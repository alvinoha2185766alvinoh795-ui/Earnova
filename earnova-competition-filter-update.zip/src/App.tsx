/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { EarnovaProvider, useEarnova } from './context/EarnovaContext';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { NotificationToast } from './components/NotificationToast';
import { NotificationCenter } from './components/NotificationCenter';
import { PredictionSlip } from './components/PredictionSlip';
import { MatchMarketsModal } from './components/MatchMarketsModal';
import { MatchDetailModal } from './components/MatchDetailModal';
import { MatchIntelligenceModal } from './components/MatchIntelligenceModal';
import { FavoriteTeamsModal } from './components/FavoriteTeamsModal';
import { NavigationDrawer } from './components/NavigationDrawer';
import { AuthModal } from './components/AuthModal';
import { HomeView } from './views/HomeView';
import { WalletView } from './views/WalletView';
import { FavoritesView } from './views/FavoritesView';
import { MatchesView } from './views/MatchesView';
import { LiveCenterView } from './views/LiveCenterView';
import { ChampionsLeagueView } from './views/ChampionsLeagueView';
import { CommunityView } from './views/CommunityView';
import { AcademyView } from './views/AcademyView';
import { PerformanceView } from './views/PerformanceView';
import { TriviaView } from './views/TriviaView';
import { HistoryView } from './views/HistoryView';
import { LeaderboardView } from './views/LeaderboardView';
import { ProfileView } from './views/ProfileView';
import { SettingsView } from './views/SettingsView';
import { DepositView } from './views/DepositView';
import { WithdrawalView } from './views/WithdrawalView';
import { NovaPlayView } from './views/NovaPlayView';

function AppContent() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [showFavoritesModal, setShowFavoritesModal] = useState<boolean>(false);
  const [selectedGameId, setSelectedGameId] = useState<string | undefined>(undefined);

  // Ensure view resets to top when switching navigation tabs (critical for Android browsers)
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.scrollTo) {
        window.scrollTo(0, 0);
      }
    } catch {}
  }, [currentTab]);

  const {
    selectedMarketsMatch,
    setSelectedMarketsMatch,
    selectedMatchDetail,
    setSelectedMatchDetail,
    selectedIntelligenceMatch,
    setSelectedIntelligenceMatch,
    setIsNotificationCenterOpen,
  } = useEarnova();

  return (
    <div className="min-h-screen bg-[#070d18] text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* 1. Legal Disclaimer Banner */}
      <DisclaimerBanner />

      {/* 2. Top Bar Navigation Contract with Language & Low-Data Mode */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenFavorites={() => setShowFavoritesModal(true)}
      />

      {/* 3. Main Content Views */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 pb-24 md:pb-12">
        {currentTab === 'home' && (
          <HomeView
            onNavigateToMatches={() => setCurrentTab('matches')}
            onNavigateToLive={() => setCurrentTab('live')}
            onNavigateToHistory={() => setCurrentTab('history')}
            onNavigateToLeaderboard={() => setCurrentTab('leaderboard')}
            onNavigateToUCL={() => setCurrentTab('ucl')}
            onNavigateToAcademy={() => setCurrentTab('academy')}
            onNavigateToCommunity={() => setCurrentTab('community')}
            onNavigateToTrivia={() => setCurrentTab('trivia')}
            onNavigateToWallet={() => setCurrentTab('wallet')}
            onNavigateToFavorites={() => setCurrentTab('favorites')}
            onNavigateToProfile={() => setCurrentTab('profile')}
            onNavigateToDeposit={() => setCurrentTab('deposit')}
            onNavigateToWithdraw={() => setCurrentTab('withdraw')}
            onNavigateToNovaPlay={(gameId?: string) => {
              setSelectedGameId(gameId);
              setCurrentTab('novaplay');
            }}
          />
        )}
        {currentTab === 'wallet' && (
          <WalletView
            onNavigateToHome={() => setCurrentTab('home')}
            onNavigateToHistory={() => setCurrentTab('history')}
            onNavigateToMatches={() => setCurrentTab('matches')}
            onNavigateToLeaderboard={() => setCurrentTab('leaderboard')}
            onNavigateToProfile={() => setCurrentTab('profile')}
            onNavigateToDeposit={() => setCurrentTab('deposit')}
            onNavigateToWithdraw={() => setCurrentTab('withdraw')}
          />
        )}
        {currentTab === 'deposit' && (
          <DepositView
            onBack={() => setCurrentTab('wallet')}
            onNavigateToWallet={() => setCurrentTab('wallet')}
            onNavigateToMatches={() => setCurrentTab('matches')}
          />
        )}
        {currentTab === 'withdraw' && (
          <WithdrawalView
            onBack={() => setCurrentTab('wallet')}
            onNavigateToWallet={() => setCurrentTab('wallet')}
            onNavigateToMatches={() => setCurrentTab('matches')}
          />
        )}
        {currentTab === 'settings' && (
          <SettingsView onBack={() => setCurrentTab('home')} />
        )}
        {currentTab === 'novaplay' && (
          <NovaPlayView
            initialGameId={selectedGameId}
            onBack={() => {
              setSelectedGameId(undefined);
              setCurrentTab('home');
            }}
            onNavigateToWallet={() => setCurrentTab('wallet')}
          />
        )}
        {currentTab === 'favorites' && (
          <FavoritesView
            onNavigateToMatches={() => setCurrentTab('matches')}
            onNavigateToLive={() => setCurrentTab('live')}
          />
        )}
        {currentTab === 'matches' && <MatchesView />}
        {currentTab === 'live' && <LiveCenterView />}
        {currentTab === 'ucl' && <ChampionsLeagueView />}
        {currentTab === 'community' && <CommunityView />}
        {currentTab === 'academy' && <AcademyView />}
        {currentTab === 'performance' && <PerformanceView />}
        {currentTab === 'trivia' && <TriviaView />}
        {currentTab === 'history' && <HistoryView />}
        {currentTab === 'leaderboard' && (
          <LeaderboardView
            onNavigateToProfile={() => setCurrentTab('profile')}
            onNavigateToWallet={() => setCurrentTab('wallet')}
          />
        )}
        {currentTab === 'profile' && (
          <ProfileView
            onNavigateToWallet={() => setCurrentTab('wallet')}
            onNavigateToLeaderboard={() => setCurrentTab('leaderboard')}
            onNavigateToSettings={() => setCurrentTab('settings')}
          />
        )}
      </main>

      {/* 4. Navigation Drawer connecting all sections */}
      <NavigationDrawer
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenNotifications={() => setIsNotificationCenterOpen(true)}
      />

      {/* 4. Bottom Tab Bar for Mobile Touch Ergonomics */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenFavorites={() => setShowFavoritesModal(true)}
      />

      {/* 5. Modals & Overlays */}
      {selectedMarketsMatch && (
        <MatchMarketsModal
          match={selectedMarketsMatch}
          onClose={() => setSelectedMarketsMatch(null)}
        />
      )}

      {selectedMatchDetail && (
        <MatchDetailModal
          match={selectedMatchDetail}
          onClose={() => setSelectedMatchDetail(null)}
        />
      )}

      {selectedIntelligenceMatch && (
        <MatchIntelligenceModal
          match={selectedIntelligenceMatch}
          onClose={() => setSelectedIntelligenceMatch(null)}
        />
      )}

      {showFavoritesModal && (
        <FavoriteTeamsModal onClose={() => setShowFavoritesModal(false)} />
      )}

      {/* 6. Prediction Slip Drawer */}
      <PredictionSlip />

      {/* 7. Live Alerts Drawer */}
      <NotificationCenter />

      {/* 8. Floating Real-Time Goal / Event Toast */}
      <NotificationToast />

      {/* 9. Complete Authentication & Accounts Modal */}
      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <EarnovaProvider>
      <AppContent />
    </EarnovaProvider>
  );
}
