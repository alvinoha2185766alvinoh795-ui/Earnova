/**
 * Safe Storage Utility for Earnova
 * 
 * Provides safe access to localStorage with in-memory fallback.
 * Prevents DOMException / SecurityError when cookies/storage are disabled
 * or partitioned in sandboxed preview iframes.
 */

const memoryStore: Record<string, string> = {};

function isLocalStorageAvailable(): boolean {
  try {
    if (typeof window === 'undefined') return false;
    const testKey = '__earnova_storage_test__';
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
}

const hasLocalStorage = isLocalStorageAvailable();

export const safeStorage = {
  getItem: (key: string): string | null => {
    try {
      if (hasLocalStorage && typeof window !== 'undefined') {
        const val = window.localStorage.getItem(key);
        if (val !== null) return val;
      }
    } catch {}
    return memoryStore[key] ?? null;
  },

  setItem: (key: string, value: string): void => {
    try {
      memoryStore[key] = value;
      if (hasLocalStorage && typeof window !== 'undefined') {
        window.localStorage.setItem(key, value);
      }
    } catch {}
  },

  removeItem: (key: string): void => {
    try {
      delete memoryStore[key];
      if (hasLocalStorage && typeof window !== 'undefined') {
        window.localStorage.removeItem(key);
      }
    } catch {}
  },

  getJSON: <T>(key: string, fallback: T): T => {
    try {
      const raw = safeStorage.getItem(key);
      if (!raw) return fallback;
      const parsed = JSON.parse(raw);
      if (parsed === null || parsed === undefined) return fallback;
      return parsed as T;
    } catch {
      return fallback;
    }
  },
};
