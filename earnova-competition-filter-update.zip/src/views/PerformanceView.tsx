import React from 'react';
import {
  TrendingUp,
  Award,
  Shield,
  Target,
  BarChart2,
  PieChart,
  Flame,
  CheckCircle,
  Coins,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

export const PerformanceView: React.FC = () => {
  const { user, placedPredictions, language } = useEarnova();
  const { t } = useTranslation(language);

  const totalSlips = placedPredictions.length;
  const wonSlips = placedPredictions.filter((p) => p.status === 'won').length;
  const lostSlips = placedPredictions.filter((p) => p.status === 'lost').length;
  const accuracy = totalSlips > 0 ? Math.round((wonSlips / totalSlips) * 100) : 0;

  const totalStaked = placedPredictions.reduce((acc, p) => acc + p.stake, 0);
  const totalReturned = placedPredictions
    .filter((p) => p.status === 'won')
    .reduce((acc, p) => acc + p.potentialReturn, 0);
  const netProfit = totalReturned - totalStaked;

  const avgOdds =
    totalSlips > 0
      ? (placedPredictions.reduce((acc, p) => acc + p.totalOdds, 0) / totalSlips).toFixed(2)
      : '2.10';

  const marketStats = [
    { name: 'Double Chance (1X, X2, 12)', accuracy: 82, total: 11, color: '#10b981' },
    { name: 'Over / Under Goals', accuracy: 74, total: 19, color: '#34d399' },
    { name: 'Both Teams to Score (BTTS)', accuracy: 70, total: 10, color: '#38bdf8' },
    { name: '1X2 Match Result', accuracy: 65, total: 24, color: '#f59e0b' },
    { name: 'Correct Score Predictions', accuracy: 28, total: 7, color: '#ec4899' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
          {t('personalPerformance')}
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Detailed metrics on your prediction accuracy, market proficiencies, and virtual EP growth
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400 block">{t('predictionAccuracy')}</span>
          <div className="mt-2 flex items-baseline gap-1 font-mono font-extrabold text-2xl sm:text-3xl text-emerald-400 tabular-nums">
            {accuracy}%
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {wonSlips} Won / {totalSlips} Settled
          </span>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400 block">{t('netProfit')}</span>
          <div className="mt-2 flex items-baseline gap-1 font-mono font-extrabold text-2xl sm:text-3xl text-white tabular-nums">
            <span className={netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
              {netProfit >= 0 ? `+${netProfit.toLocaleString()}` : netProfit.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-slate-400">EP</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {totalReturned.toLocaleString()} won from {totalStaked.toLocaleString()} staked
          </span>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400 block">Avg Multiplier Taken</span>
          <div className="mt-2 flex items-baseline gap-1 font-mono font-extrabold text-2xl sm:text-3xl text-white tabular-nums">
            {avgOdds}x
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Optimal balance of value and risk
          </span>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400 block">Tactician Streak</span>
          <div className="mt-2 flex items-baseline gap-1 font-mono font-extrabold text-2xl sm:text-3xl text-amber-400 tabular-nums">
            {user.winStreak}W
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Longest recorded: {user.longestStreak} in a row
          </span>
        </div>
      </div>

      {/* Market Proficiency Breakdown */}
      <div className="p-6 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-5">
        <div className="flex items-center justify-between border-b border-[#14264b] pb-3 text-xs">
          <div>
            <h3 className="font-display font-bold text-base text-white">
              {t('marketBreakdown')}
            </h3>
            <p className="text-slate-400 text-[11px] mt-0.5">
              Identifies which market formats yield your highest strike rate
            </p>
          </div>
          <span className="text-emerald-400 font-semibold font-mono">
            Top: Double Chance (82%)
          </span>
        </div>

        <div className="space-y-4">
          {marketStats.map((stat, idx) => (
            <div key={idx} className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-slate-200">
                <span className="font-semibold">{stat.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 text-[11px]">({stat.total} picks)</span>
                  <span className="font-mono font-bold text-emerald-400 tabular-nums">
                    {stat.accuracy}% Pass
                  </span>
                </div>
              </div>
              <div className="h-2 rounded-full bg-[#081224] overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${stat.accuracy}%`,
                    backgroundColor: stat.color,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tactical Insights & Strengths */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
        <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <CheckCircle className="w-4 h-4" />
            <span>Key Strength: Conservative Value</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            Your high accuracy in <strong>Double Chance (82%)</strong> and <strong>Over/Under (74%)</strong> shows strong analytical discipline. You excel at predicting game tempo rather than isolated match winners.
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-2">
          <div className="flex items-center gap-2 text-amber-400 font-bold">
            <Target className="w-4 h-4" />
            <span>Growth Area: Accumulator Sizing</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            Keep accumulator legs to 2-3 maximum. High 4+ leg combos suffer from variance decay. Pairing 2 high-confidence Double Chance picks provides optimum expected yield.
          </p>
        </div>
      </div>
    </div>
  );
};
