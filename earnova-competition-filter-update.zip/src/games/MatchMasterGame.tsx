import React, { useState, useEffect } from 'react';
import { Trophy, Clock, Sparkles, CheckCircle2, RotateCcw } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

interface Card {
  id: number;
  symbol: string;
  name: string;
  flipped: boolean;
  matched: boolean;
}

const SYMBOLS = [
  { symbol: '⚽', name: 'Match Ball' },
  { symbol: '🏆', name: 'Champions Cup' },
  { symbol: '👟', name: 'Golden Boot' },
  { symbol: '🧤', name: 'Safe Hands' },
  { symbol: '🟨', name: 'Yellow Card' },
  { symbol: '⏱️', name: 'Extra Time' },
  { symbol: '🎯', name: 'Bullseye Goal' },
  { symbol: '🏟️', name: 'Grand Stadium' },
];

const generateCards = (): Card[] => {
  const deck = [...SYMBOLS, ...SYMBOLS]
    .sort(() => Math.random() - 0.5)
    .map((item, index) => ({
      id: index,
      symbol: item.symbol,
      name: item.name,
      flipped: false,
      matched: false,
    }));
  return deck;
};

export const MatchMasterGame: React.FC = () => {
  const { user, updateUser } = useEarnova();

  const [cards, setCards] = useState<Card[]>(generateCards);
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState<number>(0);
  const [matches, setMatches] = useState<number>(0);
  const [gameWon, setGameWon] = useState<boolean>(false);
  const [bonusEarned, setBonusEarned] = useState<number>(0);

  const handleCardClick = (index: number) => {
    if (cards[index].flipped || cards[index].matched || selectedCards.length === 2) return;
    sound.playTap();

    const newCards = [...cards];
    newCards[index].flipped = true;
    setCards(newCards);

    const newSelected = [...selectedCards, index];
    setSelectedCards(newSelected);

    if (newSelected.length === 2) {
      setMoves((prev) => prev + 1);
      const [firstIdx, secondIdx] = newSelected;

      if (newCards[firstIdx].symbol === newCards[secondIdx].symbol) {
        // Match!
        sound.playCashout();
        newCards[firstIdx].matched = true;
        newCards[secondIdx].matched = true;
        setCards(newCards);
        setSelectedCards([]);
        setMatches((prev) => {
          const next = prev + 1;
          if (next === 8) {
            // Completed!
            const bonus = Math.max(100, 300 - moves * 10);
            setBonusEarned(bonus);
            setGameWon(true);
            updateUser({ points: user.points + bonus });
          }
          return next;
        });
      } else {
        // No match, flip back after 700ms
        setTimeout(() => {
          newCards[firstIdx].flipped = false;
          newCards[secondIdx].flipped = false;
          setCards([...newCards]);
          setSelectedCards([]);
        }, 700);
      }
    }
  };

  const handleRestart = () => {
    setCards(generateCards());
    setSelectedCards([]);
    setMoves(0);
    setMatches(0);
    setGameWon(false);
    setBonusEarned(0);
    sound.playTap();
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
          <Trophy className="w-3.5 h-3.5" />
          <span>NovaPlay Tactical Pairs</span>
        </div>
        <h2 className="font-display font-extrabold text-2xl text-white">Match Master</h2>
        <p className="text-xs text-slate-400">Pair all football emblems in fewest moves to earn virtual EP!</p>
      </div>

      <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] text-xs">
        <span className="text-slate-400">Moves: <strong className="text-white font-mono">{moves}</strong></span>
        <span className="text-slate-400">Matches: <strong className="text-emerald-400 font-mono">{matches}/8</strong></span>
        <button
          type="button"
          onClick={handleRestart}
          className="text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* 4x4 Cards Grid */}
      <div className="grid grid-cols-4 gap-2.5 p-4 rounded-3xl bg-[#0c1830] border border-[#162c57] shadow-xl">
        {cards.map((card, i) => (
          <button
            key={card.id}
            type="button"
            onClick={() => handleCardClick(i)}
            className={`w-full aspect-square rounded-2xl flex items-center justify-center text-3xl font-bold transition-all cursor-pointer touch-manipulation border ${
              card.matched
                ? 'bg-emerald-500/20 border-emerald-500/50 opacity-80'
                : card.flipped
                ? 'bg-[#14264d] border-emerald-400 text-white shadow-lg'
                : 'bg-[#081224] border-[#162c57] hover:border-slate-500 text-slate-600'
            }`}
          >
            {card.flipped || card.matched ? card.symbol : '✦'}
          </button>
        ))}
      </div>

      {gameWon && (
        <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-400 text-center space-y-2 animate-in zoom-in-95 duration-150">
          <div className="text-xs uppercase font-bold text-emerald-400">Pitch Cleared!</div>
          <div className="font-display font-black text-2xl text-white">
            +{bonusEarned} EP Bonus
          </div>
          <p className="text-xs text-slate-300">You mastered all tactical cards in {moves} moves!</p>
          <button
            type="button"
            onClick={handleRestart}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs uppercase tracking-wider"
          >
            Play Next Round
          </button>
        </div>
      )}
    </div>
  );
};
