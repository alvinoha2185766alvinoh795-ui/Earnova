import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowDownLeft,
  ShieldCheck,
  Sparkles,
  Coins,
  CheckCircle2,
  Copy,
  Check,
  RefreshCw,
  Info,
  Clock,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';
import { DEMO_DEPOSIT_PACKAGES } from '../data/mockData';
import { DemoDepositPackage } from '../types';

interface DepositViewProps {
  onBack: () => void;
  onNavigateToWallet: () => void;
  onNavigateToMatches?: () => void;
}

export const DepositView: React.FC<DepositViewProps> = ({
  onBack,
  onNavigateToWallet,
  onNavigateToMatches,
}) => {
  const { user, demoDeposit, language } = useEarnova();
  const { t } = useTranslation(language);

  const [customAmount, setCustomAmount] = useState<number>(2500);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [receiptResult, setReceiptResult] = useState<{ reference: string; amount: number } | null>(null);
  const [copiedRef, setCopiedRef] = useState<boolean>(false);

  const handleClaimPackage = (pkg: DemoDepositPackage) => {
    setIsProcessing(true);
    setTimeout(() => {
      const res = demoDeposit(pkg.id);
      setReceiptResult({ reference: res.reference, amount: res.epAdded });
      setIsProcessing(false);
    }, 600);
  };

  const handleCustomDeposit = () => {
    if (customAmount <= 0) return;
    setIsProcessing(true);
    setTimeout(() => {
      const res = demoDeposit('custom', customAmount);
      setReceiptResult({ reference: res.reference, amount: res.epAdded });
      setIsProcessing(false);
    }, 600);
  };

  const copyRefToClipboard = (text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
      }
    } catch {}
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  return (
    <div className="space-y-6 pb-16 max-w-4xl mx-auto">
      {/* 1. Header Navigation Bar */}
      <div className="flex items-center justify-between gap-4 pb-2 border-b border-[#14264b]">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#0c1830] hover:bg-[#122347] border border-[#162c57] text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer touch-manipulation active:scale-95"
          title="Back to Previous Screen"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-400" />
          <span>Back</span>
        </button>

        <div className="text-right">
          <div className="flex items-center justify-end gap-2">
            <h1 className="font-display font-extrabold text-lg sm:text-2xl text-white tracking-tight">
              Demo Deposit Center
            </h1>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              100% Free Simulation
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Replenish virtual Earnova Points (EP) for demonstration play
          </p>
        </div>
      </div>

      {/* 2. Educational Free-to-Play Security Card & Proposed Minimum Deposit */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-emerald-950/70 via-[#0a1a36] to-[#071329] border border-emerald-500/40 shadow-xl space-y-4">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display font-bold text-base sm:text-lg text-white">
                Demonstration & Virtual Sandbox Guidelines
              </h2>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-400 text-slate-950">
                Proposed Min: KSh 10
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Earnova is a free-to-play sports analytics and tactical prediction simulation. <strong>No real-money transactions, payment cards, mobile money, or bank deposits</strong> are accepted or processed. All points are fictional game credits created solely for skill evaluation and leaderboard rankings.
            </p>
          </div>
        </div>

        {/* Proposed Minimum Deposit Highlight Strip (Requirement: Minimum Deposit KSh 10) */}
        <div className="p-3.5 rounded-2xl bg-[#061224] border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-black text-xs font-mono shrink-0">
              KSh
            </div>
            <div>
              <span className="text-[11px] font-bold text-white block">
                Proposed Minimum Deposit Benchmark: <span className="text-emerald-400 font-extrabold text-xs">KSh 10</span> (100 EP)
              </span>
              <span className="text-[10px] text-slate-400 block">
                Micro-deposit baseline for prototype testing & virtual bankroll simulation.
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleClaimPackage({ id: 'micro', name: 'Starter Micro Refill (KSh 10 Proposed Min)', epAmount: 100, description: 'Proposed minimum deposit demonstration grant', icon: '⚡' })}
            disabled={isProcessing}
            className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer touch-manipulation active:scale-95 shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Simulate KSh 10 (+100 EP)</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-[#162d59] text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Zero monetary cost</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Min deposit: KSh 10 (100 EP)</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Full audited ledger record</span>
          </div>
        </div>
      </div>

      {/* 3. Current Virtual Balance Pill */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-[#09152b] border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Current Available Balance
            </span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="font-mono font-black text-2xl sm:text-3xl text-white tabular-nums">
                {(user?.points ?? 0).toLocaleString()}
              </span>
              <span className="text-sm font-bold text-emerald-400 font-mono">EP</span>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onNavigateToWallet}
          className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 self-start sm:self-auto hover:underline cursor-pointer touch-manipulation"
        >
          <span>View Full Wallet Ledger →</span>
        </button>
      </div>

      {/* 4. Demo Deposit Packages Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Select a Demo Grant Package</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">100% Free Refills</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {DEMO_DEPOSIT_PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/50 transition-all flex flex-col justify-between gap-4 group shadow-sm"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-2xl">{pkg.icon}</span>
                  {pkg.tag && (
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {pkg.tag}
                    </span>
                  )}
                </div>
                <h4 className="font-display font-extrabold text-lg text-white mt-2 group-hover:text-emerald-300 transition-colors">
                  {pkg.name}
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {pkg.description}
                </p>
              </div>

              <div className="pt-4 border-t border-[#14264b] flex items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                    Simulated Grant
                  </span>
                  <span className="font-mono font-black text-2xl text-emerald-400 tabular-nums">
                    +{pkg.epAmount.toLocaleString()} EP
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleClaimPackage(pkg)}
                  disabled={isProcessing}
                  className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider active:scale-95 transition-all disabled:opacity-50 cursor-pointer touch-manipulation shadow-md shadow-emerald-500/20 shrink-0"
                >
                  {isProcessing ? 'Crediting...' : 'Simulate Deposit'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Custom Virtual Deposit Simulator */}
      <div className="p-6 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-4">
        <div>
          <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>Custom Amount Simulator</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Input any simulated amount to model high-stakes accumulators or test risk-management models.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <input
              type="number"
              min={100}
              max={50000}
              step={500}
              value={customAmount}
              onChange={(e) => setCustomAmount(Number(e.target.value))}
              className="w-full h-12 px-4 rounded-xl bg-[#081224] border border-[#1a3363] text-white font-mono font-bold text-lg focus:outline-none focus:border-emerald-400 touch-manipulation"
            />
            <span className="absolute right-4 top-3.5 text-xs font-bold text-emerald-400 font-mono">
              EP
            </span>
          </div>

          <button
            type="button"
            onClick={handleCustomDeposit}
            disabled={isProcessing || customAmount <= 0}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider shrink-0 active:scale-95 transition-all disabled:opacity-50 cursor-pointer touch-manipulation shadow-md shadow-emerald-500/20"
          >
            {isProcessing ? 'Processing Sandbox...' : `Credit +${customAmount.toLocaleString()} EP`}
          </button>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          <Info className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span>Credits are logged into your local simulation ledger immediately without network delay.</span>
        </div>
      </div>

      {/* 6. Success Receipt Modal */}
      {receiptResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#09152b] border border-emerald-500/50 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-400 flex items-center justify-center mx-auto text-3xl">
              ✓
            </div>
            <div>
              <span className="text-xs uppercase font-bold text-emerald-400 tracking-wider">
                Simulated Deposit Approved
              </span>
              <h3 className="font-display font-extrabold text-2xl text-white mt-1">
                +{receiptResult.amount.toLocaleString()} EP Added
              </h3>
              <p className="text-xs text-slate-300 mt-2">
                Your virtual bankroll has been replenished for demonstration play.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#060e1f] border border-[#14264b] text-left text-xs font-mono space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>Ref Code:</span>
                <button
                  type="button"
                  onClick={() => copyRefToClipboard(receiptResult.reference)}
                  className="text-white font-bold flex items-center gap-1 hover:text-emerald-300 cursor-pointer"
                >
                  <span>{receiptResult.reference}</span>
                  {copiedRef ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-500" />}
                </button>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Rail:</span>
                <span className="text-emerald-400">Earnova Demo Sandbox</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>New Total:</span>
                <span className="text-white font-bold">{(user?.points ?? 0).toLocaleString()} EP</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setReceiptResult(null)}
                className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer touch-manipulation"
              >
                Done
              </button>
              <button
                type="button"
                onClick={() => {
                  setReceiptResult(null);
                  onNavigateToWallet();
                }}
                className="py-3 px-4 rounded-xl bg-[#0e1d3b] hover:bg-[#142852] border border-[#162c57] text-slate-200 text-xs font-semibold cursor-pointer touch-manipulation"
              >
                View Ledger
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
