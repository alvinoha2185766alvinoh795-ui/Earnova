import React, { useState } from 'react';
import { X, Sparkles, TrendingUp, Shield, Brain, Zap, Target } from 'lucide-react';
import { Match, TeamFormGame } from '../types';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface MatchIntelligenceModalProps {
  match: Match;
  onClose: () => void;
}

export const MatchIntelligenceModal: React.FC<MatchIntelligenceModalProps> = ({ match, onClose }) => {
  const { togglePick, isSelectionActive, language } = useEarnova();
  const { t } = useTranslation(language);
  const [activeTab, setActiveTab] = useState<'ai' | 'stats' | 'form'>('ai');

  const intel = match.intelligence;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#091326] border border-[#1b3463] rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#14264b] bg-gradient-to-r from-[#0a162e] to-[#0d1f42] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Earnova Match Intelligence AI</span>
              </div>
              <h3 className="font-display font-bold text-base text-white">
                {match.homeTeam.name} vs {match.awayTeam.name}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-[#122245] transition-colors"
            aria-label="Close intelligence"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="px-4 py-2 bg-[#070e1c] border-b border-[#14264b] flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('ai')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'ai'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-[#112244]'
            }`}
          >
            Tactical AI Breakdown
          </button>
          <button
            onClick={() => setActiveTab('form')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'form'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-[#112244]'
            }`}
          >
            Recent Form & Results
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'stats'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-[#112244]'
            }`}
          >
            Team Strength Indices
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {!intel ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              Full intelligence dossier loading for this fixture...
            </div>
          ) : (
            <>
              {/* TAB 1: AI BREAKDOWN */}
              {activeTab === 'ai' && (
                <div className="space-y-4">
                  {/* Win Probability Bar */}
                  <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-2">
                    <span className="text-xs font-semibold text-slate-300 block">
                      AI Win Probability Forecast
                    </span>
                    <div className="grid grid-cols-3 gap-2 text-center text-xs">
                      <div className="p-2 rounded-xl bg-[#102143] border border-[#1b3464]">
                        <span className="text-[10px] text-slate-400 block">{match.homeTeam.code} Win</span>
                        <strong className="font-mono text-base text-emerald-400 font-bold tabular-nums">
                          {intel.aiExplanation.winProbability.home}%
                        </strong>
                      </div>
                      <div className="p-2 rounded-xl bg-[#102143] border border-[#1b3464]">
                        <span className="text-[10px] text-slate-400 block">Draw (X)</span>
                        <strong className="font-mono text-base text-slate-200 font-bold tabular-nums">
                          {intel.aiExplanation.winProbability.draw}%
                        </strong>
                      </div>
                      <div className="p-2 rounded-xl bg-[#102143] border border-[#1b3464]">
                        <span className="text-[10px] text-slate-400 block">{match.awayTeam.code} Win</span>
                        <strong className="font-mono text-base text-sky-400 font-bold tabular-nums">
                          {intel.aiExplanation.winProbability.away}%
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* AI Recommended Pick Callout */}
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0e244d] to-[#0c1936] border border-emerald-500/40 shadow-lg shadow-emerald-950/20 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                        <Zap className="w-4 h-4" />
                        <span>AI Recommended Value Selection</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded-md border border-emerald-500/30">
                        {intel.aiExplanation.aiRecommendedPick.confidence}% Confidence
                      </span>
                    </div>

                    <div className="flex items-baseline justify-between pt-1">
                      <div>
                        <span className="text-xs text-slate-400 block">
                          Market: {intel.aiExplanation.aiRecommendedPick.market}
                        </span>
                        <h4 className="font-display font-extrabold text-base text-white mt-0.5">
                          {intel.aiExplanation.aiRecommendedPick.pick}
                        </h4>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed pt-1">
                      {intel.aiExplanation.aiRecommendedPick.rationale}
                    </p>
                  </div>

                  {/* Key Tactical Battles */}
                  <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-slate-200 font-semibold">
                      <Target className="w-4 h-4 text-emerald-400" />
                      <span>Key Tactical Battleground</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {intel.aiExplanation.keyTacticalBattle}
                    </p>
                  </div>

                  {/* Expected Game Flow */}
                  <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-slate-200 font-semibold">
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                      <span>Expected Flow & Momentum</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {intel.aiExplanation.expectedGameFlow}
                    </p>
                  </div>
                </div>
              )}

              {/* TAB 2: RECENT FORM */}
              {activeTab === 'form' && (
                <div className="space-y-4">
                  {/* Home Team Form */}
                  <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-2.5">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-xs text-white">
                        {match.homeTeam.name} (Past 5 Matches)
                      </h4>
                      <span className="text-xs text-slate-400 font-mono">
                        Avg {intel.homeIntelligence.avgGoalsScored} Scored / {intel.homeIntelligence.avgGoalsConceded} Conceded
                      </span>
                    </div>

                    <div className="grid grid-cols-5 gap-2">
                      {intel.homeIntelligence.recentForm.map((game, idx) => (
                        <FormBadge key={idx} game={game} />
                      ))}
                    </div>
                  </div>

                  {/* Away Team Form */}
                  <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-2.5">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-xs text-white">
                        {match.awayTeam.name} (Past 5 Matches)
                      </h4>
                      <span className="text-xs text-slate-400 font-mono">
                        Avg {intel.awayIntelligence.avgGoalsScored} Scored / {intel.awayIntelligence.avgGoalsConceded} Conceded
                      </span>
                    </div>

                    <div className="grid grid-cols-5 gap-2">
                      {intel.awayIntelligence.recentForm.map((game, idx) => (
                        <FormBadge key={idx} game={game} />
                      ))}
                    </div>
                  </div>

                  {/* Head-to-Head Note */}
                  <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] text-xs text-slate-300 space-y-1">
                    <span className="font-semibold text-slate-200 block">Historical Head-to-Head</span>
                    <p>{intel.headToHeadSummary}</p>
                  </div>
                </div>
              )}

              {/* TAB 3: TEAM STRENGTH INDICES */}
              {activeTab === 'stats' && (
                <div className="space-y-3">
                  <StrengthComparison
                    title="Attack Power Index"
                    homeTeam={match.homeTeam.code}
                    awayTeam={match.awayTeam.code}
                    homeVal={intel.homeIntelligence.attackRating}
                    awayVal={intel.awayIntelligence.attackRating}
                    max={100}
                  />

                  <StrengthComparison
                    title="Defensive Solidity Index"
                    homeTeam={match.homeTeam.code}
                    awayTeam={match.awayTeam.code}
                    homeVal={intel.homeIntelligence.defenseRating}
                    awayVal={intel.awayIntelligence.defenseRating}
                    max={100}
                  />

                  <StrengthComparison
                    title="Average Possession %"
                    homeTeam={match.homeTeam.code}
                    awayTeam={match.awayTeam.code}
                    homeVal={intel.homeIntelligence.possessionAvg}
                    awayVal={intel.awayIntelligence.possessionAvg}
                    max={100}
                    unit="%"
                  />

                  <StrengthComparison
                    title="Clean Sheet Rate %"
                    homeTeam={match.homeTeam.code}
                    awayTeam={match.awayTeam.code}
                    homeVal={intel.homeIntelligence.cleanSheetRate}
                    awayVal={intel.awayIntelligence.cleanSheetRate}
                    max={100}
                    unit="%"
                  />
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#070e1c] border-t border-[#14264b] flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Powered by Earnova statistical models. For demonstration simulation only.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
          >
            {t('done')}
          </button>
        </div>
      </div>
    </div>
  );
};

function FormBadge({ game }: { game: TeamFormGame }) {
  const isWin = game.result === 'W';
  const isDraw = game.result === 'D';

  return (
    <div
      className={`p-2 rounded-xl border text-center text-xs ${
        isWin
          ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
          : isDraw
          ? 'bg-amber-950/60 border-amber-500/40 text-amber-300'
          : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
      }`}
    >
      <span className="font-mono font-bold block">{game.result}</span>
      <span className="text-[10px] opacity-80 block truncate mt-0.5">{game.score}</span>
    </div>
  );
}

function StrengthComparison({
  title,
  homeTeam,
  awayTeam,
  homeVal,
  awayVal,
  max,
  unit = '',
}: {
  title: string;
  homeTeam: string;
  awayTeam: string;
  homeVal: number;
  awayVal: number;
  max: number;
  unit?: string;
}) {
  return (
    <div className="p-3.5 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-1.5 text-xs">
      <div className="flex items-center justify-between text-slate-300 font-semibold">
        <span>
          {homeTeam} <strong className="text-emerald-400 tabular-nums">{homeVal}{unit}</strong>
        </span>
        <span className="text-slate-400">{title}</span>
        <span>
          <strong className="text-sky-400 tabular-nums">{awayVal}{unit}</strong> {awayTeam}
        </span>
      </div>
      <div className="h-2 rounded-full bg-[#112347] overflow-hidden flex">
        <div
          className="bg-emerald-500 transition-all duration-300"
          style={{ width: `${(homeVal / max) * 50}%` }}
        />
        <div className="w-1 bg-[#091326]" />
        <div
          className="bg-sky-500 transition-all duration-300 ml-auto"
          style={{ width: `${(awayVal / max) * 50}%` }}
        />
      </div>
    </div>
  );
}
