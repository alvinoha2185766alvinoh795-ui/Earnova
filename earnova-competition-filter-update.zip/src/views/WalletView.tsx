import React, { useState } from 'react';
import {
  Coins,
  ArrowDownLeft,
  ArrowUpRight,
  Sparkles,
  ShieldCheck,
  History,
  CheckCircle2,
  Copy,
  Check,
  AlertCircle,
  FileText,
  Clock,
  Download,
  Flame,
  Award,
  CreditCard,
  RefreshCw,
  Search,
  ArrowLeft,
  ChevronLeft,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';
import { DEMO_DEPOSIT_PACKAGES, DEMO_WITHDRAWAL_REWARDS } from '../data/mockData';
import { DemoDepositPackage, DemoWithdrawalReward } from '../types';

interface WalletViewProps {
  onNavigateToHome?: () => void;
  onNavigateToHistory: () => void;
  onNavigateToMatches: () => void;
  onNavigateToLeaderboard?: () => void;
  onNavigateToProfile?: () => void;
  onNavigateToDeposit?: () => void;
  onNavigateToWithdraw?: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  onNavigateToHome,
  onNavigateToHistory,
  onNavigateToMatches,
  onNavigateToLeaderboard,
  onNavigateToProfile,
  onNavigateToDeposit,
  onNavigateToWithdraw,
}) => {
  const { user, transactions = [], placedPredictions = [], demoDeposit, demoWithdraw, refillDemoPoints, language } = useEarnova();
  const { t } = useTranslation(language);

  const safeTransactions = Array.isArray(transactions) ? transactions : [];
  const safePlacedPredictions = Array.isArray(placedPredictions) ? placedPredictions : [];

  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw' | 'ledger'>('overview');
  const [filterType, setFilterType] = useState<'all' | 'deposit' | 'prediction_stake' | 'prediction_payout' | 'daily_bonus'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedRef, setCopiedRef] = useState<string | null>(null);

  // Deposit Modal Simulation
  const [selectedDepositPkg, setSelectedDepositPkg] = useState<DemoDepositPackage | null>(null);
  const [customDepositAmount, setCustomDepositAmount] = useState<number>(2000);
  const [isDepositing, setIsDepositing] = useState(false);
  const [depositSuccessResult, setDepositSuccessResult] = useState<{ reference: string; amount: number } | null>(null);

  // Withdrawal Modal Simulation
  const [selectedWithdrawalReward, setSelectedWithdrawalReward] = useState<DemoWithdrawalReward | null>(null);
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [withdrawalSuccessResult, setWithdrawalSuccessResult] = useState<{ certificateId: string; reward: DemoWithdrawalReward } | null>(null);

  // Calculation of in-play virtual EP
  const pendingStakes = safePlacedPredictions
    .filter((p) => p && p.status === 'pending')
    .reduce((sum, p) => sum + (p.stake || 0), 0);

  const lifetimeWon = safeTransactions
    .filter((tx) => tx && tx.type === 'prediction_payout')
    .reduce((sum, tx) => sum + (tx.amount || 0), 0);

  const totalDeposited = safeTransactions
    .filter((tx) => tx && tx.type === 'deposit')
    .reduce((sum, tx) => sum + (tx.amount || 0), 0);

  const copyToClipboard = (text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
      }
    } catch {}
    setCopiedRef(text);
    setTimeout(() => setCopiedRef(null), 2500);
  };

  const handleExecuteDeposit = (pkg?: DemoDepositPackage) => {
    setIsDepositing(true);
    setTimeout(() => {
      let res;
      if (pkg) {
        res = demoDeposit(pkg.id);
        setDepositSuccessResult({ reference: res.reference, amount: res.epAdded });
      } else {
        res = demoDeposit('custom', customDepositAmount);
        setDepositSuccessResult({ reference: res.reference, amount: res.epAdded });
      }
      setIsDepositing(false);
    }, 700);
  };

  const handleExecuteWithdrawal = (reward: DemoWithdrawalReward) => {
    if (user.points < reward.epCost) return;
    setIsWithdrawing(true);
    setTimeout(() => {
      const res = demoWithdraw(reward.id);
      setIsWithdrawing(false);
      if (res.success && res.certificateId) {
        setWithdrawalSuccessResult({ certificateId: res.certificateId, reward });
      }
    }, 800);
  };

  const filteredTransactions = safeTransactions.filter((tx) => {
    if (!tx) return false;
    if (filterType !== 'all' && tx.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        (tx.description && tx.description.toLowerCase().includes(q)) ||
        (tx.reference && tx.reference.toLowerCase().includes(q)) ||
        (tx.type && tx.type.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Navigation Breadcrumb Bar */}
      <div className="flex flex-wrap items-center justify-between text-xs pb-1 gap-2">
        <div className="flex items-center gap-3">
          {onNavigateToHome && (
            <button
              type="button"
              onClick={onNavigateToHome}
              className="flex items-center gap-1.5 text-slate-400 hover:text-emerald-400 font-semibold transition-colors cursor-pointer py-1 touch-manipulation"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back to Dashboard</span>
            </button>
          )}

          {onNavigateToLeaderboard && (
            <button
              type="button"
              onClick={onNavigateToLeaderboard}
              className="text-slate-400 hover:text-emerald-400 transition-colors font-medium cursor-pointer py-1 touch-manipulation"
            >
              Leaderboard
            </button>
          )}

          {onNavigateToProfile && (
            <button
              type="button"
              onClick={onNavigateToProfile}
              className="text-slate-400 hover:text-emerald-400 transition-colors font-medium cursor-pointer py-1 touch-manipulation"
            >
              Profile
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={onNavigateToMatches}
          className="text-slate-400 hover:text-emerald-400 transition-colors font-medium cursor-pointer py-1 touch-manipulation"
        >
          Browse Fixtures →
        </button>
      </div>

      {/* 1. Free-to-Play Demonstration Banner */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-[#0a1b38] to-[#071329] border border-emerald-500/40 flex items-start sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5 sm:mt-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display font-extrabold text-sm sm:text-base text-white tracking-tight">
                {t('virtualWallet')}
              </h3>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                100% Free Virtual Points
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
              Earnova Points (EP) are virtual game tokens with no monetary value. No real-money deposits, withdrawals, or fiat gambling.
            </p>
          </div>
        </div>
      </div>

      {/* 2. Primary Financial Overview Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#0c1830] via-[#0b162c] to-[#081224] border border-[#162c57] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              {t('availableEP')}
            </span>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="font-mono font-black text-4xl sm:text-5xl text-white tracking-tight tabular-nums">
                {(user?.points ?? 0).toLocaleString()}
              </span>
              <span className="text-base sm:text-lg font-bold text-emerald-400 font-mono">
                EP
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
              <span>Simulation Tier: </span>
              <span className="font-semibold text-emerald-300">{user.tier}</span>
              <span>·</span>
              <span>Leaderboard Rank #{user.rank}</span>
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onNavigateToDeposit || (() => setActiveTab('deposit'))}
              className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer touch-manipulation"
            >
              <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />
              <span>{t('tabDeposit')}</span>
            </button>

            <button
              onClick={onNavigateToWithdraw || (() => setActiveTab('withdraw'))}
              className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-[#10234a] hover:bg-[#163066] border border-[#1e3e7a] text-slate-200 hover:text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer touch-manipulation"
            >
              <ArrowUpRight className="w-4 h-4 stroke-[2.5] text-amber-400" />
              <span>{t('tabWithdraw')}</span>
            </button>

            <button
              onClick={refillDemoPoints}
              title="Instant +1,000 EP Virtual Grant"
              className="p-3 rounded-xl bg-[#09152b] hover:bg-[#0f2142] border border-[#162c57] text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4 Financial Metric Pillars */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mt-8 pt-6 border-t border-[#14264b]">
          <div className="p-3.5 rounded-2xl bg-[#081224]/80 border border-[#14264b]">
            <span className="text-[11px] text-slate-400 block">{t('inPlayEP')}</span>
            <div className="mt-1 flex items-baseline gap-1 font-mono font-bold text-xl text-sky-400 tabular-nums">
              {pendingStakes.toLocaleString()} <span className="text-xs text-sky-500">EP</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              {placedPredictions.filter((p) => p.status === 'pending').length} active slips
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#081224]/80 border border-[#14264b]">
            <span className="text-[11px] text-slate-400 block">{t('lifetimeWinnings')}</span>
            <div className="mt-1 flex items-baseline gap-1 font-mono font-bold text-xl text-emerald-400 tabular-nums">
              +{lifetimeWon.toLocaleString()} <span className="text-xs text-emerald-500">EP</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              From settled predictions
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#081224]/80 border border-[#14264b]">
            <span className="text-[11px] text-slate-400 block">{t('totalSimDeposits')}</span>
            <div className="mt-1 flex items-baseline gap-1 font-mono font-bold text-xl text-amber-300 tabular-nums">
              {totalDeposited.toLocaleString()} <span className="text-xs text-amber-500">EP</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Free virtual packages
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#081224]/80 border border-[#14264b]">
            <span className="text-[11px] text-slate-400 block">Ledger Activity</span>
            <div className="mt-1 flex items-baseline gap-1 font-mono font-bold text-xl text-white tabular-nums">
              {transactions.length} <span className="text-xs text-slate-500">Events</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Audited simulation log
            </span>
          </div>
        </div>
      </div>

      {/* 3. Section Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-[#14264b] pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'overview'
              ? 'bg-emerald-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-[#0c1830]'
          }`}
        >
          {t('tabOverview')}
        </button>
        <button
          onClick={() => setActiveTab('deposit')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'deposit'
              ? 'bg-emerald-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-[#0c1830]'
          }`}
        >
          <ArrowDownLeft className="w-3.5 h-3.5" />
          <span>{t('tabDeposit')}</span>
        </button>
        <button
          onClick={() => setActiveTab('withdraw')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'withdraw'
              ? 'bg-emerald-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-[#0c1830]'
          }`}
        >
          <ArrowUpRight className="w-3.5 h-3.5" />
          <span>{t('tabWithdraw')}</span>
        </button>
        <button
          onClick={() => setActiveTab('ledger')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'ledger'
              ? 'bg-emerald-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-[#0c1830]'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>{t('tabLedger')} ({transactions.length})</span>
        </button>
      </div>

      {/* 4. Tab Contents */}

      {/* TAB A: OVERVIEW & RECENT ACTIVITY */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick Refill & Quick Predict Prompts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] flex items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  Need More Virtual Points?
                </span>
                <h4 className="font-display font-bold text-base text-white">
                  Demo Refill Packages
                </h4>
                <p className="text-xs text-slate-400">
                  Choose from +500 to +10,000 EP instant free refill allocations.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('deposit')}
                className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider shrink-0 cursor-pointer"
              >
                Refill Now
              </button>
            </div>

            <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] flex items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  Demonstration Rewards
                </span>
                <h4 className="font-display font-bold text-base text-white">
                  Redeem Virtual Trophies
                </h4>
                <p className="text-xs text-slate-400">
                  Trade earned EP for verifiable digital certificates and trophy badges.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('withdraw')}
                className="px-4 py-2.5 rounded-xl bg-[#11244d] hover:bg-[#18326b] border border-[#1e3c78] text-slate-200 hover:text-white font-bold text-xs uppercase tracking-wider shrink-0 cursor-pointer"
              >
                Browse Rewards
              </button>
            </div>
          </div>

          {/* Recent Ledger Strip */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
                <History className="w-4 h-4 text-emerald-400" />
                <span>Recent Transactions</span>
              </h3>
              <button
                onClick={() => setActiveTab('ledger')}
                className="text-xs font-semibold text-emerald-400 hover:underline cursor-pointer"
              >
                View Full Ledger →
              </button>
            </div>

            <div className="space-y-2.5">
              {transactions.slice(0, 5).map((tx) => (
                <div
                  key={tx.id}
                  className="p-3.5 sm:p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] flex items-center justify-between gap-3 hover:border-[#1e3c75] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-sm font-bold ${
                        tx.amount > 0
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {tx.amount > 0 ? (
                        <ArrowDownLeft className="w-4 h-4" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white truncate">
                          {tx.description}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-[#081224] text-slate-400 border border-[#14264b]">
                          {tx.reference}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {new Date(tx.timestamp).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`font-mono font-bold text-sm sm:text-base tabular-nums ${
                        tx.amount > 0 ? 'text-emerald-400' : 'text-slate-300'
                      }`}
                    >
                      {tx.amount > 0 ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()} EP
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      Bal: {tx.balanceAfter.toLocaleString()} EP
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB B: DEMO DEPOSIT / VIRTUAL REFILL */}
      {activeTab === 'deposit' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-[#09152b] border border-[#142a54] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <div>
                <h4 className="font-bold text-sm text-white">{t('selectDepositPackage')}</h4>
                <p className="text-xs text-slate-400">{t('demoDepositDisclaimer')}</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-lg">
              SIMULATION ONLY
            </span>
          </div>

          {/* Deposit Packages Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {DEMO_DEPOSIT_PACKAGES.map((pkg) => (
              <div
                key={pkg.id}
                className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/50 transition-all flex flex-col justify-between gap-4 group"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl">{pkg.icon}</span>
                    {pkg.tag && (
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {pkg.tag}
                      </span>
                    )}
                  </div>
                  <h4 className="font-display font-extrabold text-lg text-white mt-2 group-hover:text-emerald-300 transition-colors">
                    {pkg.name}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">{pkg.description}</p>
                </div>

                <div className="pt-4 border-t border-[#14264b] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                      Free Virtual Grant
                    </span>
                    <span className="font-mono font-black text-2xl text-emerald-400 tabular-nums">
                      +{pkg.epAmount.toLocaleString()} EP
                    </span>
                  </div>

                  <button
                    onClick={() => handleExecuteDeposit(pkg)}
                    disabled={isDepositing}
                    className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider active:scale-95 transition-all disabled:opacity-50 cursor-pointer shadow-md shadow-emerald-500/20"
                  >
                    {isDepositing ? 'Simulating...' : 'Claim Refill'}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Custom Virtual Refill Tester */}
          <div className="p-6 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-4">
            <div>
              <h4 className="font-bold text-base text-white">{t('customAmount')}</h4>
              <p className="text-xs text-slate-400">
                Specify any custom virtual amount to test high-stakes accumulator modeling or stress-test predictions.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <input
                  type="number"
                  min={100}
                  max={50000}
                  step={500}
                  value={customDepositAmount}
                  onChange={(e) => setCustomDepositAmount(Number(e.target.value))}
                  className="w-full h-11 px-4 rounded-xl bg-[#081224] border border-[#1a3363] text-white font-mono font-bold text-base focus:outline-none focus:border-emerald-400"
                />
                <span className="absolute right-3.5 top-3 text-xs font-bold text-emerald-400 font-mono">
                  EP
                </span>
              </div>

              <button
                onClick={() => handleExecuteDeposit()}
                disabled={isDepositing || customDepositAmount <= 0}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider shrink-0 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
              >
                {isDepositing ? 'Crediting...' : `Credit +${customDepositAmount.toLocaleString()} EP`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB C: DEMO WITHDRAWAL / VIRTUAL REWARD REDEMPTION */}
      {activeTab === 'withdraw' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-[#09152b] border border-[#142a54] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Award className="w-5 h-5 text-amber-400" />
              <div>
                <h4 className="font-bold text-sm text-white">{t('redeemVirtualReward')}</h4>
                <p className="text-xs text-slate-400">{t('demoWithdrawDisclaimer')}</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-amber-300 bg-amber-950/60 border border-amber-500/30 px-2.5 py-1 rounded-lg">
              ZERO CASH VALUE
            </span>
          </div>

          {/* Rewards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {DEMO_WITHDRAWAL_REWARDS.map((reward) => {
              const canAfford = user.points >= reward.epCost;
              return (
                <div
                  key={reward.id}
                  className={`p-5 rounded-3xl border transition-all flex flex-col justify-between gap-4 ${
                    canAfford
                      ? 'bg-[#0c1830] border-[#162c57] hover:border-amber-400/50'
                      : 'bg-[#091224]/70 border-[#122345] opacity-75'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-3xl">{reward.icon}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#081224] text-slate-400 border border-[#14264b]">
                        {reward.deliveryTime}
                      </span>
                    </div>

                    <h4 className="font-display font-extrabold text-lg text-white mt-3">
                      {reward.name}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1">{reward.description}</p>
                  </div>

                  <div className="pt-4 border-t border-[#14264b] flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                        Cost
                      </span>
                      <span className="font-mono font-black text-2xl text-amber-400 tabular-nums">
                        {reward.epCost.toLocaleString()} EP
                      </span>
                    </div>

                    <button
                      onClick={() => handleExecuteWithdrawal(reward)}
                      disabled={!canAfford || isWithdrawing}
                      className={`px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider active:scale-95 transition-all cursor-pointer ${
                        canAfford
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md shadow-amber-400/20'
                          : 'bg-[#122347] text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {canAfford ? 'Redeem Reward' : 'Insufficient EP'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB D: TRANSACTION HISTORY & FULL LEDGER */}
      {activeTab === 'ledger' && (
        <div className="space-y-4">
          {/* Filters & Search */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer ${
                  filterType === 'all'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
                }`}
              >
                {t('filterAll')}
              </button>
              <button
                onClick={() => setFilterType('deposit')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer ${
                  filterType === 'deposit'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
                }`}
              >
                {t('filterDeposits')}
              </button>
              <button
                onClick={() => setFilterType('prediction_stake')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer ${
                  filterType === 'prediction_stake'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
                }`}
              >
                {t('filterStakes')}
              </button>
              <button
                onClick={() => setFilterType('prediction_payout')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer ${
                  filterType === 'prediction_payout'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
                }`}
              >
                {t('filterPayouts')}
              </button>
              <button
                onClick={() => setFilterType('daily_bonus')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer ${
                  filterType === 'daily_bonus'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
                }`}
              >
                {t('filterBonuses')}
              </button>
            </div>

            <div className="relative min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search ledger..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-9 pl-8 pr-3 rounded-xl bg-[#081224] border border-[#162c57] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
              />
            </div>
          </div>

          {/* Ledger Table */}
          <div className="rounded-2xl border border-[#162c57] overflow-hidden bg-[#0c1830]">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#081224] border-b border-[#14264b] text-[11px] uppercase tracking-wider text-slate-400">
                  <tr>
                    <th className="py-3 px-4">{t('txDate')}</th>
                    <th className="py-3 px-4">{t('txReference')}</th>
                    <th className="py-3 px-4">Description</th>
                    <th className="py-3 px-4 text-right">{t('txAmount')}</th>
                    <th className="py-3 px-4 text-right">{t('txBalance')}</th>
                    <th className="py-3 px-4 text-center">{t('txStatus')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#14264b]">
                  {filteredTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-[#0e1d3b] transition-colors">
                      <td className="py-3 px-4 text-slate-400 whitespace-nowrap font-mono text-[11px]">
                        {new Date(tx.timestamp).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                        })}{' '}
                        {new Date(tx.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>

                      <td className="py-3 px-4 font-mono font-medium text-slate-300 whitespace-nowrap">
                        <button
                          onClick={() => copyToClipboard(tx.reference)}
                          className="flex items-center gap-1 hover:text-emerald-400 transition-colors cursor-pointer"
                          title="Copy reference code"
                        >
                          <span>{tx.reference}</span>
                          {copiedRef === tx.reference ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3 text-slate-500" />
                          )}
                        </button>
                      </td>

                      <td className="py-3 px-4 text-white font-medium max-w-xs truncate">
                        {tx.description}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold whitespace-nowrap">
                        <span
                          className={
                            tx.amount > 0 ? 'text-emerald-400' : 'text-slate-300'
                          }
                        >
                          {tx.amount > 0 ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()} EP
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-slate-400 tabular-nums">
                        {tx.balanceAfter.toLocaleString()} EP
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-400 border border-emerald-500/30 text-[10px] font-semibold">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          <span>{t('completed')}</span>
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filteredTransactions.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500 text-xs">
                        No transactions found matching your criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5. Deposit Success Modal */}
      {depositSuccessResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#09152b] border border-emerald-500/50 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-400 flex items-center justify-center mx-auto text-3xl">
              ✓
            </div>
            <div>
              <span className="text-xs uppercase font-bold text-emerald-400 tracking-wider">
                Virtual Refill Approved
              </span>
              <h3 className="font-display font-extrabold text-2xl text-white mt-1">
                +{depositSuccessResult.amount.toLocaleString()} EP Added
              </h3>
              <p className="text-xs text-slate-300 mt-2">
                Your virtual bankroll has been replenished for demonstration play.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#060e1f] border border-[#14264b] text-left text-xs font-mono space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>Ref Code:</span>
                <span className="text-white font-bold">{depositSuccessResult.reference}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Rail:</span>
                <span className="text-emerald-400">Earnova Virtual Sandbox</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>New Balance:</span>
                <span className="text-white font-bold">{(user?.points ?? 0).toLocaleString()} EP</span>
              </div>
            </div>

            <button
              onClick={() => setDepositSuccessResult(null)}
              className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer"
            >
              Back to Wallet
            </button>
          </div>
        </div>
      )}

      {/* 6. Withdrawal Certificate Modal */}
      {withdrawalSuccessResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#09152b] border border-amber-500/50 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-400/50 text-amber-400 flex items-center justify-center mx-auto text-3xl">
              {withdrawalSuccessResult.reward.icon}
            </div>
            <div>
              <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                Virtual Credential Issued
              </span>
              <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white mt-1">
                {withdrawalSuccessResult.reward.name}
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Official demonstration credential. Redeemable in EARNOVA community showcase.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#060e1f] border border-[#14264b] text-left text-xs font-mono space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>Certificate ID:</span>
                <button
                  onClick={() => copyToClipboard(withdrawalSuccessResult.certificateId)}
                  className="text-amber-300 font-bold flex items-center gap-1 hover:underline"
                >
                  <span>{withdrawalSuccessResult.certificateId}</span>
                  <Copy className="w-3 h-3" />
                </button>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Issued To:</span>
                <span className="text-white">{user.username}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Value Stamp:</span>
                <span className="text-emerald-400">ZERO FIAT VALUE</span>
              </div>
            </div>

            <button
              onClick={() => setWithdrawalSuccessResult(null)}
              className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer"
            >
              Close & View Showcase
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
