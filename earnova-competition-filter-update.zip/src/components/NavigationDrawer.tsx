import React from 'react';
import {
  X,
  Home,
  Wallet,
  Trophy,
  Activity,
  Award,
  GraduationCap,
  TrendingUp,
  History,
  MessageSquare,
  Brain,
  Star,
  Bell,
  User,
  ShieldCheck,
  Globe,
  Wifi,
  WifiOff,
  Coins,
  ChevronRight,
  Sparkles,
  RotateCcw,
  Settings,
  ArrowDownLeft,
  ArrowUpRight,
  Plane,
  LogIn,
  LogOut,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface NavigationDrawerProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenNotifications: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  currentTab,
  onSelectTab,
  onOpenNotifications,
}) => {
  const {
    user,
    isNavDrawerOpen,
    setIsNavDrawerOpen,
    language,
    setLanguage,
    lowDataMode,
    toggleLowDataMode,
    refillDemoPoints,
    resetAllDemoData,
    notifications,
    openAuthModal,
    logoutUser,
  } = useEarnova();
  const { t } = useTranslation(language);

  if (!isNavDrawerOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleNav = (tabId: string) => {
    onSelectTab(tabId);
    setIsNavDrawerOpen(false);
  };

  const navGroups = [
    {
      title: 'Core Platform',
      items: [
        { id: 'home', label: t('dashboard'), icon: Home, desc: 'Overview, stats & active slips' },
        { id: 'novaplay', label: 'NovaPlay (Aviator)', icon: Plane, desc: 'Aviator crash flight & virtual arcade games' },
        { id: 'wallet', label: t('wallet'), icon: Wallet, desc: 'Demo refills, rewards & ledger' },
        { id: 'deposit', label: 'Demo Deposit', icon: ArrowDownLeft, desc: 'Free virtual refill packages' },
        { id: 'withdraw', label: 'Demo Withdrawal', icon: ArrowUpRight, desc: 'Educational rewards & certificates' },
        { id: 'matches', label: t('fixtures'), icon: Trophy, desc: 'Upcoming 1X2, Over/Under & BTTS' },
        { id: 'live', label: t('liveCentre'), icon: Activity, desc: 'Live tactical match tracker' },
      ],
    },
    {
      title: 'Competitions & Analytics',
      items: [
        { id: 'ucl', label: t('championsLeague'), icon: Trophy, desc: 'Weekly rankings & group tables' },
        { id: 'academy', label: t('academy'), icon: GraduationCap, desc: 'Theory courses & certified credentials' },
        { id: 'performance', label: t('performance'), icon: TrendingUp, desc: 'Accuracy & yield analytics' },
        { id: 'history', label: t('history'), icon: History, desc: 'All settled & pending predictions' },
      ],
    },
    {
      title: 'Community & Trivia',
      items: [
        { id: 'community', label: t('community'), icon: MessageSquare, desc: 'Discussions & friend duels' },
        { id: 'trivia', label: t('trivia'), icon: Brain, desc: 'Daily football quizzes & +100 EP' },
        { id: 'leaderboard', label: t('ranks'), icon: Award, desc: 'Top predictors & rankings' },
      ],
    },
    {
      title: 'Personal & Account',
      items: [
        { id: 'settings', label: 'Audio & Settings', icon: Settings, desc: 'Volume slider, mute & sound controls' },
        { id: 'favorites', label: t('favoriteClubs'), icon: Star, desc: 'Followed clubs & alert rules' },
        { id: 'profile', label: t('profile'), icon: User, desc: 'Identity, sound & settings' },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex bg-black/80 backdrop-blur-xs animate-in fade-in duration-150">
      {/* Click outside to close */}
      <div
        className="flex-1 cursor-pointer"
        onClick={() => setIsNavDrawerOpen(false)}
      />

      {/* Drawer Body */}
      <div className="w-full max-w-sm sm:max-w-md bg-[#081224] border-l border-[#162c57] h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200 overflow-hidden">
        {/* Top Drawer Header with User Card */}
        <div className="p-5 border-b border-[#14264b] bg-gradient-to-br from-[#0c1a36] to-[#071329] space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500 text-slate-950 font-black flex items-center justify-center text-sm shadow-sm">
                E
              </div>
              <span className="font-display font-extrabold text-lg text-white">
                EARNOVA
              </span>
            </div>

            <button
              onClick={() => setIsNavDrawerOpen(false)}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-[#122347] transition-colors cursor-pointer"
              aria-label="Close menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* User Mini Profile or Sign In Card */}
          {user.isLoggedIn !== false && user.email ? (
            <div className="p-3.5 rounded-2xl bg-[#060e1e]/90 border border-[#14264b] flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => handleNav('profile')}
                className="flex items-center gap-3 min-w-0 text-left cursor-pointer group touch-manipulation"
                title="View Profile Settings"
              >
                <div className="w-11 h-11 rounded-xl bg-[#0f2142] border border-emerald-500/40 flex items-center justify-center text-2xl shrink-0 group-hover:scale-105 transition-transform">
                  {user.avatar}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-sm text-white group-hover:text-emerald-400 transition-colors truncate">
                      {user.fullName || user.username}
                    </h4>
                    <span className="text-[10px] font-semibold px-2 py-0.2 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/40 shrink-0">
                      {user.tier}
                    </span>
                  </div>
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      handleNav('wallet');
                    }}
                    className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5 hover:text-emerald-300 transition-colors"
                  >
                    <Coins className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="font-mono font-bold text-white tabular-nums">
                      {(user?.points ?? 0).toLocaleString()} EP
                    </span>
                    <span className="text-[10px] text-emerald-400 underline ml-0.5">Wallet →</span>
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={refillDemoPoints}
                title="Quick +1,000 EP Refill"
                className="p-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase shrink-0 transition-colors cursor-pointer touch-manipulation active:scale-95"
              >
                + Refill
              </button>
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/40 flex items-center justify-between gap-3">
              <div>
                <h4 className="font-bold text-sm text-white">Join Earnova</h4>
                <p className="text-[11px] text-amber-200">Sign in or register for +2,500 EP</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsNavDrawerOpen(false);
                  openAuthModal('login');
                }}
                className="px-3.5 py-1.5 rounded-xl bg-yellow-400 text-slate-950 font-bold text-xs uppercase cursor-pointer shadow-sm hover:scale-105 transition-transform"
              >
                Sign In
              </button>
            </div>
          )}
        </div>

        {/* Scrollable Navigation Groups */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {navGroups.map((group) => (
            <div key={group.title} className="space-y-1.5">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 px-3">
                {group.title}
              </span>

              <div className="space-y-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNav(item.id)}
                      className={`w-full p-2.5 rounded-2xl text-left flex items-center justify-between gap-3 transition-all cursor-pointer ${
                        isActive
                          ? 'bg-emerald-500/20 border border-emerald-400/50 text-white font-bold'
                          : 'hover:bg-[#0c1830] text-slate-300 hover:text-white border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                            isActive
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-[#0f1f3d] text-emerald-400'
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <span className="text-xs font-semibold block truncate">
                            {item.label}
                          </span>
                          <span className="text-[10px] text-slate-400 block truncate">
                            {item.desc}
                          </span>
                        </div>
                      </div>

                      <ChevronRight className="w-4 h-4 text-slate-600 shrink-0" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Quick Notifications Trigger in Drawer */}
          <div className="pt-2">
            <button
              onClick={() => {
                setIsNavDrawerOpen(false);
                onOpenNotifications();
              }}
              className="w-full p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] flex items-center justify-between hover:border-[#1e3e78] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#0f1f3d] text-emerald-400 flex items-center justify-center">
                  <Bell className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-bold text-white block">
                    Alerts & Notifications
                  </span>
                  <span className="text-[10px] text-slate-400 block">
                    {unreadCount > 0 ? `${unreadCount} unread match events` : 'All caught up'}
                  </span>
                </div>
              </div>

              {unreadCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-bold text-[10px]">
                  {unreadCount} NEW
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Bottom Drawer Actions */}
        <div className="p-4 border-t border-[#14264b] bg-[#070e1c] space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-2">
            {/* Language Switch */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'sw' : 'en')}
              className="py-2 px-3 rounded-xl bg-[#0c1830] border border-[#162c57] text-slate-300 hover:text-white flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-bold text-[11px] uppercase">
                {language === 'en' ? 'Swahili' : 'English'}
              </span>
            </button>

            {/* Low Data Mode */}
            <button
              onClick={toggleLowDataMode}
              className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-1.5 cursor-pointer ${
                lowDataMode
                  ? 'bg-amber-950/50 border-amber-500/50 text-amber-300 font-bold'
                  : 'bg-[#0c1830] border-[#162c57] text-slate-300 hover:text-white'
              }`}
            >
              {lowDataMode ? <WifiOff className="w-3.5 h-3.5 text-amber-400" /> : <Wifi className="w-3.5 h-3.5" />}
              <span className="text-[11px]">{lowDataMode ? 'Saver ON' : 'Data Saver'}</span>
            </button>
          </div>

          {/* User Sign In / Logout Button */}
          {user.isLoggedIn !== false && user.email ? (
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Are you sure you want to sign out of Earnova?')) {
                  logoutUser();
                  setIsNavDrawerOpen(false);
                }
              }}
              className="w-full py-2.5 px-3 rounded-xl bg-rose-950/40 hover:bg-rose-950/70 border border-rose-500/40 text-rose-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out ({user.username})</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setIsNavDrawerOpen(false);
                openAuthModal('login');
              }}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md hover:brightness-110 transition-all"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign In / Create Account</span>
            </button>
          )}

          {/* Reset Demo Data Button */}
          <button
            onClick={() => {
              if (window.confirm('Reset all demo balances, predictions and records back to initial factory demo state?')) {
                resetAllDemoData();
                setIsNavDrawerOpen(false);
              }
            }}
            className="w-full py-1.5 text-slate-500 hover:text-slate-300 text-[11px] flex items-center justify-center gap-1 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Factory Demo State</span>
          </button>
        </div>
      </div>
    </div>
  );
};
