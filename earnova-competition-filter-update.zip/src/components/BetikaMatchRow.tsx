import React, { useState } from 'react';
import { Brain, SlidersHorizontal, Star, Activity, ChevronRight, Sparkles, ChevronDown } from 'lucide-react';
import { Match } from '../types';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface BetikaMatchRowProps {
  match: Match;
  featured?: boolean;
  selectedMarketFilter?: '1X2' | 'O/U' | 'GG/NG' | 'DC';
}

export const BetikaMatchRow: React.FC<BetikaMatchRowProps> = ({
  match,
  featured,
  selectedMarketFilter = '1X2',
}) => {
  const {
    togglePick,
    isSelectionActive,
    setSelectedMarketsMatch,
    setSelectedMatchDetail,
    setSelectedIntelligenceMatch,
    favoriteTeamIds,
    toggleFavoriteTeam,
    language,
  } = useEarnova();
  const { t } = useTranslation(language);

  const [showExtraMarkets, setShowExtraMarkets] = useState(false);

  // 1X2 selections
  const handlePick1X2 = (
    key: 'home' | 'draw' | 'away',
    label: string,
    odds: number,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    togglePick({
      matchId: match.id,
      matchTitle: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
      marketType: 'matchResult',
      marketName: 'Match Result (1X2)',
      selectionKey: key,
      selectionLabel: label,
      odds,
    });
  };

  // Over/Under selections
  const handlePickOU = (
    key: 'over25' | 'under25',
    label: string,
    odds: number,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    togglePick({
      matchId: match.id,
      matchTitle: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
      marketType: 'overUnder',
      marketName: 'Over/Under 2.5 Goals',
      selectionKey: key,
      selectionLabel: label,
      odds,
    });
  };

  // BTTS selections
  const handlePickBTTS = (
    key: 'yes' | 'no',
    label: string,
    odds: number,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    togglePick({
      matchId: match.id,
      matchTitle: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
      marketType: 'btts',
      marketName: 'Both Teams to Score',
      selectionKey: key,
      selectionLabel: label,
      odds,
    });
  };

  // Double Chance selections
  const handlePickDC = (
    key: 'homeDraw' | 'homeAway' | 'drawAway',
    label: string,
    odds: number,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    togglePick({
      matchId: match.id,
      matchTitle: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
      marketType: 'doubleChance',
      marketName: 'Double Chance',
      selectionKey: key,
      selectionLabel: label,
      odds,
    });
  };

  const isHomeSelected = isSelectionActive(match.id, 'home');
  const isDrawSelected = isSelectionActive(match.id, 'draw');
  const isAwaySelected = isSelectionActive(match.id, 'away');

  const isOverSelected = isSelectionActive(match.id, 'over25');
  const isUnderSelected = isSelectionActive(match.id, 'under25');
  const isBttsYesSelected = isSelectionActive(match.id, 'yes');
  const isBttsNoSelected = isSelectionActive(match.id, 'no');
  const is1XSelected = isSelectionActive(match.id, 'homeDraw');
  const isX2Selected = isSelectionActive(match.id, 'drawAway');

  const isLive = match.status === 'live';
  const isFinished = match.status === 'finished';

  const isHomeFav = favoriteTeamIds.includes(match.homeTeam.id);
  const isAwayFav = favoriteTeamIds.includes(match.awayTeam.id);

  // Short ID for Betika style
  const matchCode = match.id.replace('match-', 'ID: 4');

  return (
    <div
      className={`rounded-2xl border transition-all duration-150 bg-[#0c1830] hover:border-[#1e3b70] shadow-sm ${
        featured ? 'border-emerald-500/40' : 'border-[#14264b]'
      }`}
    >
      {/* 1. Header: League name & Match time above each match */}
      <div className="px-3 py-2 flex items-center justify-between border-b border-[#14264b]/80 text-[11px] text-slate-400 bg-[#091326]/60 rounded-t-2xl">
        <div className="flex items-center gap-1.5 truncate min-w-0">
          <span className="font-semibold text-slate-200 truncate uppercase tracking-tight text-[10.5px]">
            {match.leagueName}
          </span>
          <span className="text-slate-600">·</span>
          {isLive ? (
            <span className="flex items-center gap-1 text-emerald-400 font-bold font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>{match.minute}&apos; LIVE</span>
            </span>
          ) : isFinished ? (
            <span className="text-slate-400 font-medium">FT</span>
          ) : (
            <span className="font-mono text-slate-300 font-medium">{match.startTime}</span>
          )}
          <span className="text-slate-600 hidden sm:inline">·</span>
          <span className="text-slate-500 font-mono text-[10px] hidden sm:inline">
            {matchCode}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* AI Match Intelligence button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedIntelligenceMatch(match);
            }}
            className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 hover:text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 px-1.5 py-0.5 rounded-md border border-emerald-500/30 transition-colors cursor-pointer touch-manipulation"
            title="Earnova AI Match Intelligence"
          >
            <Brain className="w-3 h-3 text-emerald-400" />
            <span className="hidden xs:inline">AI Intel</span>
          </button>

          {/* More Markets trigger */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedMarketsMatch(match);
            }}
            className="text-[10px] font-semibold text-slate-400 hover:text-white flex items-center gap-0.5 cursor-pointer touch-manipulation hover:underline"
          >
            <span>+42 Markets</span>
            <ChevronRight className="w-3 h-3 text-emerald-400" />
          </button>
        </div>
      </div>

      {/* 2. Main Match Row: Home & Away teams on Left, 3 rounded prediction buttons (1, X, 2) on Right */}
      <div className="p-3 flex items-center justify-between gap-3">
        {/* Left Side: Home and Away teams */}
        <div
          onClick={() => setSelectedMatchDetail(match)}
          className="flex-1 min-w-0 cursor-pointer group pr-2"
          title="Click to view match tracker, stats & lineup"
        >
          {/* Home Team */}
          <div className="flex items-center justify-between gap-2 py-0.5">
            <div className="flex items-center gap-2 min-w-0">
              <span
                className="w-5 h-5 rounded-md flex items-center justify-center text-[11px] shrink-0 font-bold text-slate-900"
                style={{ backgroundColor: match.homeTeam.crestBg || '#10b981' }}
              >
                {match.homeTeam.crestIcon || match.homeTeam.name.charAt(0)}
              </span>
              <span className="text-xs sm:text-sm font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                {match.homeTeam.name}
              </span>
              {isHomeFav && <Star className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />}
            </div>
            {(isLive || isFinished) && (
              <span className="font-mono font-black text-sm text-white tabular-nums shrink-0">
                {match.homeScore}
              </span>
            )}
          </div>

          {/* Away Team */}
          <div className="flex items-center justify-between gap-2 py-0.5 mt-1">
            <div className="flex items-center gap-2 min-w-0">
              <span
                className="w-5 h-5 rounded-md flex items-center justify-center text-[11px] shrink-0 font-bold text-slate-900"
                style={{ backgroundColor: match.awayTeam.crestBg || '#3b82f6' }}
              >
                {match.awayTeam.crestIcon || match.awayTeam.name.charAt(0)}
              </span>
              <span className="text-xs sm:text-sm font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                {match.awayTeam.name}
              </span>
              {isAwayFav && <Star className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />}
            </div>
            {(isLive || isFinished) && (
              <span className="font-mono font-black text-sm text-white tabular-nums shrink-0">
                {match.awayScore}
              </span>
            )}
          </div>
        </div>

        {/* Right Side: Three rounded prediction/odds buttons (1, X, 2) aligned horizontally */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Button 1 (Home Win) */}
          <button
            type="button"
            onClick={(e) =>
              handlePick1X2('home', `${match.homeTeam.shortName} (1)`, match.odds.matchResult.home, e)
            }
            className={`w-14 sm:w-16 h-12 rounded-xl flex flex-col items-center justify-center border transition-all cursor-pointer touch-manipulation active:scale-95 ${
              isHomeSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-black shadow-md shadow-emerald-500/20'
                : 'bg-[#102143] border-[#1b3463] text-slate-200 hover:border-emerald-500/50 hover:bg-[#142852]'
            }`}
          >
            <span
              className={`text-[10px] font-bold uppercase leading-none ${
                isHomeSelected ? 'text-slate-950' : 'text-slate-400'
              }`}
            >
              1
            </span>
            <span className="font-mono font-bold text-xs sm:text-sm tabular-nums mt-0.5 leading-none">
              {match.odds.matchResult.home.toFixed(2)}
            </span>
          </button>

          {/* Button X (Draw) */}
          <button
            type="button"
            onClick={(e) =>
              handlePick1X2('draw', 'Draw (X)', match.odds.matchResult.draw, e)
            }
            className={`w-14 sm:w-16 h-12 rounded-xl flex flex-col items-center justify-center border transition-all cursor-pointer touch-manipulation active:scale-95 ${
              isDrawSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-black shadow-md shadow-emerald-500/20'
                : 'bg-[#102143] border-[#1b3463] text-slate-200 hover:border-emerald-500/50 hover:bg-[#142852]'
            }`}
          >
            <span
              className={`text-[10px] font-bold uppercase leading-none ${
                isDrawSelected ? 'text-slate-950' : 'text-slate-400'
              }`}
            >
              X
            </span>
            <span className="font-mono font-bold text-xs sm:text-sm tabular-nums mt-0.5 leading-none">
              {match.odds.matchResult.draw.toFixed(2)}
            </span>
          </button>

          {/* Button 2 (Away Win) */}
          <button
            type="button"
            onClick={(e) =>
              handlePick1X2('away', `${match.awayTeam.shortName} (2)`, match.odds.matchResult.away, e)
            }
            className={`w-14 sm:w-16 h-12 rounded-xl flex flex-col items-center justify-center border transition-all cursor-pointer touch-manipulation active:scale-95 ${
              isAwaySelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-black shadow-md shadow-emerald-500/20'
                : 'bg-[#102143] border-[#1b3463] text-slate-200 hover:border-emerald-500/50 hover:bg-[#142852]'
            }`}
          >
            <span
              className={`text-[10px] font-bold uppercase leading-none ${
                isAwaySelected ? 'text-slate-950' : 'text-slate-400'
              }`}
            >
              2
            </span>
            <span className="font-mono font-bold text-xs sm:text-sm tabular-nums mt-0.5 leading-none">
              {match.odds.matchResult.away.toFixed(2)}
            </span>
          </button>
        </div>
      </div>

      {/* 3. Additional markets displayed underneath each match */}
      <div className="px-3 pb-2.5 pt-1 border-t border-[#14264b]/60 flex items-center justify-between gap-1.5 overflow-x-auto text-[11px]">
        <div className="flex items-center gap-1.5">
          {/* Over 2.5 quick pill */}
          <button
            type="button"
            onClick={(e) =>
              handlePickOU('over25', 'Over 2.5 Goals', match.odds.overUnder.over25, e)
            }
            className={`px-2 py-1 rounded-lg border text-[10px] font-mono whitespace-nowrap transition-all cursor-pointer touch-manipulation ${
              isOverSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                : 'bg-[#09152b] border-[#152a52] text-slate-300 hover:text-white hover:border-[#223d74]'
            }`}
          >
            <span>O 2.5: </span>
            <strong className="text-emerald-400 ml-0.5 font-bold">
              {match.odds.overUnder.over25.toFixed(2)}
            </strong>
          </button>

          {/* Under 2.5 quick pill */}
          <button
            type="button"
            onClick={(e) =>
              handlePickOU('under25', 'Under 2.5 Goals', match.odds.overUnder.under25, e)
            }
            className={`px-2 py-1 rounded-lg border text-[10px] font-mono whitespace-nowrap transition-all cursor-pointer touch-manipulation ${
              isUnderSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                : 'bg-[#09152b] border-[#152a52] text-slate-300 hover:text-white hover:border-[#223d74]'
            }`}
          >
            <span>U 2.5: </span>
            <strong className="text-emerald-400 ml-0.5 font-bold">
              {match.odds.overUnder.under25.toFixed(2)}
            </strong>
          </button>

          {/* GG (BTTS Yes) quick pill */}
          <button
            type="button"
            onClick={(e) =>
              handlePickBTTS('yes', 'Both Teams Score (Yes)', match.odds.btts.yes, e)
            }
            className={`px-2 py-1 rounded-lg border text-[10px] font-mono whitespace-nowrap transition-all cursor-pointer touch-manipulation ${
              isBttsYesSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                : 'bg-[#09152b] border-[#152a52] text-slate-300 hover:text-white hover:border-[#223d74]'
            }`}
          >
            <span>GG: </span>
            <strong className="text-emerald-400 ml-0.5 font-bold">
              {match.odds.btts.yes.toFixed(2)}
            </strong>
          </button>

          {/* 1X (Double Chance) quick pill */}
          <button
            type="button"
            onClick={(e) =>
              handlePickDC('homeDraw', '1X Double Chance', match.odds.doubleChance.homeDraw, e)
            }
            className={`px-2 py-1 rounded-lg border text-[10px] font-mono whitespace-nowrap transition-all cursor-pointer touch-manipulation ${
              is1XSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                : 'bg-[#09152b] border-[#152a52] text-slate-300 hover:text-white hover:border-[#223d74]'
            }`}
          >
            <span>1X: </span>
            <strong className="text-emerald-400 ml-0.5 font-bold">
              {match.odds.doubleChance.homeDraw.toFixed(2)}
            </strong>
          </button>
        </div>

        {/* Favorite team toggle on right */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleFavoriteTeam(match.homeTeam.id);
          }}
          className="p-1 text-slate-500 hover:text-amber-400 transition-colors cursor-pointer shrink-0"
          title="Follow Home Team"
        >
          <Star className={`w-3.5 h-3.5 ${isHomeFav ? 'fill-amber-400 text-amber-400' : ''}`} />
        </button>
      </div>
    </div>
  );
};
