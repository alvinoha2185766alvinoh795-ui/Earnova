import React, { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  ArrowRight,
  Award,
  Shield,
  Lock,
  ExternalLink,
  Copy,
  Check,
  X,
  FileCheck2,
  Crown,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { AcademyLesson, AcademyCertificationBadge } from '../types';
import { useTranslation } from '../utils/i18n';

export const AcademyView: React.FC = () => {
  const { academyLessons, completeAcademyLesson, user, language } = useEarnova();
  const { t } = useTranslation(language);

  const [activeTab, setActiveTab] = useState<'modules' | 'badges'>('modules');
  const [selectedLesson, setSelectedLesson] = useState<AcademyLesson>(academyLessons[0]);
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  // Certificate Modal state
  const [inspectingBadge, setInspectingBadge] = useState<{
    badge: AcademyCertificationBadge;
    moduleNumber: number;
    moduleTitle: string;
    completed: boolean;
  } | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const isSw = language === 'sw';
  const completedLessons = academyLessons.filter((l) => l.completed);
  const completedCount = completedLessons.length;
  const isMasterQualified = completedCount === academyLessons.length;

  const handleSelectLesson = (l: AcademyLesson) => {
    setSelectedLesson(l);
    setQuizAnswer(null);
    setQuizSubmitted(false);
  };

  const handleQuizSubmit = () => {
    if (quizAnswer === null) return;
    setQuizSubmitted(true);
    if (quizAnswer === selectedLesson.quiz.correctIndex) {
      completeAcademyLesson(selectedLesson.id);
    }
  };

  const handleCopyCode = (code: string) => {
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Academy Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0b2044] via-[#0d2a57] to-[#0a1833] border border-emerald-500/30 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-3xl shadow-xl shadow-emerald-950/40">
              🎓
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                <Sparkles className="w-4 h-4" />
                <span>EARNOVA TACTICAL MASTERCLASSES</span>
              </div>
              <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white mt-0.5">
                {t('predictionAcademy')}
              </h1>
              <p className="text-xs text-slate-300 mt-1">
                {t('interactiveLessons')}
              </p>
            </div>
          </div>

          <div className="bg-[#081326]/80 p-3.5 rounded-2xl border border-[#162f5e] text-xs">
            <span className="text-slate-400 block text-[11px]">Curriculum & Badges</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <strong className="font-mono text-lg text-emerald-400 font-bold tabular-nums">
                {completedCount} / {academyLessons.length}
              </strong>
              <span className="text-slate-400 text-[11px]">Certifications Earned</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Tabs (Theory Modules vs Earned Certification Badges) */}
      <div className="flex items-center gap-2 p-1 bg-[#0c1830] rounded-2xl border border-[#162c57] w-fit">
        <button
          onClick={() => setActiveTab('modules')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'modules'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>{t('courseModules')} ({academyLessons.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('badges')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'badges'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>{t('certificationBadges')} ({completedCount})</span>
        </button>
      </div>

      {/* VIEW 1: THEORY MODULES & QUIZ */}
      {activeTab === 'modules' && (
        <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6">
          {/* Module Nav Cards */}
          <div className="space-y-3">
            <h3 className="font-display font-bold text-sm text-white px-1">
              Curriculum Lessons
            </h3>
            {academyLessons.map((lesson) => {
              const isCurrent = lesson.id === selectedLesson.id;
              const badge = lesson.certificateBadge;

              return (
                <button
                  key={lesson.id}
                  onClick={() => handleSelectLesson(lesson)}
                  className={`w-full p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                    isCurrent
                      ? 'bg-emerald-500/10 border-emerald-400 text-white shadow-lg shadow-emerald-950/30'
                      : 'bg-[#0c1830] border-[#162c57] text-slate-300 hover:border-[#1e3b74]'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-mono font-bold text-emerald-400">
                      Module {lesson.moduleNumber}
                    </span>
                    {lesson.completed ? (
                      <span className="flex items-center gap-1 text-emerald-400 font-semibold text-[10px]">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Certified
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-slate-400 text-[10px]">
                        <Lock className="w-3 h-3" />
                        Badge Locked
                      </span>
                    )}
                  </div>

                  <h4 className="font-semibold text-xs text-white line-clamp-2">
                    {isSw ? lesson.titleSw : lesson.titleEn}
                  </h4>

                  {/* Badge Preview */}
                  <div className="mt-2.5 pt-2 border-t border-[#14264b] flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-1.5 text-slate-300 truncate">
                      <span className="text-base">{badge.icon}</span>
                      <span className="truncate text-[10px] text-slate-400">
                        {isSw ? badge.nameSw : badge.nameEn}
                      </span>
                    </div>
                    <span className="font-mono text-amber-400 text-[10px] shrink-0 font-bold">
                      +{lesson.rewardEP} EP
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected Lesson Interactive Content & Quiz */}
          <div className="p-6 sm:p-7 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-6">
            {/* Lesson Header */}
            <div className="border-b border-[#14264b] pb-4">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                  Module {selectedLesson.moduleNumber} Masterclass
                </span>
                {/* Associated Certification Badge Pill */}
                <button
                  onClick={() =>
                    setInspectingBadge({
                      badge: selectedLesson.certificateBadge,
                      moduleNumber: selectedLesson.moduleNumber,
                      moduleTitle: isSw ? selectedLesson.titleSw : selectedLesson.titleEn,
                      completed: selectedLesson.completed,
                    })
                  }
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#081224] border border-[#162c57] hover:border-emerald-500/50 text-xs text-slate-300 transition-colors cursor-pointer"
                >
                  <span className="text-sm">{selectedLesson.certificateBadge.icon}</span>
                  <span className="text-[11px] font-semibold text-emerald-400">
                    {t('viewCredential')}
                  </span>
                </button>
              </div>

              <h2 className="font-display font-extrabold text-xl sm:text-2xl text-white mt-1.5">
                {isSw ? selectedLesson.titleSw : selectedLesson.titleEn}
              </h2>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                {isSw ? selectedLesson.descriptionSw : selectedLesson.descriptionEn}
              </p>
            </div>

            {/* Lesson Notes */}
            <div className="space-y-3">
              <h4 className="font-bold text-xs uppercase tracking-wider text-slate-400">
                Core Tactical Principles
              </h4>
              <div className="space-y-2.5">
                {(isSw ? selectedLesson.contentSw : selectedLesson.contentEn).map((point, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-[#081224] border border-[#14264b] text-xs text-slate-200 leading-relaxed flex items-start gap-3"
                  >
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{point}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Associated Badge Preview Callout */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0d2247] to-[#081329] border border-emerald-500/30 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-2xl shadow-inner shrink-0">
                  {selectedLesson.certificateBadge.icon}
                </div>
                <div>
                  <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">
                    Associated Credential Badge
                  </span>
                  <h4 className="font-semibold text-sm text-white">
                    {isSw ? selectedLesson.certificateBadge.nameSw : selectedLesson.certificateBadge.nameEn}
                  </h4>
                  <span className="text-[11px] text-slate-400">
                    {isSw ? selectedLesson.certificateBadge.tierSw : selectedLesson.certificateBadge.tierEn}
                  </span>
                </div>
              </div>

              <div className="text-right shrink-0">
                {selectedLesson.completed ? (
                  <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-500/30">
                    ✓ Badge Earned
                  </span>
                ) : (
                  <span className="text-[11px] font-medium text-slate-400 bg-[#0c1830] px-2.5 py-1 rounded-full border border-[#14264b]">
                    Pass Quiz to Unlock
                  </span>
                )}
              </div>
            </div>

            {/* Interactive Quiz Assessment */}
            <div className="pt-4 border-t border-[#14264b] space-y-4">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-emerald-400" />
                <h3 className="font-display font-bold text-sm text-white">
                  Interactive Knowledge Quiz (+{selectedLesson.rewardEP} EP)
                </h3>
              </div>

              <p className="text-xs text-slate-200 font-medium">
                {isSw ? selectedLesson.quiz.questionSw : selectedLesson.quiz.questionEn}
              </p>

              {/* Quiz Options */}
              <div className="space-y-2">
                {(isSw ? selectedLesson.quiz.optionsSw : selectedLesson.quiz.optionsEn).map((opt, idx) => {
                  const isSelected = quizAnswer === idx;
                  const isCorrect = idx === selectedLesson.quiz.correctIndex;
                  const showResults = quizSubmitted;

                  let optClass = 'bg-[#081224] border-[#162b54] text-slate-200 hover:border-emerald-500/50';
                  if (isSelected) {
                    optClass = 'bg-emerald-500/10 border-emerald-400 text-white';
                  }
                  if (showResults) {
                    if (isCorrect) {
                      optClass = 'bg-emerald-950/60 border-emerald-400 text-emerald-200 font-bold';
                    } else if (isSelected && !isCorrect) {
                      optClass = 'bg-rose-950/60 border-rose-500 text-rose-200';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      disabled={quizSubmitted}
                      onClick={() => setQuizAnswer(idx)}
                      className={`w-full p-3.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between cursor-pointer ${optClass}`}
                    >
                      <span>{opt}</span>
                      {showResults && isCorrect && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Quiz Feedback message */}
              {quizSubmitted && (
                <div
                  className={`p-4 rounded-2xl border text-xs leading-relaxed ${
                    quizAnswer === selectedLesson.quiz.correctIndex
                      ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/50 border-rose-500/40 text-rose-300'
                  }`}
                >
                  <strong className="block text-sm mb-1">
                    {quizAnswer === selectedLesson.quiz.correctIndex
                      ? '✓ Assessment Passed & Certification Badge Awarded!'
                      : '✗ Incorrect selection'}
                  </strong>
                  <p>{isSw ? selectedLesson.quiz.explanationSw : selectedLesson.quiz.explanationEn}</p>
                </div>
              )}

              {/* Quiz action button */}
              {!quizSubmitted ? (
                <button
                  onClick={handleQuizSubmit}
                  disabled={quizAnswer === null}
                  className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-bold text-xs tracking-wide shadow-md transition-all cursor-pointer"
                >
                  Submit Quiz & Earn Certification
                </button>
              ) : (
                <div className="flex items-center justify-between text-xs text-slate-400 pt-2">
                  <span>
                    {quizAnswer === selectedLesson.quiz.correctIndex
                      ? `+${selectedLesson.rewardEP} EP and badge added to your credentials.`
                      : 'Review the tactical principles above and try again.'}
                  </span>
                  {quizAnswer !== selectedLesson.quiz.correctIndex && (
                    <button
                      onClick={() => {
                        setQuizSubmitted(false);
                        setQuizAnswer(null);
                      }}
                      className="text-emerald-400 font-semibold hover:underline"
                    >
                      Retry Quiz
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: EARNED CERTIFICATION BADGES SHOWCASE */}
      {activeTab === 'badges' && (
        <div className="space-y-6">
          {/* Master Diploma Banner */}
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#112752] via-[#0d3452] to-[#0a1b38] border-2 border-emerald-400/60 shadow-xl shadow-emerald-950/40 relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-18 h-18 rounded-2xl bg-gradient-to-br from-amber-400/20 to-emerald-400/20 border-2 border-amber-400 flex items-center justify-center text-4xl shadow-xl shadow-amber-950/30 shrink-0">
                  👑
                </div>
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                    <Crown className="w-4 h-4" />
                    <span>HIGHEST ACADEMIC DISTINCTION</span>
                  </div>
                  <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white mt-0.5">
                    {t('masterDiploma')}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl">
                    Conferred upon tacticians who pass all four theoretical modules of the EARNOVA Curriculum. Certified in Implied Probability, Expected Goals (xG), Risk Management, and Offensive Transitions.
                  </p>
                </div>
              </div>

              <div className="text-left sm:text-right shrink-0">
                {isMasterQualified ? (
                  <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-950 text-emerald-300 font-bold text-xs border border-emerald-400 shadow-md">
                    <CheckCircle2 className="w-4 h-4" />
                    Certified Master Tactician
                  </span>
                ) : (
                  <div className="space-y-1">
                    <span className="text-xs font-mono font-bold text-amber-300 block">
                      {completedCount} / {academyLessons.length} Modules Completed
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      Pass remaining modules to unlock diploma
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Grid of Individual Certification Badges */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base text-white">
                Module Competency Certifications
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                {completedCount} of {academyLessons.length} Earned
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {academyLessons.map((lesson) => {
                const badge = lesson.certificateBadge;
                const isEarned = lesson.completed;

                return (
                  <div
                    key={badge.id}
                    className={`p-5 rounded-3xl border transition-all flex flex-col justify-between space-y-4 ${
                      isEarned
                        ? 'bg-gradient-to-br from-[#0c1a36] to-[#09152b] border-emerald-500/40 shadow-lg shadow-emerald-950/20'
                        : 'bg-[#081224]/60 border-[#14264b] opacity-70'
                    }`}
                  >
                    {/* Badge Top Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl border shadow-inner ${
                            isEarned
                              ? 'bg-emerald-500/20 border-emerald-400 text-white'
                              : 'bg-[#0e1d3b] border-slate-700 text-slate-500'
                          }`}
                        >
                          {badge.icon}
                        </div>
                        <div>
                          <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-emerald-400 block">
                            {isSw ? badge.tierSw : badge.tierEn}
                          </span>
                          <h4 className="font-display font-bold text-sm sm:text-base text-white mt-0.5">
                            {isSw ? badge.nameSw : badge.nameEn}
                          </h4>
                          <span className="text-[11px] text-slate-400 block">
                            Module {lesson.moduleNumber}: {isSw ? lesson.titleSw : lesson.titleEn}
                          </span>
                        </div>
                      </div>

                      {/* Status Tag */}
                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full shrink-0 flex items-center gap-1 border ${
                          isEarned
                            ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                            : 'bg-slate-900 text-slate-500 border-slate-800'
                        }`}
                      >
                        {isEarned ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            <span>{t('activeCertified')}</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-3 h-3" />
                            <span>{t('lockedModule')}</span>
                          </>
                        )}
                      </span>
                    </div>

                    {/* Verified Competencies */}
                    <div className="space-y-1.5 pt-1">
                      <span className="text-[10px] font-semibold uppercase text-slate-400 block">
                        {t('verifiedSkills')}:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {(isSw ? badge.skillsSw : badge.skillsEn).map((skill, sIdx) => (
                          <span
                            key={sIdx}
                            className={`text-[10px] px-2 py-0.5 rounded-lg border font-medium ${
                              isEarned
                                ? 'bg-[#0e2142] border-[#183669] text-slate-200'
                                : 'bg-[#0a152a] border-[#122345] text-slate-500'
                            }`}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Certificate Footer / Action */}
                    <div className="pt-3 border-t border-[#14264b] flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 font-mono text-[10px] text-slate-400">
                        <span>ID:</span>
                        <strong className="text-slate-300">{badge.certificateCode}</strong>
                      </div>

                      <button
                        onClick={() =>
                          setInspectingBadge({
                            badge,
                            moduleNumber: lesson.moduleNumber,
                            moduleTitle: isSw ? lesson.titleSw : lesson.titleEn,
                            completed: lesson.completed,
                          })
                        }
                        className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-xl font-semibold text-xs transition-colors cursor-pointer ${
                          isEarned
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold'
                            : 'bg-[#102040] hover:bg-[#162e5c] text-slate-300'
                        }`}
                      >
                        <FileCheck2 className="w-3.5 h-3.5" />
                        <span>{t('viewCredential')}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* CREDENTIAL CERTIFICATE INSPECTOR MODAL */}
      {inspectingBadge && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-[#091326] border-2 border-emerald-500/50 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden relative">
            {/* Certificate Header Bar */}
            <div className="p-4 bg-[#060e1a] border-b border-[#14264b] flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                <Shield className="w-4 h-4" />
                <span>OFFICIAL EARNOVA TACTICAL CREDENTIAL</span>
              </div>
              <button
                onClick={() => setInspectingBadge(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Inner Parchment-like High Tech Certificate Card */}
            <div className="p-6 sm:p-8 space-y-6 bg-gradient-to-b from-[#0c1a36] via-[#09152b] to-[#071022] text-center relative overflow-hidden">
              {/* Watermark subtle seal */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-8xl opacity-5 pointer-events-none select-none">
                {inspectingBadge.badge.icon}
              </div>

              {/* Institution Title */}
              <div className="space-y-1">
                <span className="text-[10px] tracking-widest uppercase font-mono font-bold text-emerald-400 block">
                  {inspectingBadge.badge.issuedBy}
                </span>
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white">
                  Certificate of Tactical Competence
                </h3>
              </div>

              {/* Recipient */}
              <div className="py-2">
                <span className="text-xs text-slate-400 block">This certifies that</span>
                <h4 className="font-display font-black text-2xl sm:text-3xl text-emerald-300 mt-1">
                  {user.username}
                </h4>
                <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
                  has demonstrated rigorous command in football analytical theory and successfully passed the examination for:
                </p>
              </div>

              {/* Qualification Box */}
              <div className="p-4 rounded-2xl bg-[#071020] border border-emerald-500/40 text-center space-y-1 shadow-inner">
                <span className="text-2xl block">{inspectingBadge.badge.icon}</span>
                <h5 className="font-display font-bold text-base sm:text-lg text-white">
                  {isSw ? inspectingBadge.badge.nameSw : inspectingBadge.badge.nameEn}
                </h5>
                <span className="text-xs text-emerald-400 font-mono font-medium block">
                  {isSw ? inspectingBadge.badge.tierSw : inspectingBadge.badge.tierEn} · Module {inspectingBadge.moduleNumber}
                </span>
              </div>

              {/* Competencies Verified */}
              <div className="space-y-1.5 text-xs text-left max-w-md mx-auto">
                <span className="text-[11px] font-semibold uppercase text-slate-400 block text-center">
                  Demonstrated Competencies:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(isSw ? inspectingBadge.badge.skillsSw : inspectingBadge.badge.skillsEn).map(
                    (skill, idx) => (
                      <div
                        key={idx}
                        className="p-2 rounded-lg bg-[#0e1d3b] border border-[#182f5c] text-[11px] text-slate-200 flex items-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="truncate">{skill}</span>
                      </div>
                    )
                  )}
                </div>
              </div>

              {/* Credential ID and Copy Bar */}
              <div className="pt-4 border-t border-[#14264b] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="text-left font-mono">
                  <span className="text-[10px] text-slate-400 block">{t('credentialCode')}</span>
                  <span className="text-white font-bold">{inspectingBadge.badge.certificateCode}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopyCode(inspectingBadge.badge.certificateCode)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0f2144] hover:bg-[#152e5e] text-xs font-semibold text-emerald-300 border border-emerald-500/30 transition-colors cursor-pointer"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode ? 'Copied!' : 'Copy Credential'}</span>
                  </button>

                  <button
                    onClick={() => setInspectingBadge(null)}
                    className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
