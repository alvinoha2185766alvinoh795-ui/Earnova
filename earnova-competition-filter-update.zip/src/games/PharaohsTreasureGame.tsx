import React, { useState, useEffect } from 'react';
import {
  RotateCcw,
  Trophy,
  Coins,
  Sparkles,
  ArrowLeft,
  Volume2,
  VolumeX,
  ShieldAlert,
  Flame,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type TileReward = 'scarab' | 'ankh' | 'eye' | 'mask' | 'coins' | 'lapis';

interface CryptTile {
  id: number;
  revealed: boolean;
  reward: TileReward;
  points: number;
}

const REWARDS: Record<TileReward, { icon: string; name: string; desc: string; pot: 'ra' | 'osiris' | 'anubis' }> = {
  scarab: { icon: '🪲', name: 'Golden Scarab', desc: '+150 EP & Charges Ra Multiplier', pot: 'ra' },
  ankh: { icon: '☥', name: 'Ankh of Eternity', desc: '+2 Bonus Tomb Picks', pot: 'osiris' },
  eye: { icon: '𓂀', name: 'Eye of Horus', desc: 'Divine Sight +100 EP', pot: 'anubis' },
  mask: { icon: '👑', name: "Pharaoh's Gold Mask", desc: '5x Grand Relic +300 EP', pot: 'anubis' },
  coins: { icon: '🪙', name: 'Nile Gold Urn', desc: '+60 EP Virtual Coins', pot: 'ra' },
  lapis: { icon: '💎', name: 'Royal Lapis Gem', desc: '+80 EP Sacred Jewel', pot: 'osiris' },
};

const createCryptTiles = (): CryptTile[] => {
  const pool: { reward: TileReward; points: number }[] = [
    { reward: 'mask', points: 300 },
    { reward: 'scarab', points: 150 },
    { reward: 'scarab', points: 150 },
    { reward: 'ankh', points: 50 },
    { reward: 'ankh', points: 50 },
    { reward: 'eye', points: 100 },
    { reward: 'eye', points: 100 },
    { reward: 'coins', points: 60 },
    { reward: 'coins', points: 60 },
    { reward: 'coins', points: 60 },
    { reward: 'lapis', points: 80 },
    { reward: 'lapis', points: 80 },
    { reward: 'scarab', points: 150 },
    { reward: 'coins', points: 60 },
    { reward: 'eye', points: 100 },
    { reward: 'lapis', points: 80 },
  ];

  // Shuffle pool
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }

  return pool.map((item, idx) => ({
    id: idx,
    revealed: false,
    reward: item.reward,
    points: item.points,
  }));
};

interface PharaohsTreasureGameProps {
  onBack?: () => void;
}

export const PharaohsTreasureGame: React.FC<PharaohsTreasureGameProps> = ({ onBack }) => {
  const { user, updateUser } = useEarnova();
  const [tiles, setTiles] = useState<CryptTile[]>(() => createCryptTiles());
  const [picksLeft, setPicksLeft] = useState<number>(6);
  const [potRa, setPotRa] = useState<number>(1); // Multiplier: 1x to 5x
  const [potOsiris, setPotOsiris] = useState<number>(0); // Bonus picks
  const [potAnubis, setPotAnubis] = useState<number>(0); // Progress to 100%
  const [roundEarnings, setRoundEarnings] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [roundComplete, setRoundComplete] = useState<boolean>(false);
  const [lastDiscovered, setLastDiscovered] = useState<string | null>(null);

  const handleTileClick = (index: number) => {
    if (roundComplete || picksLeft <= 0 || tiles[index].revealed) return;

    if (soundEnabled) sound.playTap();

    const clicked = tiles[index];
    const rewardInfo = REWARDS[clicked.reward];
    let addedPoints = clicked.points * potRa;
    let extraPicks = 0;

    // Process relic effects
    if (clicked.reward === 'scarab') {
      setPotRa((prev) => Math.min(5, prev + 1));
    } else if (clicked.reward === 'ankh') {
      extraPicks += 2;
      setPotOsiris((prev) => prev + 1);
    } else if (clicked.reward === 'mask' || clicked.reward === 'eye') {
      setPotAnubis((prev) => {
        const next = prev + 35;
        if (next >= 100) {
          confetti({ particleCount: 80, spread: 80 });
          addedPoints += 500;
        }
        return Math.min(100, next);
      });
    }

    if (soundEnabled) sound.playWin();

    setLastDiscovered(`${rewardInfo.icon} Discovered ${rewardInfo.name}! (+${addedPoints} EP)`);

    // Update tiles
    const newTiles = tiles.map((t, idx) => (idx === index ? { ...t, revealed: true } : t));
    setTiles(newTiles);

    const newRoundEarnings = roundEarnings + addedPoints;
    setRoundEarnings(newRoundEarnings);
    updateUser({ points: user.points + addedPoints });

    const newPicks = picksLeft - 1 + extraPicks;
    setPicksLeft(newPicks);

    if (newPicks <= 0) {
      setRoundComplete(true);
      confetti({ particleCount: 50, spread: 60 });
      if (soundEnabled) sound.playBonus();
    }
  };

  const handleReset = () => {
    setTiles(createCryptTiles());
    setPicksLeft(6);
    setPotRa(1);
    setPotOsiris(0);
    setPotAnubis(0);
    setRoundEarnings(0);
    setRoundComplete(false);
    setLastDiscovered(null);
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* Header bar */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/50">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🏺</span>
              <h2 className="font-display font-black text-lg sm:text-xl text-yellow-300 tracking-tight">
                Pharaoh's Treasure
              </h2>
            </div>
            <p className="text-[11px] text-amber-300/80 font-mono">
              3 Pots of Egypt Mystery Crypt · Virtual EP Only
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* The 3 Sacred Urns of Egypt */}
      <div className="grid grid-cols-3 gap-2">
        {/* Urn of Ra */}
        <div className="p-3 rounded-2xl bg-gradient-to-b from-[#2a1b05] to-[#140c02] border border-amber-500/50 text-center relative overflow-hidden shadow-lg">
          <span className="text-2xl sm:text-3xl block animate-bounce" style={{ animationDuration: '3s' }}>
            🏺
          </span>
          <span className="font-display font-black text-xs text-yellow-300 uppercase block mt-1">
            Urn of Ra
          </span>
          <span className="text-[10px] text-amber-400 font-mono font-bold block">
            {potRa}x Multiplier
          </span>
          <span className="text-[8.5px] text-slate-400 block">Scarab Charged</span>
        </div>

        {/* Urn of Osiris */}
        <div className="p-3 rounded-2xl bg-gradient-to-b from-[#0c2618] to-[#04120a] border border-emerald-500/50 text-center relative overflow-hidden shadow-lg">
          <span className="text-2xl sm:text-3xl block animate-bounce" style={{ animationDuration: '2.5s' }}>
            🏺
          </span>
          <span className="font-display font-black text-xs text-emerald-300 uppercase block mt-1">
            Urn of Osiris
          </span>
          <span className="text-[10px] text-emerald-400 font-mono font-bold block">
            +{potOsiris * 2} Bonus Picks
          </span>
          <span className="text-[8.5px] text-slate-400 block">Ankh of Life</span>
        </div>

        {/* Urn of Anubis */}
        <div className="p-3 rounded-2xl bg-gradient-to-b from-[#121c3b] to-[#060a17] border border-sky-500/50 text-center relative overflow-hidden shadow-lg">
          <span className="text-2xl sm:text-3xl block animate-bounce" style={{ animationDuration: '3.5s' }}>
            🏺
          </span>
          <span className="font-display font-black text-xs text-sky-300 uppercase block mt-1">
            Urn of Anubis
          </span>
          <span className="text-[10px] text-sky-400 font-mono font-bold block">
            {potAnubis}% Jackpot
          </span>
          <span className="text-[8.5px] text-slate-400 block">Pharaoh's Chamber</span>
        </div>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-[#09152b] border border-amber-500/30">
        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Picks Remaining</span>
          <span
            className={`font-mono font-black text-xl tabular-nums ${
              picksLeft <= 2 ? 'text-rose-400 animate-pulse' : 'text-white'
            }`}
          >
            {picksLeft}
          </span>
        </div>
        <div className="text-center border-x border-[#162c57]">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Tomb Loot</span>
          <span className="font-mono font-black text-xl text-yellow-300 tabular-nums">
            +{roundEarnings.toLocaleString()}
          </span>
        </div>
        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Virtual Balance</span>
          <span className="font-mono font-black text-base text-emerald-400 tabular-nums">
            {(user?.points ?? 0).toLocaleString()} EP
          </span>
        </div>
      </div>

      {/* 4x4 Crypt Tablets Grid */}
      <div className="relative p-3.5 rounded-3xl bg-gradient-to-b from-[#1a1306] to-[#0d0902] border-2 border-amber-600/70 shadow-2xl">
        <div className="grid grid-cols-4 gap-2 sm:gap-2.5 max-w-[380px] mx-auto">
          {tiles.map((tile, idx) => {
            const reward = REWARDS[tile.reward];
            return (
              <button
                key={tile.id}
                type="button"
                onClick={() => handleTileClick(idx)}
                disabled={tile.revealed || picksLeft <= 0}
                className={`aspect-square rounded-2xl flex flex-col items-center justify-center p-1.5 transition-all duration-200 transform cursor-pointer select-none border-2 ${
                  tile.revealed
                    ? 'bg-gradient-to-b from-[#2e2007] to-[#170f03] border-amber-400 scale-95 shadow-inner'
                    : 'bg-gradient-to-b from-[#422c0b] via-[#332208] to-[#1c1203] border-amber-600 hover:border-yellow-400 hover:scale-105 active:scale-95 shadow-lg'
                }`}
              >
                {tile.revealed ? (
                  <>
                    <span className="text-2xl sm:text-3xl filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] animate-scale-in">
                      {reward.icon}
                    </span>
                    <span className="text-[9px] font-mono font-bold text-yellow-300 mt-1 truncate">
                      +{tile.points * potRa}
                    </span>
                  </>
                ) : (
                  <>
                    <span className="text-lg opacity-40 text-amber-300 font-serif">𓂀</span>
                    <span className="text-[9px] font-bold text-amber-400/80 uppercase tracking-tighter mt-0.5">
                      SEAL #{idx + 1}
                    </span>
                  </>
                )}
              </button>
            );
          })}
        </div>

        {/* Round Complete Modal */}
        {roundComplete && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center p-6 text-center z-20 animate-fade-in">
            <span className="text-5xl mb-2 animate-bounce">🏺</span>
            <h3 className="font-display font-black text-2xl text-yellow-300">
              PHARAOH'S TOMB EXCAVATED!
            </h3>
            <p className="text-xs text-slate-300 mt-1 max-w-xs">
              You uncovered ancient treasures and gained{' '}
              <strong className="text-emerald-400 font-mono text-sm">+{roundEarnings} EP</strong> virtual demo reward!
            </p>
            <button
              type="button"
              onClick={handleReset}
              className="mt-4 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg hover:scale-105 active:scale-95 transition-all"
            >
              Enter New Crypt
            </button>
          </div>
        )}
      </div>

      {lastDiscovered && (
        <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-center text-xs font-semibold text-yellow-300 animate-fade-in">
          {lastDiscovered}
        </div>
      )}
    </div>
  );
};
