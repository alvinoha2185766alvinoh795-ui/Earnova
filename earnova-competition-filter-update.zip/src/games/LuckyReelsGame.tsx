import React, { useState, useRef } from 'react';
import { Sparkles, Trophy, Coins, RotateCcw, CheckCircle2 } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

interface SymbolItem {
  icon: string;
  name: string;
  multiplier: number;
}

const SYMBOLS: SymbolItem[] = [
  { icon: '7️⃣', name: 'Emerald 7', multiplier: 25 },
  { icon: '🏆', name: 'Champions Trophy', multiplier: 15 },
  { icon: '💎', name: 'Diamond', multiplier: 10 },
  { icon: '⚽', name: 'Golden Ball', multiplier: 8 },
  { icon: '🍀', name: 'Lucky Clover', multiplier: 5 },
  { icon: '🔔', name: 'Tactical Whistle', multiplier: 3 },
];

export const LuckyReelsGame: React.FC = () => {
  const { user, updateUser, refillDemoPoints } = useEarnova();

  const [reel1, setReel1] = useState<string>('7️⃣');
  const [reel2, setReel2] = useState<string>('7️⃣');
  const [reel3, setReel3] = useState<string>('7️⃣');
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [bet, setBet] = useState<number>(50);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [winMessage, setWinMessage] = useState<string | null>(null);

  const spinIntervalRef = useRef<number | null>(null);

  const handleSpin = () => {
    if (isSpinning) return;
    if (user.points < bet) {
      alert('Insufficient virtual points. Use demo refill to top up EP.');
      return;
    }

    sound.playTap();
    // Deduct bet
    updateUser({ points: Math.max(0, user.points - bet) });
    setIsSpinning(true);
    setLastWin(null);
    setWinMessage(null);

    // Continuous rolling animation
    let tickCount = 0;
    spinIntervalRef.current = window.setInterval(() => {
      tickCount++;
      sound.playSpinTick();
      setReel1(SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].icon);
      setReel2(SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].icon);
      setReel3(SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].icon);
    }, 80);

    // Stop Reel 1 after 800ms
    setTimeout(() => {
      const s1 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].icon;
      setReel1(s1);
    }, 800);

    // Stop Reel 2 after 1300ms
    setTimeout(() => {
      const s2 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].icon;
      setReel2(s2);
    }, 1300);

    // Stop Reel 3 after 1800ms & resolve
    setTimeout(() => {
      if (spinIntervalRef.current) clearInterval(spinIntervalRef.current);
      const finalS1 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
      // 30% chance to match for exciting gameplay
      const matchRand = Math.random();
      let finalS2 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
      let finalS3 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];

      if (matchRand < 0.28) {
        // Full 3-of-a-kind!
        finalS2 = finalS1;
        finalS3 = finalS1;
      } else if (matchRand < 0.55) {
        // 2-of-a-kind
        finalS2 = finalS1;
      }

      setReel1(finalS1.icon);
      setReel2(finalS2.icon);
      setReel3(finalS3.icon);
      setIsSpinning(false);

      if (finalS1.icon === finalS2.icon && finalS2.icon === finalS3.icon) {
        // Jackpot!
        const winAmount = bet * finalS1.multiplier;
        sound.playCashout();
        setLastWin(winAmount);
        setWinMessage(`JACKPOT! 3x ${finalS1.name} (${finalS1.multiplier}x)`);
        updateUser({ points: user.points - bet + winAmount });
      } else if (finalS1.icon === finalS2.icon || finalS2.icon === finalS3.icon) {
        // Partial pair match
        const winAmount = Math.round(bet * 1.5);
        sound.playCashout();
        setLastWin(winAmount);
        setWinMessage(`PAIR MATCH (+${winAmount} EP)`);
        updateUser({ points: user.points - bet + winAmount });
      } else {
        sound.playCrash();
        setLastWin(0);
      }
    }, 1800);
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Header */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Lucky Reels 3-Reel Slots</span>
        </div>
        <h2 className="font-display font-black text-2xl text-white">Lucky Reels</h2>
        <p className="text-xs text-slate-400">Match 3 symbols across the reels for up to 25x multipliers!</p>
      </div>

      {/* 3-Reel Cabinet */}
      <div className="p-6 rounded-3xl bg-gradient-to-b from-[#0e1d3b] to-[#071126] border-2 border-emerald-500/40 shadow-2xl space-y-4">
        {/* Payline indicator line */}
        <div className="relative flex items-center justify-center gap-3 py-6 px-2 rounded-2xl bg-[#040a17] border border-[#14264b] overflow-hidden">
          {/* Neon center payline */}
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-emerald-400/30 pointer-events-none" />

          {/* Reel 1 */}
          <div className="flex-1 aspect-square rounded-2xl bg-[#0a1730] border-2 border-[#1c386e] flex items-center justify-center text-4xl sm:text-5xl shadow-inner select-none transition-transform">
            <span>{reel1}</span>
          </div>

          {/* Reel 2 */}
          <div className="flex-1 aspect-square rounded-2xl bg-[#0a1730] border-2 border-[#1c386e] flex items-center justify-center text-4xl sm:text-5xl shadow-inner select-none transition-transform">
            <span>{reel2}</span>
          </div>

          {/* Reel 3 */}
          <div className="flex-1 aspect-square rounded-2xl bg-[#0a1730] border-2 border-[#1c386e] flex items-center justify-center text-4xl sm:text-5xl shadow-inner select-none transition-transform">
            <span>{reel3}</span>
          </div>
        </div>

        {/* Win Banner */}
        {lastWin !== null && !isSpinning && (
          <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-400 text-center animate-in zoom-in-95 duration-150">
            {lastWin > 0 ? (
              <div>
                <span className="text-xs font-bold text-emerald-400 block">{winMessage}</span>
                <span className="font-display font-black text-xl text-white">+{lastWin} EP WON</span>
              </div>
            ) : (
              <span className="text-xs text-slate-400">Try again for the 3x 7s Jackpot!</span>
            )}
          </div>
        )}

        {/* Stake Controls */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between text-xs text-slate-300">
            <span>Bet Stake:</span>
            <span className="font-mono text-emerald-400 font-bold">{(user?.points ?? 0).toLocaleString()} EP Bankroll</span>
          </div>

          <div className="flex items-center gap-2">
            {[25, 50, 100, 250].map((amt) => (
              <button
                key={amt}
                type="button"
                disabled={isSpinning}
                onClick={() => setBet(amt)}
                className={`flex-1 py-2.5 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                  bet === amt
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                    : 'bg-[#060e1d] border-[#162c57] text-slate-300 hover:text-white'
                }`}
              >
                {amt}
              </button>
            ))}
          </div>

          {/* Spin Button */}
          <button
            type="button"
            onClick={handleSpin}
            disabled={isSpinning || user.points < bet}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-emerald-500 hover:brightness-110 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-emerald-500/25 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            {isSpinning ? 'REELS SPINNING...' : `PULL REELS (${bet} EP)`}
          </button>
        </div>
      </div>

      {/* Paytable Preview */}
      <div className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] text-xs">
        <div className="flex items-center justify-between text-[11px] text-slate-400 pb-1.5 border-b border-[#14264b]">
          <span className="font-bold text-white">Paytable (3 of a kind)</span>
          <span>Multiplier</span>
        </div>
        <div className="grid grid-cols-3 gap-2 pt-2 text-[11px] font-mono">
          {SYMBOLS.map((s) => (
            <div key={s.name} className="flex items-center justify-between px-2 py-1 rounded-lg bg-[#081224]">
              <span>{s.icon}</span>
              <span className="font-bold text-emerald-400">{s.multiplier}x</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
