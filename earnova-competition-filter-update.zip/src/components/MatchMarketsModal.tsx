import React, { useState } from 'react';
import { X, Check, Info } from 'lucide-react';
import { Match, MarketType } from '../types';
import { useEarnova } from '../context/EarnovaContext';

interface MatchMarketsModalProps {
  match: Match;
  onClose: () => void;
}

export const MatchMarketsModal: React.FC<MatchMarketsModalProps> = ({ match, onClose }) => {
  const { togglePick, isSelectionActive } = useEarnova();
  const [activeTab, setActiveTab] = useState<MarketType>('doubleChance');

  const handleSelect = (
    marketType: MarketType,
    marketName: string,
    key: string,
    label: string,
    odds: number
  ) => {
    togglePick({
      matchId: match.id,
      matchTitle: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
      marketType,
      marketName,
      selectionKey: key,
      selectionLabel: label,
      odds,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="bg-[#0a1529] border border-[#1a3363] rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#14264b] bg-[#070e1d] flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>{match.leagueName}</span>
              <span aria-hidden="true">·</span>
              <span>{match.startTime}</span>
            </div>
            <h3 className="font-display font-bold text-lg text-white mt-0.5">
              {match.homeTeam.name} vs {match.awayTeam.name}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-[#122245] transition-colors"
            aria-label="Close markets"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Market Category Selector Tabs (Segmented controls) */}
        <div className="p-2 sm:px-4 bg-[#0a1324] border-b border-[#14264b] overflow-x-auto">
          <div className="flex items-center gap-1.5 min-w-max">
            <button
              onClick={() => setActiveTab('matchResult')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'matchResult'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-[#122347]'
              }`}
            >
              1X2 Match Result
            </button>
            <button
              onClick={() => setActiveTab('doubleChance')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'doubleChance'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-[#122347]'
              }`}
            >
              Double Chance
            </button>
            <button
              onClick={() => setActiveTab('overUnder')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'overUnder'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-[#122347]'
              }`}
            >
              Over / Under Goals
            </button>
            <button
              onClick={() => setActiveTab('btts')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'btts'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-[#122347]'
              }`}
            >
              Both Teams to Score
            </button>
            <button
              onClick={() => setActiveTab('correctScore')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'correctScore'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-[#122347]'
              }`}
            >
              Correct Score
            </button>
          </div>
        </div>

        {/* Market Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: MATCH RESULT */}
          {activeTab === 'matchResult' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-semibold text-slate-200">Full Time Match Result</span>
                <span>Select who will win or draw</span>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() =>
                    handleSelect(
                      'matchResult',
                      'Match Result',
                      'home',
                      `${match.homeTeam.name} (Home)`,
                      match.odds.matchResult.home
                    )
                  }
                  className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'home')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <span className="block text-xs font-medium opacity-80">1 (Home)</span>
                  <span className="block font-bold text-sm truncate mt-0.5">{match.homeTeam.shortName}</span>
                  <span className="block font-mono font-bold text-base mt-2 tabular-nums">
                    {match.odds.matchResult.home.toFixed(2)}x
                  </span>
                </button>

                <button
                  onClick={() =>
                    handleSelect(
                      'matchResult',
                      'Match Result',
                      'draw',
                      'Draw (X)',
                      match.odds.matchResult.draw
                    )
                  }
                  className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'draw')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <span className="block text-xs font-medium opacity-80">X</span>
                  <span className="block font-bold text-sm mt-0.5">Draw</span>
                  <span className="block font-mono font-bold text-base mt-2 tabular-nums">
                    {match.odds.matchResult.draw.toFixed(2)}x
                  </span>
                </button>

                <button
                  onClick={() =>
                    handleSelect(
                      'matchResult',
                      'Match Result',
                      'away',
                      `${match.awayTeam.name} (Away)`,
                      match.odds.matchResult.away
                    )
                  }
                  className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'away')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <span className="block text-xs font-medium opacity-80">2 (Away)</span>
                  <span className="block font-bold text-sm truncate mt-0.5">{match.awayTeam.shortName}</span>
                  <span className="block font-mono font-bold text-base mt-2 tabular-nums">
                    {match.odds.matchResult.away.toFixed(2)}x
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: DOUBLE CHANCE */}
          {activeTab === 'doubleChance' && (
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Info className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Covers two out of three possible match outcomes</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* 1X */}
                <button
                  onClick={() =>
                    handleSelect(
                      'doubleChance',
                      'Double Chance',
                      'homeDraw',
                      `1X (${match.homeTeam.shortName} or Draw)`,
                      match.odds.doubleChance.homeDraw
                    )
                  }
                  className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'homeDraw')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm">1X</span>
                    <span className="font-mono font-bold text-base tabular-nums">
                      {match.odds.doubleChance.homeDraw.toFixed(2)}x
                    </span>
                  </div>
                  <p className="text-xs opacity-80 mt-1 truncate">
                    {match.homeTeam.shortName} Win or Draw
                  </p>
                </button>

                {/* 12 */}
                <button
                  onClick={() =>
                    handleSelect(
                      'doubleChance',
                      'Double Chance',
                      'homeAway',
                      `12 (${match.homeTeam.shortName} or ${match.awayTeam.shortName})`,
                      match.odds.doubleChance.homeAway
                    )
                  }
                  className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'homeAway')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm">12</span>
                    <span className="font-mono font-bold text-base tabular-nums">
                      {match.odds.doubleChance.homeAway.toFixed(2)}x
                    </span>
                  </div>
                  <p className="text-xs opacity-80 mt-1 truncate">
                    Either Team Wins (No Draw)
                  </p>
                </button>

                {/* X2 */}
                <button
                  onClick={() =>
                    handleSelect(
                      'doubleChance',
                      'Double Chance',
                      'drawAway',
                      `X2 (Draw or ${match.awayTeam.shortName})`,
                      match.odds.doubleChance.drawAway
                    )
                  }
                  className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'drawAway')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm">X2</span>
                    <span className="font-mono font-bold text-base tabular-nums">
                      {match.odds.doubleChance.drawAway.toFixed(2)}x
                    </span>
                  </div>
                  <p className="text-xs opacity-80 mt-1 truncate">
                    Draw or {match.awayTeam.shortName} Win
                  </p>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: OVER / UNDER GOALS */}
          {activeTab === 'overUnder' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400">
                Predict the aggregate total goals scored by both teams at 90 minutes.
              </p>

              {/* Over/Under 1.5 */}
              <div className="p-4 rounded-2xl bg-[#0d1a33] border border-[#162a52] space-y-2.5">
                <span className="text-xs font-semibold text-slate-300">Total Goals: 1.5 Line</span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() =>
                      handleSelect('overUnder', 'Over / Under 1.5', 'over15', 'Over 1.5 Goals', match.odds.overUnder.over15)
                    }
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isSelectionActive(match.id, 'over15')
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                        : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/60'
                    }`}
                  >
                    <span className="text-xs">Over 1.5 (2+ goals)</span>
                    <span className="font-mono font-bold text-sm tabular-nums">
                      {match.odds.overUnder.over15.toFixed(2)}x
                    </span>
                  </button>
                  <button
                    onClick={() =>
                      handleSelect('overUnder', 'Over / Under 1.5', 'under15', 'Under 1.5 Goals', match.odds.overUnder.under15)
                    }
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isSelectionActive(match.id, 'under15')
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                        : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/60'
                    }`}
                  >
                    <span className="text-xs">Under 1.5 (0-1 goals)</span>
                    <span className="font-mono font-bold text-sm tabular-nums">
                      {match.odds.overUnder.under15.toFixed(2)}x
                    </span>
                  </button>
                </div>
              </div>

              {/* Over/Under 2.5 */}
              <div className="p-4 rounded-2xl bg-[#0d1a33] border border-[#162a52] space-y-2.5">
                <span className="text-xs font-semibold text-slate-300">Total Goals: 2.5 Line (Most Popular)</span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() =>
                      handleSelect('overUnder', 'Over / Under 2.5', 'over25', 'Over 2.5 Goals', match.odds.overUnder.over25)
                    }
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isSelectionActive(match.id, 'over25')
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                        : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/60'
                    }`}
                  >
                    <span className="text-xs">Over 2.5 (3+ goals)</span>
                    <span className="font-mono font-bold text-sm tabular-nums">
                      {match.odds.overUnder.over25.toFixed(2)}x
                    </span>
                  </button>
                  <button
                    onClick={() =>
                      handleSelect('overUnder', 'Over / Under 2.5', 'under25', 'Under 2.5 Goals', match.odds.overUnder.under25)
                    }
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isSelectionActive(match.id, 'under25')
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                        : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/60'
                    }`}
                  >
                    <span className="text-xs">Under 2.5 (0-2 goals)</span>
                    <span className="font-mono font-bold text-sm tabular-nums">
                      {match.odds.overUnder.under25.toFixed(2)}x
                    </span>
                  </button>
                </div>
              </div>

              {/* Over/Under 3.5 */}
              <div className="p-4 rounded-2xl bg-[#0d1a33] border border-[#162a52] space-y-2.5">
                <span className="text-xs font-semibold text-slate-300">Total Goals: 3.5 Line</span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() =>
                      handleSelect('overUnder', 'Over / Under 3.5', 'over35', 'Over 3.5 Goals', match.odds.overUnder.over35)
                    }
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isSelectionActive(match.id, 'over35')
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                        : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/60'
                    }`}
                  >
                    <span className="text-xs">Over 3.5 (4+ goals)</span>
                    <span className="font-mono font-bold text-sm tabular-nums">
                      {match.odds.overUnder.over35.toFixed(2)}x
                    </span>
                  </button>
                  <button
                    onClick={() =>
                      handleSelect('overUnder', 'Over / Under 3.5', 'under35', 'Under 3.5 Goals', match.odds.overUnder.under35)
                    }
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isSelectionActive(match.id, 'under35')
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                        : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/60'
                    }`}
                  >
                    <span className="text-xs">Under 3.5 (0-3 goals)</span>
                    <span className="font-mono font-bold text-sm tabular-nums">
                      {match.odds.overUnder.under35.toFixed(2)}x
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: BOTH TEAMS TO SCORE (BTTS) */}
          {activeTab === 'btts' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Will both teams score at least one goal each during regular play?
              </p>
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() =>
                    handleSelect(
                      'btts',
                      'Both Teams to Score',
                      'yes',
                      'BTTS: Yes (Both Score)',
                      match.odds.btts.yes
                    )
                  }
                  className={`p-4 rounded-2xl border text-center transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'yes')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <span className="block font-bold text-sm">YES</span>
                  <span className="block text-xs opacity-75 mt-0.5">Both teams find the net</span>
                  <span className="block font-mono font-bold text-lg mt-2 tabular-nums">
                    {match.odds.btts.yes.toFixed(2)}x
                  </span>
                </button>

                <button
                  onClick={() =>
                    handleSelect(
                      'btts',
                      'Both Teams to Score',
                      'no',
                      'BTTS: No (Clean Sheet)',
                      match.odds.btts.no
                    )
                  }
                  className={`p-4 rounded-2xl border text-center transition-all cursor-pointer ${
                    isSelectionActive(match.id, 'no')
                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20'
                      : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                  }`}
                >
                  <span className="block font-bold text-sm">NO</span>
                  <span className="block text-xs opacity-75 mt-0.5">At least one clean sheet</span>
                  <span className="block font-mono font-bold text-lg mt-2 tabular-nums">
                    {match.odds.btts.no.toFixed(2)}x
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: CORRECT SCORE */}
          {activeTab === 'correctScore' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-semibold text-slate-200">Exact Final Score</span>
                <span className="text-emerald-400 font-medium">High Point Multipliers</span>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
                {Object.entries(match.odds.correctScore).map(([scoreKey, oddValue]) => {
                  const isSelected = isSelectionActive(match.id, scoreKey);
                  return (
                    <button
                      key={scoreKey}
                      onClick={() =>
                        handleSelect(
                          'correctScore',
                          'Correct Score',
                          scoreKey,
                          `Score: ${scoreKey}`,
                          oddValue
                        )
                      }
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                          : 'bg-[#0f1f3d] border-[#1b3464] text-slate-200 hover:border-emerald-500/60 hover:bg-[#142952]'
                      }`}
                    >
                      <span className="block font-mono font-bold text-sm">
                        {scoreKey}
                      </span>
                      <span className="block font-mono text-xs opacity-90 mt-1 tabular-nums">
                        {oddValue.toFixed(2)}x
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#070e1d] border-t border-[#14264b] flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Selected markets are automatically synced with your prediction slip.
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs tracking-wide transition-all shadow-md active:scale-95 cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
