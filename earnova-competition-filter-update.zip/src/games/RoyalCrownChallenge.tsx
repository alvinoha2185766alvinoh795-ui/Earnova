import React, { useState, useEffect } from 'react';
import {
  RotateCcw,
  Trophy,
  Coins,
  Sparkles,
  ArrowLeft,
  Volume2,
  VolumeX,
  Crown,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type RoyalItem = 'crown' | 'sceptre' | 'crest' | 'chalice' | 'ring' | 'tiara' | 'orb' | 'shield';

interface CardItem {
  id: number;
  item: RoyalItem;
  isFlipped: boolean;
  isMatched: boolean;
}

const ROYAL_ITEMS: Record<RoyalItem, { name: string; icon: string; points: number }> = {
  crown: { name: 'Imperial Crown', icon: '👑', points: 100 },
  sceptre: { name: 'Royal Sceptre', icon: '🪄', points: 80 },
  crest: { name: 'Fleur-de-lis Crest', icon: '⚜️', points: 70 },
  chalice: { name: 'Gold Chalice', icon: '🏆', points: 75 },
  ring: { name: 'Signet Ruby Ring', icon: '💍', points: 65 },
  tiara: { name: 'Diamond Tiara', icon: '💎', points: 85 },
  orb: { name: 'Imperial Orb', icon: '🔮', points: 60 },
  shield: { name: 'Knights Shield', icon: '🛡️', points: 50 },
};

const createDeck = (): CardItem[] => {
  const items: RoyalItem[] = ['crown', 'sceptre', 'crest', 'chalice', 'ring', 'tiara', 'orb', 'shield'];
  const deck: CardItem[] = [];

  let id = 0;
  items.forEach((item) => {
    // 2 copies for pairs
    deck.push({ id: id++, item, isFlipped: false, isMatched: false });
    deck.push({ id: id++, item, isFlipped: false, isMatched: false });
  });

  // Shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  return deck;
};

interface RoyalCrownChallengeProps {
  onBack?: () => void;
}

export const RoyalCrownChallenge: React.FC<RoyalCrownChallengeProps> = ({ onBack }) => {
  const { user, updateUser } = useEarnova();
  const [deck, setDeck] = useState<CardItem[]>(() => createDeck());
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [moves, setMoves] = useState<number>(0);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [gameWon, setGameWon] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [earnedReward, setEarnedReward] = useState<number>(0);

  const matchedPairsCount = deck.filter((c) => c.isMatched).length / 2;

  const handleCardClick = (id: number) => {
    if (isLocked) return;
    const card = deck.find((c) => c.id === id);
    if (!card || card.isFlipped || card.isMatched) return;

    if (soundEnabled) sound.playTap();

    const newFlipped = [...flippedCards, id];
    const newDeck = deck.map((c) => (c.id === id ? { ...c, isFlipped: true } : c));
    setDeck(newDeck);
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setMoves((m) => m + 1);
      setIsLocked(true);

      const first = newDeck.find((c) => c.id === newFlipped[0])!;
      const second = newDeck.find((c) => c.id === newFlipped[1])!;

      if (first.item === second.item) {
        // Match!
        setTimeout(() => {
          if (soundEnabled) sound.playWin();
          const newStreak = streak + 1;
          setStreak(newStreak);
          const pointsEarned = ROYAL_ITEMS[first.item].points * newStreak;
          setScore((s) => s + pointsEarned);

          const matchedDeck = newDeck.map((c) =>
            c.id === first.id || c.id === second.id ? { ...c, isMatched: true } : c
          );
          setDeck(matchedDeck);
          setFlippedCards([]);
          setIsLocked(false);

          // Check if all matched
          if (matchedDeck.every((c) => c.isMatched)) {
            setGameWon(true);
            confetti({ particleCount: 80, spread: 80 });
            if (soundEnabled) sound.playBonus();
            const reward = 300;
            setEarnedReward(reward);
            updateUser({ points: user.points + reward });
          }
        }, 500);
      } else {
        // No match
        setTimeout(() => {
          setStreak(0);
          setDeck((d) =>
            d.map((c) => (c.id === first.id || c.id === second.id ? { ...c, isFlipped: false } : c))
          );
          setFlippedCards([]);
          setIsLocked(false);
        }, 900);
      }
    }
  };

  const handleReset = () => {
    setDeck(createDeck());
    setFlippedCards([]);
    setScore(0);
    setStreak(0);
    setMoves(0);
    setIsLocked(false);
    setGameWon(false);
    setEarnedReward(0);
  };

  const getRoyalRank = () => {
    if (matchedPairsCount >= 8) return 'King of Earnova 👑';
    if (matchedPairsCount >= 6) return 'Grand Duke ⚜️';
    if (matchedPairsCount >= 4) return 'Royal Knight ⚔️';
    if (matchedPairsCount >= 2) return 'Noble Baron 🛡️';
    return 'Royal Squire 📜';
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/50">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">👑</span>
              <h2 className="font-display font-black text-lg sm:text-xl text-yellow-300 tracking-tight">
                Royal Crown Challenge
              </h2>
            </div>
            <p className="text-[11px] text-amber-300/80 font-mono">
              Burning Classics Memory Vault · Virtual Demo EP
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-gradient-to-r from-[#240821] via-[#380e34] to-[#110419] border border-amber-500/40 shadow-xl">
        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-amber-400 block">Royal Pairs</span>
          <span className="font-mono font-black text-xl text-yellow-300 tabular-nums">
            {matchedPairsCount} / 8
          </span>
          <span className="text-[9px] text-amber-200/60 block">{getRoyalRank()}</span>
        </div>

        <div className="text-center border-x border-amber-500/30">
          <span className="text-[10px] uppercase font-bold text-amber-400 block">Royal Streak</span>
          <span className="font-mono font-black text-xl text-amber-300 tabular-nums">
            {streak > 0 ? `${streak}x Mult` : '0x'}
          </span>
          <span className="text-[9px] text-slate-400 block">Moves: {moves}</span>
        </div>

        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-amber-400 block">Virtual Balance</span>
          <span className="font-mono font-black text-base text-emerald-400 tabular-nums">
            {(user?.points ?? 0).toLocaleString()} EP
          </span>
          <span className="text-[9px] text-emerald-400 block font-mono">Score: {score}</span>
        </div>
      </div>

      {/* 4x4 Royal Vault Grid */}
      <div className="relative p-3.5 rounded-3xl bg-gradient-to-b from-[#20071e] to-[#0c020b] border-2 border-amber-600/70 shadow-2xl">
        <div className="grid grid-cols-4 gap-2 sm:gap-2.5 max-w-[380px] mx-auto">
          {deck.map((card) => {
            const item = ROYAL_ITEMS[card.item];
            return (
              <button
                key={card.id}
                type="button"
                onClick={() => handleCardClick(card.id)}
                disabled={card.isMatched || card.isFlipped}
                className={`aspect-square rounded-2xl flex flex-col items-center justify-center p-1.5 transition-all duration-300 transform cursor-pointer select-none border-2 ${
                  card.isMatched
                    ? 'bg-gradient-to-b from-amber-600/30 to-purple-950/40 border-yellow-400/80 scale-95 shadow-inner'
                    : card.isFlipped
                    ? 'bg-gradient-to-b from-amber-500 via-rose-700 to-purple-950 border-yellow-300 shadow-xl'
                    : 'bg-gradient-to-b from-[#350d31] to-[#1a0518] border-amber-500/50 hover:border-yellow-300 hover:scale-105 active:scale-95 shadow-lg'
                }`}
              >
                {card.isFlipped || card.isMatched ? (
                  <>
                    <span className="text-2xl sm:text-3xl filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] animate-scale-in">
                      {item.icon}
                    </span>
                    <span className="text-[8.5px] font-mono font-bold text-yellow-300 mt-1 truncate">
                      {item.name}
                    </span>
                  </>
                ) : (
                  <>
                    <span className="text-xl opacity-60 text-amber-400">⚜️</span>
                    <span className="text-[8px] font-bold text-amber-300 uppercase tracking-tighter mt-1">
                      ROYAL
                    </span>
                  </>
                )}
              </button>
            );
          })}
        </div>

        {/* Victory Modal */}
        {gameWon && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center p-6 text-center z-20 animate-fade-in">
            <span className="text-5xl mb-2 animate-bounce">👑</span>
            <h3 className="font-display font-black text-2xl text-yellow-300">
              ROYAL VAULT UNLOCKED!
            </h3>
            <p className="text-xs text-slate-300 mt-1 max-w-xs">
              All 8 royal treasures discovered in {moves} moves! You earned{' '}
              <strong className="text-emerald-400 font-mono text-sm">+{earnedReward} EP</strong> virtual demo reward!
            </p>
            <button
              type="button"
              onClick={handleReset}
              className="mt-4 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg hover:scale-105 active:scale-95 transition-all"
            >
              Play Next Round
            </button>
          </div>
        )}
      </div>

      <div className="p-3 rounded-2xl bg-[#091326] border border-amber-500/30 flex items-center justify-between text-xs text-amber-200">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-400" />
          Flip matching pairs to build Royal Streaks and unlock the Imperial Vault!
        </span>
      </div>
    </div>
  );
};
