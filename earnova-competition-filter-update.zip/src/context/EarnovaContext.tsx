import React, { createContext, useContext, useState, useEffect, useRef, ReactNode, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  Match,
  PredictionSelection,
  PlacedPrediction,
  UserProfile,
  NotificationItem,
  LeaderboardEntry,
  MatchEvent,
  Language,
  CommunityPost,
  FriendChallenge,
  AcademyLesson,
  DailyTriviaQuestion,
  TournamentGroup,
  WalletTransaction,
  DemoDepositPackage,
  DemoWithdrawalReward,
} from '../types';
import {
  INITIAL_MATCHES,
  INITIAL_USER,
  INITIAL_LEADERBOARD,
  INITIAL_PREDICTIONS,
  INITIAL_POSTS,
  INITIAL_CHALLENGES,
  ACADEMY_LESSONS,
  DAILY_TRIVIA_QUESTIONS,
  TOURNAMENT_GROUPS,
  TEAMS,
  INITIAL_TRANSACTIONS,
  DEMO_DEPOSIT_PACKAGES,
  DEMO_WITHDRAWAL_REWARDS,
} from '../data/mockData';
import { sound } from '../utils/sound';
import {
  resolveCurrentAuthUser,
  getRegisteredAccounts,
  saveRegisteredAccounts,
  saveActiveSession,
  hashPassword,
  generateUserId,
  StoredAccount,
} from '../utils/auth';
import { safeStorage } from '../utils/safeStorage';

interface EarnovaContextType {
  matches: Match[];
  slip: PredictionSelection[];
  placedPredictions: PlacedPrediction[];
  user: UserProfile;
  notifications: NotificationItem[];
  activeToast: NotificationItem | null;
  leaderboard: LeaderboardEntry[];
  isSlipOpen: boolean;
  setIsSlipOpen: (open: boolean) => void;
  selectedMatchDetail: Match | null;
  setSelectedMatchDetail: (match: Match | null) => void;
  selectedMarketsMatch: Match | null;
  setSelectedMarketsMatch: (match: Match | null) => void;
  selectedIntelligenceMatch: Match | null;
  setSelectedIntelligenceMatch: (match: Match | null) => void;
  isNotificationCenterOpen: boolean;
  setIsNotificationCenterOpen: (open: boolean) => void;
  isNavDrawerOpen: boolean;
  setIsNavDrawerOpen: (open: boolean) => void;

  // Virtual Wallet & Ledger
  transactions: WalletTransaction[];
  demoDeposit: (packageId: string, customAmount?: number) => { success: boolean; message: string; epAdded: number; reference: string };
  demoWithdraw: (rewardId: string) => { success: boolean; message: string; certificateId?: string; epDeducted: number };

  // Community & Challenges
  communityPosts: CommunityPost[];
  friendChallenges: FriendChallenge[];
  addCommunityPost: (title: string, content: string, tag: 'Prediction' | 'Tactics' | 'Discussion' | 'Debate', matchId?: string) => void;
  likeCommunityPost: (postId: string) => void;
  addCommentToPost: (postId: string, text: string) => void;
  acceptFriendChallenge: (challengeId: string, myPick: string) => void;
  createFriendChallenge: (matchId: string, pick: string, stakeEP: number) => void;

  // Academy & Trivia
  academyLessons: AcademyLesson[];
  completeAcademyLesson: (lessonId: string) => void;
  dailyTrivia: DailyTriviaQuestion[];
  triviaAnswered: boolean;
  triviaCorrect: boolean | null;
  answerTrivia: (selectedIndex: number) => boolean;

  // Weekly Champions League
  tournamentGroups: TournamentGroup[];

  // App Settings & Preferences
  language: Language;
  setLanguage: (lang: Language) => void;
  lowDataMode: boolean;
  toggleLowDataMode: () => void;
  favoriteTeamIds: string[];
  toggleFavoriteTeam: (teamId: string) => void;
  volume: number;
  setVolume: (vol: number) => void;
  playTestSound: () => void;

  // Actions
  togglePick: (selection: PredictionSelection) => void;
  removePick: (matchId: string, selectionKey: string) => void;
  clearSlip: () => void;
  isSelectionActive: (matchId: string, selectionKey: string) => boolean;
  placePrediction: (stake: number, type: 'single' | 'accumulator') => { success: boolean; message: string };
  claimDailyBonus: () => { success: boolean; amount: number };
  refillDemoPoints: () => void;
  updateUser: (updates: Partial<UserProfile>) => void;
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
  dismissToast: () => void;
  simulateLiveStep: (matchId: string) => void;
  fastForwardMatch: (matchId: string) => void;
  resetAllDemoData: () => void;
  // Authentication & User Accounts
  isAuthenticated: boolean;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'register' | 'forgot';
  authPromptReason: string | null;
  openAuthModal: (mode?: 'login' | 'register' | 'forgot', reason?: string) => void;
  closeAuthModal: () => void;
  loginUser: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  registerUser: (fullName: string, username: string, email: string, pass: string, confirmPass: string) => Promise<{ success: boolean; error?: string }>;
  logoutUser: () => void;
  resetPasswordUser: (email: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  requireAuth: (action?: () => void, promptReason?: string) => boolean;
}

const EarnovaContext = createContext<EarnovaContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_USER = 'earnova_user_v3';
const LOCAL_STORAGE_KEY_PREDS = 'earnova_predictions_v3';
const LOCAL_STORAGE_KEY_POSTS = 'earnova_posts_v3';
const LOCAL_STORAGE_KEY_ACADEMY = 'earnova_academy_v3';
const LOCAL_STORAGE_KEY_TRANSACTIONS = 'earnova_transactions_v3';

export const EarnovaProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [matches, setMatches] = useState<Match[]>(() => INITIAL_MATCHES);

  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const authState = resolveCurrentAuthUser();
      const saved = safeStorage.getItem(LOCAL_STORAGE_KEY_USER);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return {
            ...INITIAL_USER,
            ...parsed,
            points: typeof parsed.points === 'number' && !isNaN(parsed.points) ? parsed.points : INITIAL_USER.points,
            badges: Array.isArray(parsed.badges) ? parsed.badges : INITIAL_USER.badges,
            favoriteTeamIds: Array.isArray(parsed.favoriteTeamIds) ? parsed.favoriteTeamIds : INITIAL_USER.favoriteTeamIds,
            uid: authState.user.uid || parsed.uid || 'user_earnova_demo_apex',
            email: authState.user.email || parsed.email || 'alvin@earnova.com',
            fullName: authState.user.fullName || parsed.fullName || 'Alvin Oha',
            isLoggedIn: authState.isLoggedIn !== undefined ? authState.isLoggedIn : true,
          };
        }
      }
      return {
        ...INITIAL_USER,
        ...authState.user,
        points: typeof authState.user?.points === 'number' && !isNaN(authState.user.points) ? authState.user.points : INITIAL_USER.points,
      };
    } catch (err) {
      console.warn('Failed to resolve stored user, using initial user state:', err);
    }
    return INITIAL_USER;
  });

  // Auth Modal state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [authPromptReason, setAuthPromptReason] = useState<string | null>(null);

  const [placedPredictions, setPlacedPredictions] = useState<PlacedPrediction[]>(() => {
    try {
      const saved = safeStorage.getItem(LOCAL_STORAGE_KEY_PREDS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return INITIAL_PREDICTIONS;
  });

  const [transactions, setTransactions] = useState<WalletTransaction[]>(() => {
    try {
      const saved = safeStorage.getItem(LOCAL_STORAGE_KEY_TRANSACTIONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return INITIAL_TRANSACTIONS;
  });

  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>(() => {
    try {
      const saved = safeStorage.getItem(LOCAL_STORAGE_KEY_POSTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return INITIAL_POSTS;
  });

  const [friendChallenges, setFriendChallenges] = useState<FriendChallenge[]>(() => INITIAL_CHALLENGES);

  const [academyLessons, setAcademyLessons] = useState<AcademyLesson[]>(() => {
    try {
      const saved = safeStorage.getItem(LOCAL_STORAGE_KEY_ACADEMY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return ACADEMY_LESSONS;
  });

  const [dailyTrivia] = useState<DailyTriviaQuestion[]>(DAILY_TRIVIA_QUESTIONS);
  const [triviaAnswered, setTriviaAnswered] = useState<boolean>(false);
  const [triviaCorrect, setTriviaCorrect] = useState<boolean | null>(null);

  const [tournamentGroups] = useState<TournamentGroup[]>(TOURNAMENT_GROUPS);

  const [slip, setSlip] = useState<PredictionSelection[]>([]);
  const [isSlipOpen, setIsSlipOpen] = useState<boolean>(false);
  const [isNavDrawerOpen, setIsNavDrawerOpen] = useState<boolean>(false);

  // Modals
  const [selectedMatchDetail, setSelectedMatchDetail] = useState<Match | null>(null);
  const [selectedMarketsMatch, setSelectedMarketsMatch] = useState<Match | null>(null);
  const [selectedIntelligenceMatch, setSelectedIntelligenceMatch] = useState<Match | null>(null);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState<boolean>(false);

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif_welcome',
      type: 'daily_bonus',
      title: 'Welcome to EARNOVA!',
      message: 'Claim your daily 250 EP virtual bonus and test your football tactical foresight.',
      timestamp: Date.now() - 3600 * 1000,
      read: false,
    },
    {
      id: 'notif_kickoff',
      type: 'match_start',
      title: 'European Champions Cup Live',
      message: 'London Titans vs Madrid Royal is in the 2nd half! Check the live tactical tracker.',
      timestamp: Date.now() - 2500 * 1000,
      read: false,
    },
  ]);
  const [activeToast, setActiveToast] = useState<NotificationItem | null>(null);

  const [leaderboard] = useState<LeaderboardEntry[]>(() => INITIAL_LEADERBOARD);

  // Persistence
  useEffect(() => {
    try {
      safeStorage.setItem(LOCAL_STORAGE_KEY_USER, JSON.stringify(user));
      if (user.uid && user.email) {
        const accounts = getRegisteredAccounts();
        const idx = accounts.findIndex((a) => a.uid === user.uid || a.email.toLowerCase() === user.email?.toLowerCase());
        if (idx !== -1) {
          accounts[idx].profile = { ...user };
          saveRegisteredAccounts(accounts);
        }
      }
    } catch {}
  }, [user]);

  useEffect(() => {
    try {
      safeStorage.setItem(LOCAL_STORAGE_KEY_PREDS, JSON.stringify(placedPredictions));
    } catch {}
  }, [placedPredictions]);

  useEffect(() => {
    try {
      safeStorage.setItem(LOCAL_STORAGE_KEY_TRANSACTIONS, JSON.stringify(transactions));
    } catch {}
  }, [transactions]);

  useEffect(() => {
    try {
      safeStorage.setItem(LOCAL_STORAGE_KEY_POSTS, JSON.stringify(communityPosts));
    } catch {}
  }, [communityPosts]);

  useEffect(() => {
    try {
      safeStorage.setItem(LOCAL_STORAGE_KEY_ACADEMY, JSON.stringify(academyLessons));
    } catch {}
  }, [academyLessons]);

  const [volume, setVolumeState] = useState<number>(() => {
    return user.volume !== undefined ? user.volume : sound.getVolume();
  });

  const setVolume = useCallback((val: number) => {
    const clamped = Math.max(0, Math.min(100, Math.round(val)));
    setVolumeState(clamped);
    sound.setVolume(clamped);
    setUser((prev) => {
      const updated = { ...prev, volume: clamped };
      try {
        safeStorage.setItem(LOCAL_STORAGE_KEY_USER, JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  const playTestSound = useCallback(() => {
    sound.playTestTone();
  }, []);

  const triggerNotification = useCallback((notif: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => {
    const newNotif: NotificationItem = {
      ...notif,
      id: 'notif_' + Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev.slice(0, 29)]);
    if (user.notificationsEnabled) {
      setActiveToast(newNotif);
    }
  }, [user.notificationsEnabled]);


  // Authentication Handlers
  const openAuthModal = useCallback((mode: 'login' | 'register' | 'forgot' = 'login', reason?: string) => {
    setAuthModalMode(mode);
    setAuthPromptReason(reason || null);
    setIsAuthModalOpen(true);
  }, []);

  const closeAuthModal = useCallback(() => {
    setIsAuthModalOpen(false);
    setAuthPromptReason(null);
  }, []);

  const requireAuth = useCallback((action?: () => void, promptReason?: string) => {
    if (user.isLoggedIn === false || !user.email) {
      sound.playTap();
      openAuthModal('login', promptReason || 'Please sign in or create an account to access this feature.');
      return false;
    }
    if (action) action();
    return true;
  }, [user.isLoggedIn, user.email, openAuthModal]);

  const loginUser = useCallback(async (emailInput: string, passwordInput: string): Promise<{ success: boolean; error?: string }> => {
    const emailNorm = emailInput.trim().toLowerCase();
    const accounts = getRegisteredAccounts();
    const account = accounts.find((a) => a.email.toLowerCase() === emailNorm || a.username.toLowerCase() === emailNorm);

    if (!account) {
      return { success: false, error: 'No account found with this email or username. Please check your spelling or register.' };
    }

    const inputHash = await hashPassword(passwordInput);
    if (account.passwordHash !== inputHash) {
      return { success: false, error: 'Incorrect password. Please verify and try again or use Forgot Password.' };
    }

    // Login successful
    saveActiveSession({
      uid: account.uid,
      token: `token_${Date.now()}_${Math.random().toString(36).substring(2)}`,
      createdAt: Date.now(),
    });

    const activeProfile: UserProfile = {
      ...account.profile,
      uid: account.uid,
      email: account.email,
      fullName: account.fullName,
      username: account.username,
      isLoggedIn: true,
    };

    setUser(activeProfile);
    sound.playBonus();
    confetti({ particleCount: 60, spread: 60 });
    triggerNotification({
      type: 'daily_bonus',
      title: 'Welcome Back!',
      message: `Signed in as ${account.fullName} (@${account.username}). Your points and predictions are synced.`,
    });

    return { success: true };
  }, [triggerNotification]);

  const registerUser = useCallback(async (
    fullNameInput: string,
    usernameInput: string,
    emailInput: string,
    passwordInput: string,
    confirmPasswordInput: string
  ): Promise<{ success: boolean; error?: string }> => {
    const fullName = fullNameInput.trim();
    const username = usernameInput.trim();
    const email = emailInput.trim().toLowerCase();

    if (!fullName || fullName.length < 2) return { success: false, error: 'Full name must be at least 2 characters.' };
    if (!username || username.length < 3) return { success: false, error: 'Username must be at least 3 characters.' };
    if (!email || !email.includes('@')) return { success: false, error: 'Please enter a valid email address.' };
    if (!passwordInput || passwordInput.length < 6) return { success: false, error: 'Password must be at least 6 characters.' };
    if (passwordInput !== confirmPasswordInput) return { success: false, error: 'Passwords do not match.' };

    const accounts = getRegisteredAccounts();
    if (accounts.some((a) => a.email.toLowerCase() === email)) {
      return { success: false, error: 'An account with this email address already exists. Please sign in instead.' };
    }
    if (accounts.some((a) => a.username.toLowerCase() === username.toLowerCase())) {
      return { success: false, error: 'This username is already taken. Please choose another username.' };
    }

    const passwordHash = await hashPassword(passwordInput);
    const uid = generateUserId();

    const newProfile: UserProfile = {
      ...INITIAL_USER,
      uid,
      email,
      fullName,
      username,
      isLoggedIn: true,
      points: 2500, // Welcome bonus virtual EP
      winStreak: 0,
      longestStreak: 0,
      totalPredictions: 0,
      wonPredictions: 0,
      lostPredictions: 0,
      lastBonusClaim: 0,
    };

    const newAccount: StoredAccount = {
      uid,
      fullName,
      username,
      email,
      passwordHash,
      createdAt: Date.now(),
      profile: newProfile,
    };

    saveRegisteredAccounts([...accounts, newAccount]);
    saveActiveSession({
      uid,
      token: `token_${Date.now()}_${Math.random().toString(36).substring(2)}`,
      createdAt: Date.now(),
    });

    setUser(newProfile);
    sound.playWin();
    confetti({ particleCount: 80, spread: 80 });
    triggerNotification({
      type: 'daily_bonus',
      title: 'Account Created Successfully!',
      message: `Welcome to Earnova, ${fullName}! +2,500 Virtual EP welcome bonus credited to your wallet.`,
    });

    return { success: true };
  }, [triggerNotification]);

  const logoutUser = useCallback(() => {
    sound.playTap();
    saveActiveSession(null);
    setUser({
      ...INITIAL_USER,
      uid: 'guest_' + Date.now(),
      email: '',
      fullName: 'Guest User',
      username: 'Guest',
      isLoggedIn: false,
    });
    triggerNotification({
      type: 'daily_bonus',
      title: 'Logged Out',
      message: 'You have been safely signed out of your Earnova account.',
    });
  }, [triggerNotification]);

  const resetPasswordUser = useCallback(async (emailInput: string, newPasswordInput: string): Promise<{ success: boolean; error?: string }> => {
    const emailNorm = emailInput.trim().toLowerCase();
    const accounts = getRegisteredAccounts();
    const accountIndex = accounts.findIndex((a) => a.email.toLowerCase() === emailNorm);

    if (accountIndex === -1) {
      return { success: false, error: 'No account registered with this email address.' };
    }

    if (!newPasswordInput || newPasswordInput.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters.' };
    }

    const newHash = await hashPassword(newPasswordInput);
    accounts[accountIndex].passwordHash = newHash;
    saveRegisteredAccounts(accounts);
    sound.playBonus();

    triggerNotification({
      type: 'daily_bonus',
      title: 'Password Updated',
      message: 'Your account password has been updated securely. You can now sign in.',
    });

    return { success: true };
  }, [triggerNotification]);

  useEffect(() => {
    sound.setEnabled(user.soundEnabled);
    if (user.volume !== undefined) {
      sound.setVolume(user.volume);
    }
  }, [user.soundEnabled, user.volume]);


  const dismissToast = useCallback(() => {
    setActiveToast(null);
  }, []);

  useEffect(() => {
    if (!activeToast) return;
    const timer = setTimeout(() => {
      setActiveToast(null);
    }, 4500);
    return () => clearTimeout(timer);
  }, [activeToast]);

  // Check and evaluate pending predictions for settled matches
  const checkPredictionsSettlement = useCallback((finishedMatch: Match) => {
    setPlacedPredictions((prevList) => {
      let earnedPointsTotal = 0;
      let wonAny = false;

      const updated = prevList.map((pred) => {
        if (pred.status !== 'pending') return pred;

        const allSettled = pred.selections.every((sel) => {
          if (sel.matchId === finishedMatch.id) return true;
          const other = matches.find((m) => m.id === sel.matchId);
          return other && other.status === 'finished';
        });

        if (!allSettled) return pred;

        let isOverallWon = true;
        const resultDescriptions: string[] = [];

        for (const sel of pred.selections) {
          const m = sel.matchId === finishedMatch.id ? finishedMatch : matches.find((item) => item.id === sel.matchId)!;
          let legWon = false;

          const homeG = m.homeScore;
          const awayG = m.awayScore;
          const totalG = homeG + awayG;

          switch (sel.marketType) {
            case 'matchResult':
              if (sel.selectionKey === 'home' && homeG > awayG) legWon = true;
              else if (sel.selectionKey === 'draw' && homeG === awayG) legWon = true;
              else if (sel.selectionKey === 'away' && awayG > homeG) legWon = true;
              break;
            case 'doubleChance':
              if (sel.selectionKey === 'homeDraw' && homeG >= awayG) legWon = true;
              else if (sel.selectionKey === 'homeAway' && homeG !== awayG) legWon = true;
              else if (sel.selectionKey === 'drawAway' && awayG >= homeG) legWon = true;
              break;
            case 'overUnder':
              if (sel.selectionKey === 'over15' && totalG > 1.5) legWon = true;
              else if (sel.selectionKey === 'under15' && totalG < 1.5) legWon = true;
              else if (sel.selectionKey === 'over25' && totalG > 2.5) legWon = true;
              else if (sel.selectionKey === 'under25' && totalG < 2.5) legWon = true;
              else if (sel.selectionKey === 'over35' && totalG > 3.5) legWon = true;
              else if (sel.selectionKey === 'under35' && totalG < 3.5) legWon = true;
              break;
            case 'btts':
              if (sel.selectionKey === 'yes' && homeG > 0 && awayG > 0) legWon = true;
              else if (sel.selectionKey === 'no' && (homeG === 0 || awayG === 0)) legWon = true;
              break;
            case 'correctScore': {
              const exactScore = `${homeG}-${awayG}`;
              if (sel.selectionKey === exactScore) legWon = true;
              else if (sel.selectionKey === 'Other' && !['1-0', '2-0', '2-1', '3-0', '3-1', '0-0', '1-1', '2-2', '0-1', '0-2', '1-2', '1-3'].includes(exactScore)) {
                legWon = true;
              }
              break;
            }
          }

          if (!legWon) isOverallWon = false;
          resultDescriptions.push(`${m.homeTeam.code} ${homeG}-${awayG} ${m.awayTeam.code}: ${legWon ? '✓ Pass' : '✗ Miss'}`);
        }

        if (isOverallWon) {
          wonAny = true;
          earnedPointsTotal += pred.potentialReturn;
          return {
            ...pred,
            status: 'won' as const,
            settledAt: Date.now(),
            resultDetails: resultDescriptions.join(' · '),
          };
        } else {
          return {
            ...pred,
            status: 'lost' as const,
            settledAt: Date.now(),
            resultDetails: resultDescriptions.join(' · '),
          };
        }
      });

      if (wonAny) {
        sound.playWin();
        if (!user.lowDataMode) {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#10b981', '#34d399', '#6ee7b7', '#38bdf8'],
          });
        }
        triggerNotification({
          type: 'prediction_settled',
          title: 'Prediction Won!',
          message: `Congratulations! Your prediction settled successfully. +${earnedPointsTotal} EP added to your balance.`,
        });

        const payRef = `TX-PAY-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
        setUser((u) => {
          const newPts = u.points + earnedPointsTotal;
          const newStreak = u.winStreak + 1;
          const newWon = u.wonPredictions + 1;
          const longest = Math.max(u.longestStreak, newStreak);
          return {
            ...u,
            points: newPts,
            winStreak: newStreak,
            longestStreak: longest,
            wonPredictions: newWon,
          };
        });

        setTransactions((prev) => [
          {
            id: 'tx_pay_' + Date.now(),
            type: 'prediction_payout',
            amount: earnedPointsTotal,
            description: `Prediction Settled WON (+${earnedPointsTotal} EP Payout)`,
            timestamp: Date.now(),
            status: 'completed',
            reference: payRef,
            balanceAfter: user.points + earnedPointsTotal,
          },
          ...prev,
        ]);
      }

      return updated;
    });
  }, [matches, triggerNotification, user.lowDataMode, user.points]);

  const checkPredictionsSettlementRef = useRef(checkPredictionsSettlement);
  useEffect(() => {
    checkPredictionsSettlementRef.current = checkPredictionsSettlement;
  });

  const triggerNotificationRef = useRef(triggerNotification);
  useEffect(() => {
    triggerNotificationRef.current = triggerNotification;
  });

  // Live timer simulation for matches (slowed down if Low-Data Mode is enabled)
  useEffect(() => {
    const intervalMs = user.lowDataMode ? 14000 : 7000;
    const interval = setInterval(() => {
      setMatches((currentMatches) => {
        let matchFinished: Match | null = null;

        const updated = currentMatches.map((m) => {
          if (m.status !== 'live') return m;

          const nextMinute = m.minute + 1;
          if (nextMinute > 90) {
            const finished: Match = {
              ...m,
              status: 'finished',
              minute: 90,
            };
            matchFinished = finished;
            return finished;
          }

          const rand = Math.random();
          let newEvents = [...m.events];
          let homeScore = m.homeScore;
          let awayScore = m.awayScore;
          let newStats = { ...m.stats };

          // 7% chance of goal
          if (rand < 0.07) {
            const isHome = Math.random() > 0.45;
            if (isHome) {
              homeScore += 1;
              const ev: MatchEvent = {
                id: `ev_${m.id}_${nextMinute}`,
                minute: nextMinute,
                type: 'goal',
                teamId: m.homeTeam.id,
                player: `${m.homeTeam.shortName} Attacker`,
                detail: 'Superb strike into top corner!',
              };
              newEvents = [ev, ...newEvents];
              sound.playGoal();
              triggerNotificationRef.current({
                type: 'goal',
                title: `GOAL! ${m.homeTeam.shortName} scores!`,
                message: `${m.homeTeam.name} ${homeScore} - ${awayScore} ${m.awayTeam.name} (${nextMinute}')`,
                matchId: m.id,
              });
            } else {
              awayScore += 1;
              const ev: MatchEvent = {
                id: `ev_${m.id}_${nextMinute}`,
                minute: nextMinute,
                type: 'goal',
                teamId: m.awayTeam.id,
                player: `${m.awayTeam.shortName} Forward`,
                detail: 'Clinical finish past the goalkeeper!',
              };
              newEvents = [ev, ...newEvents];
              sound.playGoal();
              triggerNotificationRef.current({
                type: 'goal',
                title: `GOAL! ${m.awayTeam.shortName} scores!`,
                message: `${m.homeTeam.name} ${homeScore} - ${awayScore} ${m.awayTeam.name} (${nextMinute}')`,
                matchId: m.id,
              });
            }
          }

          newStats = {
            ...newStats,
            totalShots: [
              newStats.totalShots[0] + (Math.random() > 0.7 ? 1 : 0),
              newStats.totalShots[1] + (Math.random() > 0.7 ? 1 : 0),
            ],
            corners: [
              newStats.corners[0] + (Math.random() > 0.85 ? 1 : 0),
              newStats.corners[1] + (Math.random() > 0.85 ? 1 : 0),
            ],
            dangerousAttacks: [
              newStats.dangerousAttacks[0] + (Math.random() > 0.5 ? 1 : 0),
              newStats.dangerousAttacks[1] + (Math.random() > 0.5 ? 1 : 0),
            ],
          };

          return {
            ...m,
            minute: nextMinute,
            homeScore,
            awayScore,
            events: newEvents,
            stats: newStats,
          };
        });

        if (matchFinished) {
          checkPredictionsSettlementRef.current(matchFinished);
          triggerNotificationRef.current({
            type: 'match_end',
            title: 'Full Time!',
            message: `${(matchFinished as Match).homeTeam.name} ${(matchFinished as Match).homeScore} - ${(matchFinished as Match).awayScore} ${(matchFinished as Match).awayTeam.name}`,
          });
        }

        return updated;
      });
    }, intervalMs);

    return () => clearInterval(interval);
  }, [user.lowDataMode]);

  // Fast forward match
  const fastForwardMatch = useCallback((matchId: string) => {
    sound.playTap();
    setMatches((currentMatches) => {
      let finishedOne: Match | null = null;
      const updated = currentMatches.map((m) => {
        if (m.id !== matchId) return m;

        const homeExtra = Math.floor(Math.random() * 2);
        const awayExtra = Math.floor(Math.random() * 2);
        const finalHome = m.homeScore + homeExtra;
        const finalAway = m.awayScore + awayExtra;

        const fin: Match = {
          ...m,
          status: 'finished',
          minute: 90,
          homeScore: finalHome,
          awayScore: finalAway,
          events: [
            ...m.events,
            ...(homeExtra > 0
              ? [
                  {
                    id: `ff_ev_h_${Date.now()}`,
                    minute: 84,
                    type: 'goal' as const,
                    teamId: m.homeTeam.id,
                    player: `${m.homeTeam.shortName} Number 9`,
                    detail: 'Decisive late winner!',
                  },
                ]
              : []),
            ...(awayExtra > 0
              ? [
                  {
                    id: `ff_ev_a_${Date.now()}`,
                    minute: 88,
                    type: 'goal' as const,
                    teamId: m.awayTeam.id,
                    player: `${m.awayTeam.shortName} Captain`,
                    detail: 'Clinical counter-attack goal',
                  },
                ]
              : []),
          ],
        };
        finishedOne = fin;
        return fin;
      });

      if (finishedOne) {
        checkPredictionsSettlement(finishedOne);
        triggerNotification({
          type: 'match_end',
          title: `Match Settled: ${(finishedOne as Match).homeTeam.code} ${(finishedOne as Match).homeScore} - ${(finishedOne as Match).awayScore} ${(finishedOne as Match).awayTeam.code}`,
          message: 'Match results verified and predictions updated.',
        });
      }

      return updated;
    });
  }, [checkPredictionsSettlement, triggerNotification]);

  // Step simulation for 1 game
  const simulateLiveStep = useCallback((matchId: string) => {
    sound.playTap();
    setMatches((prev) => {
      let fin: Match | null = null;
      const updated = prev.map((m) => {
        if (m.id !== matchId) return m;

        let status = m.status;
        let minute = m.minute;
        let homeScore = m.homeScore;
        let awayScore = m.awayScore;
        let events = [...m.events];

        if (status === 'upcoming') {
          status = 'live';
          minute = 1;
        } else if (status === 'live') {
          minute = Math.min(90, minute + 8);
          if (minute >= 90) status = 'finished';

          if (Math.random() > 0.4) {
            if (Math.random() > 0.5) {
              homeScore += 1;
              sound.playGoal();
              events = [
                {
                  id: `step_goal_${Date.now()}`,
                  minute,
                  type: 'goal',
                  teamId: m.homeTeam.id,
                  player: `${m.homeTeam.shortName} Striker`,
                  detail: 'Fast break thunderous volley!',
                },
                ...events,
              ];
            } else {
              awayScore += 1;
              sound.playGoal();
              events = [
                {
                  id: `step_goal_${Date.now()}`,
                  minute,
                  type: 'goal',
                  teamId: m.awayTeam.id,
                  player: `${m.awayTeam.shortName} Playmaker`,
                  detail: 'Curling free-kick in off the crossbar!',
                },
                ...events,
              ];
            }
          }
        }

        const res: Match = {
          ...m,
          status,
          minute,
          homeScore,
          awayScore,
          events,
        };
        if (status === 'finished') fin = res;
        return res;
      });

      if (fin) checkPredictionsSettlement(fin);
      return updated;
    });
  }, [checkPredictionsSettlement]);

  // Slip handlers
  const togglePick = useCallback((selection: PredictionSelection) => {
    sound.playTap();
    setSlip((prev) => {
      const exists = prev.find(
        (p) => p.matchId === selection.matchId && p.selectionKey === selection.selectionKey
      );
      if (exists) {
        return prev.filter(
          (p) => !(p.matchId === selection.matchId && p.selectionKey === selection.selectionKey)
        );
      } else {
        const withoutSameMarket = prev.filter(
          (p) => !(p.matchId === selection.matchId && p.marketType === selection.marketType)
        );
        return [...withoutSameMarket, selection];
      }
    });
  }, []);

  const removePick = useCallback((matchId: string, selectionKey: string) => {
    sound.playTap();
    setSlip((prev) => prev.filter((p) => !(p.matchId === matchId && p.selectionKey === selectionKey)));
  }, []);

  const clearSlip = useCallback(() => {
    sound.playTap();
    setSlip([]);
  }, []);

  const isSelectionActive = useCallback(
    (matchId: string, selectionKey: string) => {
      return slip.some((p) => p.matchId === matchId && p.selectionKey === selectionKey);
    },
    [slip]
  );

  const placePrediction = useCallback(
    (stake: number, type: 'single' | 'accumulator') => {
      if (slip.length === 0) {
        return { success: false, message: 'Your prediction slip is empty.' };
      }
      if (stake <= 0) {
        return { success: false, message: 'Please enter a valid stake in Earnova Points (EP).' };
      }
      if (stake > user.points) {
        return { success: false, message: 'Insufficient EP balance. Claim your daily bonus or refill.' };
      }

      const totalOdds =
        type === 'accumulator' && slip.length > 1
          ? Number(slip.reduce((acc, item) => acc * item.odds, 1).toFixed(2))
          : Number(slip[0].odds.toFixed(2));

      const potentialReturn = Math.round(stake * totalOdds);
      const predId = 'pred_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const newPred: PlacedPrediction = {
        id: predId,
        timestamp: Date.now(),
        type,
        selections: [...slip],
        stake,
        totalOdds,
        potentialReturn,
        status: 'pending',
      };

      const ref = `TX-STK-${predId.slice(-6).toUpperCase()}`;
      const newBal = user.points - stake;

      setUser((u) => ({
        ...u,
        points: newBal,
        totalPredictions: u.totalPredictions + 1,
      }));

      setPlacedPredictions((prev) => [newPred, ...prev]);

      setTransactions((prev) => [
        {
          id: 'tx_stk_' + Date.now(),
          type: 'prediction_stake',
          amount: -stake,
          description: `Prediction Stake (${slip.length} ${slip.length > 1 ? 'picks' : 'pick'}) @ ${totalOdds}x`,
          timestamp: Date.now(),
          status: 'completed',
          reference: ref,
          balanceAfter: newBal,
        },
        ...prev,
      ]);

      sound.playPlaced();

      triggerNotification({
        type: 'match_start',
        title: 'Prediction Placed!',
        message: `${slip.length} ${slip.length > 1 ? 'picks' : 'pick'} submitted with ${stake} EP stake. Potential return: ${potentialReturn} EP.`,
      });

      setSlip([]);
      setIsSlipOpen(false);

      return {
        success: true,
        message: `Prediction locked! Potential return: ${potentialReturn} EP.`,
      };
    },
    [slip, user.points, triggerNotification]
  );

  const claimDailyBonus = useCallback(() => {
    const BONUS_AMOUNT = 250;
    const now = Date.now();
    const COOLDOWN = 12 * 3600 * 1000;

    if (now - user.lastBonusClaim < COOLDOWN) {
      const remainingMinutes = Math.ceil((COOLDOWN - (now - user.lastBonusClaim)) / 60000);
      return { success: false, amount: remainingMinutes };
    }

    sound.playBonus();
    if (!user.lowDataMode) {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10b981', '#34d399', '#f59e0b'],
      });
    }

    const newBal = user.points + BONUS_AMOUNT;
    const ref = `TX-BN-STRK-${Math.floor(Math.random() * 900 + 100)}`;

    setUser((u) => ({
      ...u,
      points: newBal,
      lastBonusClaim: now,
    }));

    setTransactions((prev) => [
      {
        id: 'tx_bon_' + Date.now(),
        type: 'daily_bonus',
        amount: BONUS_AMOUNT,
        description: 'Daily Streak Bonus Claim',
        timestamp: now,
        status: 'completed',
        reference: ref,
        balanceAfter: newBal,
      },
      ...prev,
    ]);

    triggerNotification({
      type: 'daily_bonus',
      title: 'Daily Streak Bonus Claimed!',
      message: `+${BONUS_AMOUNT} EP credited to your account. Keep your prediction streak alive!`,
    });

    return { success: true, amount: BONUS_AMOUNT };
  }, [user.lastBonusClaim, user.points, user.lowDataMode, triggerNotification]);

  const refillDemoPoints = useCallback(() => {
    sound.playBonus();
    const newBal = Math.max(user.points, 1500) + 1000;
    const ref = `TX-DEP-REF-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    setUser((u) => ({
      ...u,
      points: newBal,
    }));

    setTransactions((prev) => [
      {
        id: 'tx_ref_' + Date.now(),
        type: 'deposit',
        amount: 1000,
        description: 'Quick Demo Points Refill (+1,000 EP)',
        timestamp: Date.now(),
        status: 'completed',
        reference: ref,
        balanceAfter: newBal,
      },
      ...prev,
    ]);

    triggerNotification({
      type: 'daily_bonus',
      title: 'Demo Points Refilled',
      message: '+1,000 EP virtual points added for free demonstration play.',
    });
  }, [user.points, triggerNotification]);

  const demoDeposit = useCallback(
    (packageId: string, customAmount?: number) => {
      let epAmount = customAmount || 0;
      let pkgName = 'Custom Demo Refill';

      if (!customAmount) {
        const pkg = DEMO_DEPOSIT_PACKAGES.find((p) => p.id === packageId);
        if (pkg) {
          epAmount = pkg.epAmount;
          pkgName = pkg.name;
        } else {
          epAmount = 1000;
          pkgName = 'Demo Virtual Grant';
        }
      }

      const ref = `TX-DEP-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const newPoints = user.points + epAmount;

      const newTx: WalletTransaction = {
        id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: 'deposit',
        amount: epAmount,
        description: `${pkgName} (Free Virtual Refill)`,
        timestamp: Date.now(),
        status: 'completed',
        reference: ref,
        balanceAfter: newPoints,
      };

      setUser((u) => ({ ...u, points: newPoints }));
      setTransactions((prev) => [newTx, ...prev]);
      sound.playBonus();

      if (!user.lowDataMode) {
        confetti({
          particleCount: 65,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#10b981', '#34d399', '#38bdf8', '#fbbf24'],
        });
      }

      triggerNotification({
        type: 'daily_bonus',
        title: 'Virtual EP Refill Credited',
        message: `+${epAmount.toLocaleString()} EP added to your balance. Ref: ${ref} (Demonstration token, zero fiat value).`,
      });

      return {
        success: true,
        message: `Successfully credited +${epAmount.toLocaleString()} EP!`,
        epAdded: epAmount,
        reference: ref,
      };
    },
    [user.points, user.lowDataMode, triggerNotification]
  );

  const demoWithdraw = useCallback(
    (rewardId: string) => {
      const reward = DEMO_WITHDRAWAL_REWARDS.find((r) => r.id === rewardId);
      if (!reward) {
        return { success: false, message: 'Selected reward not found.', epDeducted: 0 };
      }
      if (user.points < reward.epCost) {
        return {
          success: false,
          message: `Insufficient virtual points. You need ${reward.epCost.toLocaleString()} EP (Current balance: ${(user?.points ?? 0).toLocaleString()} EP).`,
          epDeducted: 0,
        };
      }

      const certCode = `EARNOVA-WD-CERT-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const newPoints = user.points - reward.epCost;

      const newTx: WalletTransaction = {
        id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: 'withdrawal',
        amount: -reward.epCost,
        description: `Redeemed: ${reward.name}`,
        timestamp: Date.now(),
        status: 'completed',
        reference: certCode,
        balanceAfter: newPoints,
      };

      setUser((u) => ({ ...u, points: newPoints }));
      setTransactions((prev) => [newTx, ...prev]);
      sound.playWin();

      if (!user.lowDataMode) {
        confetti({
          particleCount: 70,
          spread: 65,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#fbbf24', '#10b981'],
        });
      }

      triggerNotification({
        type: 'prediction_settled',
        title: 'Demo Reward Redeemed!',
        message: `${reward.name} redeemed for ${reward.epCost.toLocaleString()} EP. Credential: ${certCode}`,
      });

      return {
        success: true,
        message: `Redemption complete! Certificate ID: ${certCode}`,
        certificateId: certCode,
        epDeducted: reward.epCost,
      };
    },
    [user.points, user.lowDataMode, triggerNotification]
  );

  const updateUser = useCallback((updates: Partial<UserProfile>) => {
    setUser((u) => ({ ...u, ...updates }));
  }, []);

  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const clearAllNotifications = useCallback(() => {
    sound.playTap();
    setNotifications([]);
  }, []);

  // Language & Low-Data Mode
  const setLanguage = useCallback((lang: Language) => {
    sound.playTap();
    setUser((u) => ({ ...u, language: lang }));
  }, []);

  const toggleLowDataMode = useCallback(() => {
    sound.playTap();
    setUser((u) => {
      const next = !u.lowDataMode;
      triggerNotification({
        type: 'daily_bonus',
        title: next ? 'Smart Low-Data Mode ON' : 'Standard Mode Restored',
        message: next
          ? 'Animations and polling frequency optimized to conserve data.'
          : 'Full graphic animations and real-time streaming frequency enabled.',
      });
      return { ...u, lowDataMode: next };
    });
  }, [triggerNotification]);

  // Favorites
  const toggleFavoriteTeam = useCallback((teamId: string) => {
    sound.playTap();
    setUser((u) => {
      const exists = u.favoriteTeamIds.includes(teamId);
      const updated = exists
        ? u.favoriteTeamIds.filter((id) => id !== teamId)
        : [...u.favoriteTeamIds, teamId];
      const team = TEAMS[teamId];
      if (team) {
        triggerNotification({
          type: 'daily_bonus',
          title: exists ? `Unfollowed ${team.shortName}` : `Following ${team.shortName}!`,
          message: exists
            ? `Custom match alerts for ${team.name} removed.`
            : `You will receive instant alerts whenever ${team.name} plays or scores!`,
        });
      }
      return { ...u, favoriteTeamIds: updated };
    });
  }, [triggerNotification]);

  // Community Actions
  const addCommunityPost = useCallback(
    (title: string, content: string, tag: 'Prediction' | 'Tactics' | 'Discussion' | 'Debate', matchId?: string) => {
      sound.playPlaced();
      const newPost: CommunityPost = {
        id: 'post_' + Date.now(),
        matchId,
        matchTitle: matchId ? matches.find((m) => m.id === matchId)?.homeTeam.name + ' vs ' + matches.find((m) => m.id === matchId)?.awayTeam.name : undefined,
        author: user.username,
        avatar: user.avatar,
        title,
        content,
        timestamp: Date.now(),
        likes: 1,
        userLiked: true,
        comments: [],
        tag,
      };
      setCommunityPosts((prev) => [newPost, ...prev]);
      triggerNotification({
        type: 'friend_challenge',
        title: 'Discussion Published',
        message: 'Your analysis has been shared with the EARNOVA fan community!',
      });
    },
    [user.username, user.avatar, matches, triggerNotification]
  );

  const likeCommunityPost = useCallback((postId: string) => {
    sound.playTap();
    setCommunityPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const liked = !p.userLiked;
        return {
          ...p,
          userLiked: liked,
          likes: liked ? p.likes + 1 : Math.max(0, p.likes - 1),
        };
      })
    );
  }, []);

  const addCommentToPost = useCallback(
    (postId: string, text: string) => {
      sound.playTap();
      setCommunityPosts((prev) =>
        prev.map((p) => {
          if (p.id !== postId) return p;
          const comment = {
            id: 'c_' + Date.now(),
            author: user.username,
            avatar: user.avatar,
            text,
            timestamp: Date.now(),
            likes: 0,
          };
          return {
            ...p,
            comments: [...p.comments, comment],
          };
        })
      );
    },
    [user.username, user.avatar]
  );

  const acceptFriendChallenge = useCallback(
    (challengeId: string, myPick: string) => {
      sound.playWin();
      setFriendChallenges((prev) =>
        prev.map((c) => (c.id === challengeId ? { ...c, status: 'accepted', myPick } : c))
      );
      triggerNotification({
        type: 'friend_challenge',
        title: 'Duel Accepted!',
        message: `Prediction duel locked in for ${c_stake(challengeId, friendChallenges)} EP. Winner takes bragging rights!`,
      });
    },
    [friendChallenges, triggerNotification]
  );

  const createFriendChallenge = useCallback(
    (matchId: string, pick: string, stakeEP: number) => {
      sound.playPlaced();
      const match = matches.find((m) => m.id === matchId);
      const newChal: FriendChallenge = {
        id: 'chal_' + Date.now(),
        challenger: `${user.username} (You)`,
        avatar: user.avatar,
        opponent: 'Open Challenge / Community',
        matchId,
        matchTitle: match ? `${match.homeTeam.name} vs ${match.awayTeam.name}` : 'Featured Match',
        challengerPick: pick,
        stakeEP,
        status: 'open',
      };
      setFriendChallenges((prev) => [newChal, ...prev]);
      triggerNotification({
        type: 'friend_challenge',
        title: 'Challenge Created!',
        message: `Your prediction challenge for ${stakeEP} EP has been posted to the community board.`,
      });
    },
    [matches, user.username, user.avatar, triggerNotification]
  );

  // Prediction Academy
  const completeAcademyLesson = useCallback(
    (lessonId: string) => {
      sound.playWin();
      let rewardedEP = 0;
      let lessonTitle = 'Theory Module';
      setAcademyLessons((prev) =>
        prev.map((l) => {
          if (l.id === lessonId && !l.completed) {
            rewardedEP = l.rewardEP;
            lessonTitle = l.titleEn;
            return { ...l, completed: true };
          }
          return l;
        })
      );
      if (rewardedEP > 0) {
        const newBal = user.points + rewardedEP;
        setUser((u) => ({ ...u, points: newBal }));
        setTransactions((prev) => [
          {
            id: 'tx_acad_' + Date.now(),
            type: 'reward',
            amount: rewardedEP,
            description: `Academy Module Quiz Passed: ${lessonTitle}`,
            timestamp: Date.now(),
            status: 'completed',
            reference: `TX-ACAD-${lessonId.toUpperCase()}`,
            balanceAfter: newBal,
          },
          ...prev,
        ]);
        triggerNotification({
          type: 'daily_bonus',
          title: 'Academy Module Passed!',
          message: `+${rewardedEP} EP awarded for completing the tactical lesson quiz!`,
        });
      }
    },
    [user.points, triggerNotification]
  );

  // Daily Trivia
  const answerTrivia = useCallback(
    (selectedIndex: number): boolean => {
      setTriviaAnswered(true);
      const currentQ = dailyTrivia[0];
      const isCorrect = selectedIndex === currentQ.correctIndex;
      setTriviaCorrect(isCorrect);

      if (isCorrect) {
        sound.playWin();
        const newBal = user.points + 100;
        setUser((u) => ({ ...u, points: newBal }));
        setTransactions((prev) => [
          {
            id: 'tx_triv_' + Date.now(),
            type: 'reward',
            amount: 100,
            description: 'Daily Trivia Correct Answer Reward',
            timestamp: Date.now(),
            status: 'completed',
            reference: `TX-TRIV-${Math.floor(Math.random() * 900 + 100)}`,
            balanceAfter: newBal,
          },
          ...prev,
        ]);
        triggerNotification({
          type: 'trivia',
          title: 'Trivia Master!',
          message: 'Correct answer! +100 EP added to your balance.',
        });
        return true;
      } else {
        sound.playTap();
        return false;
      }
    },
    [dailyTrivia, user.points, triggerNotification]
  );

  const resetAllDemoData = useCallback(() => {
    sound.playBonus();
    try {
      safeStorage.removeItem(LOCAL_STORAGE_KEY_USER);
      safeStorage.removeItem(LOCAL_STORAGE_KEY_PREDS);
      safeStorage.removeItem(LOCAL_STORAGE_KEY_POSTS);
      safeStorage.removeItem(LOCAL_STORAGE_KEY_ACADEMY);
      safeStorage.removeItem(LOCAL_STORAGE_KEY_TRANSACTIONS);
    } catch {}
    setUser(INITIAL_USER);
    setPlacedPredictions(INITIAL_PREDICTIONS);
    setCommunityPosts(INITIAL_POSTS);
    setAcademyLessons(ACADEMY_LESSONS);
    setTransactions(INITIAL_TRANSACTIONS);
    setSlip([]);
    triggerNotification({
      type: 'daily_bonus',
      title: 'Demo Data Reset',
      message: 'All balances, prediction slips, and ledger records have been restored to default demo state.',
    });
  }, [triggerNotification]);

  return (
    <EarnovaContext.Provider
      value={{
        matches,
        slip,
        placedPredictions,
        user,
        notifications,
        activeToast,
        leaderboard,
        isSlipOpen,
        setIsSlipOpen,
        selectedMatchDetail,
        setSelectedMatchDetail,
        selectedMarketsMatch,
        setSelectedMarketsMatch,
        selectedIntelligenceMatch,
        setSelectedIntelligenceMatch,
        isNotificationCenterOpen,
        setIsNotificationCenterOpen,
        isNavDrawerOpen,
        setIsNavDrawerOpen,
        transactions,
        demoDeposit,
        demoWithdraw,
        communityPosts,
        friendChallenges,
        addCommunityPost,
        likeCommunityPost,
        addCommentToPost,
        acceptFriendChallenge,
        createFriendChallenge,
        academyLessons,
        completeAcademyLesson,
        dailyTrivia,
        triviaAnswered,
        triviaCorrect,
        answerTrivia,
        tournamentGroups,
        language: user.language || 'en',
        setLanguage,
        lowDataMode: user.lowDataMode || false,
        toggleLowDataMode,
        favoriteTeamIds: user.favoriteTeamIds || [],
        toggleFavoriteTeam,
        volume,
        setVolume,
        playTestSound,
        togglePick,
        removePick,
        clearSlip,
        isSelectionActive,
        placePrediction,
        claimDailyBonus,
        refillDemoPoints,
        updateUser,
        markNotificationRead,
        clearAllNotifications,
        dismissToast,
        simulateLiveStep,
        fastForwardMatch,
        resetAllDemoData,
        // Authentication & User Accounts
        isAuthenticated: user.isLoggedIn !== false && !!user.email,
        isAuthModalOpen,
        authModalMode,
        authPromptReason,
        openAuthModal,
        closeAuthModal,
        loginUser,
        registerUser,
        logoutUser,
        resetPasswordUser,
        requireAuth,
      }}
    >
      {children}
    </EarnovaContext.Provider>
  );
};

function c_stake(id: string, list: FriendChallenge[]): number {
  return list.find((c) => c.id === id)?.stakeEP || 100;
}

export const useEarnova = () => {
  const context = useContext(EarnovaContext);
  if (!context) {
    throw new Error('useEarnova must be used within an EarnovaProvider');
  }
  return context;
};
