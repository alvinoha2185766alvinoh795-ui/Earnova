import React, { useState } from 'react';
import { HelpCircle, Sparkles, CheckCircle2, XCircle, Flame, ArrowRight, Award } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

export const TriviaView: React.FC = () => {
  const { dailyTrivia, answerTrivia, triviaAnswered, triviaCorrect, user, language } = useEarnova();
  const { t } = useTranslation(language);

  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);

  const isSw = language === 'sw';
  const currentQ = dailyTrivia[0];

  const handleSubmit = () => {
    if (selectedOpt === null || triviaAnswered) return;
    answerTrivia(selectedOpt);
  };

  return (
    <div className="space-y-6 pb-12 max-w-2xl mx-auto">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0d2245] via-[#0f2d5c] to-[#09152b] border border-amber-500/30 shadow-2xl relative overflow-hidden text-center sm:text-left">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-3xl shadow-xl shadow-amber-950/40">
              🧠
            </div>
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2 text-xs font-bold text-amber-400">
                <Flame className="w-4 h-4" />
                <span>DAILY FOOTBALL KNOWLEDGE TEST</span>
              </div>
              <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white mt-0.5">
                {t('dailyTrivia')}
              </h1>
              <p className="text-xs text-slate-300 mt-1">
                {t('triviaSubtitle')}
              </p>
            </div>
          </div>

          <div className="bg-[#081224]/80 p-3 rounded-2xl border border-[#162f5e] text-center shrink-0">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
              Trivia Streak
            </span>
            <span className="font-mono font-extrabold text-xl text-amber-400">
              3 Days 🔥
            </span>
          </div>
        </div>
      </div>

      {/* Main Question Card */}
      <div className="p-6 sm:p-7 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-5">
        <div className="flex items-center justify-between text-xs border-b border-[#14264b] pb-3">
          <span className="font-semibold text-emerald-400">
            Today&apos;s Challenge
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-[#122347] border border-[#1a3363] text-slate-300 font-mono text-[10px]">
            Difficulty: {currentQ.difficulty}
          </span>
        </div>

        {/* Question Text */}
        <h2 className="font-display font-bold text-base sm:text-lg text-white leading-snug">
          {isSw ? currentQ.questionSw : currentQ.questionEn}
        </h2>

        {/* Answer Options */}
        <div className="space-y-2.5">
          {(isSw ? currentQ.optionsSw : currentQ.optionsEn).map((opt, idx) => {
            const isSelected = selectedOpt === idx;
            const isCorrect = idx === currentQ.correctIndex;

            let cardClass = 'bg-[#081224] border-[#162c57] text-slate-200 hover:border-emerald-500/50';
            if (isSelected) {
              cardClass = 'bg-emerald-500/10 border-emerald-400 text-white';
            }
            if (triviaAnswered) {
              if (isCorrect) {
                cardClass = 'bg-emerald-950/70 border-emerald-400 text-emerald-200 font-bold';
              } else if (isSelected && !isCorrect) {
                cardClass = 'bg-rose-950/70 border-rose-500 text-rose-200';
              }
            }

            return (
              <button
                key={idx}
                disabled={triviaAnswered}
                onClick={() => setSelectedOpt(idx)}
                className={`w-full p-4 rounded-2xl border text-left text-xs transition-all flex items-center justify-between cursor-pointer ${cardClass}`}
              >
                <span>{opt}</span>
                {triviaAnswered && isCorrect && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                )}
                {triviaAnswered && isSelected && !isCorrect && (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Action Button & Feedback */}
        {!triviaAnswered ? (
          <button
            onClick={handleSubmit}
            disabled={selectedOpt === null}
            className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-bold text-xs tracking-wide shadow-md transition-all cursor-pointer"
          >
            {t('submitAnswer')}
          </button>
        ) : (
          <div
            className={`p-4 rounded-2xl border text-xs leading-relaxed space-y-1 ${
              triviaCorrect
                ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-950/50 border-rose-500/40 text-rose-300'
            }`}
          >
            <strong className="block text-sm font-semibold">
              {triviaCorrect ? t('correctAnswer') : t('wrongAnswer')}
            </strong>
            <p className="text-slate-200">
              {isSw ? currentQ.explanationSw : currentQ.explanationEn}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
