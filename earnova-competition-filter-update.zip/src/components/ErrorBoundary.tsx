import React, { Component, ErrorInfo, ReactNode } from 'react';
import { RotateCcw, AlertTriangle, RefreshCw } from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Earnova ErrorBoundary caught error:', error, errorInfo);
    this.setState({ error, errorInfo });
  }

  private handleResetState = () => {
    try {
      safeStorage.removeItem('earnova_user_v3');
      safeStorage.removeItem('earnova_predictions_v3');
      safeStorage.removeItem('earnova_posts_v3');
      safeStorage.removeItem('earnova_academy_v3');
      safeStorage.removeItem('earnova_transactions_v3');
      safeStorage.removeItem('earnova_auth_session_v2');
      safeStorage.removeItem('earnova_auth_accounts_v2');
    } catch {}
    this.setState({ hasError: false, error: null, errorInfo: null });
    if (typeof window !== 'undefined') {
      window.location.reload();
    }
  };

  private handleRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#070d18] text-slate-100 flex items-center justify-center p-4">
          <div className="max-w-md w-full p-6 sm:p-8 rounded-3xl bg-[#0c1830] border-2 border-amber-500/40 shadow-2xl space-y-5 text-center">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto text-2xl">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h1 className="font-display font-extrabold text-2xl text-white">
                Earnova Session Recovery
              </h1>
              <p className="text-xs text-slate-300 leading-relaxed">
                A temporary rendering hiccup occurred. You can retry immediately or reset your demo session back to default factory state.
              </p>
            </div>

            {this.state.error && (
              <div className="p-3 rounded-xl bg-[#071021] border border-rose-500/30 text-left text-[11px] font-mono text-rose-300 max-h-32 overflow-y-auto">
                <p className="font-bold text-rose-400 mb-1">Diagnostic Log:</p>
                <p className="break-all">{this.state.error.message || String(this.state.error)}</p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={this.handleRetry}
                className="py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Retry</span>
              </button>

              <button
                type="button"
                onClick={this.handleResetState}
                className="py-3 px-4 rounded-xl bg-[#071021] hover:bg-[#0f1f3d] border border-amber-500/40 text-amber-300 font-bold text-xs uppercase flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset Demo</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
