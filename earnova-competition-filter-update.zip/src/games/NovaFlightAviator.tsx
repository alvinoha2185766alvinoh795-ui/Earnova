import React, { useState, useEffect, useRef } from 'react';
import {
  Plane,
  Play,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Coins,
  ShieldCheck,
  Volume2,
  VolumeX,
  History,
  Users,
  CheckCircle2,
  AlertTriangle,
  Flame,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

interface PastFlight {
  id: string;
  multiplier: number;
  crashedAt: number;
}

interface DemoPassenger {
  name: string;
  avatar: string;
  stake: number;
  cashedOut: boolean;
  cashedAt?: number;
}

export const NovaFlightAviator: React.FC = () => {
  const { user, updateUser, refillDemoPoints } = useEarnova();

  // Game States: 'IDLE' | 'COUNTDOWN' | 'FLYING' | 'CRASHED'
  const [gameState, setGameState] = useState<'IDLE' | 'COUNTDOWN' | 'FLYING' | 'CRASHED'>('IDLE');
  const [countdown, setCountdown] = useState<number>(3);
  const [multiplier, setMultiplier] = useState<number>(1.0);
  const [stake, setStake] = useState<number>(50);
  const [autoCashout, setAutoCashout] = useState<number>(2.0);
  const [autoCashoutEnabled, setAutoCashoutEnabled] = useState<boolean>(false);
  const [hasBet, setHasBet] = useState<boolean>(false);
  const [hasCashedOut, setHasCashedOut] = useState<boolean>(false);
  const [cashoutMultiplier, setCashoutMultiplier] = useState<number | null>(null);
  const [lastWinAmount, setLastWinAmount] = useState<number | null>(null);

  // Past rounds multiplier history
  const [flightHistory, setFlightHistory] = useState<PastFlight[]>([
    { id: '1', multiplier: 2.34, crashedAt: Date.now() - 50000 },
    { id: '2', multiplier: 1.45, crashedAt: Date.now() - 40000 },
    { id: '3', multiplier: 5.82, crashedAt: Date.now() - 30000 },
    { id: '4', multiplier: 1.18, crashedAt: Date.now() - 20000 },
    { id: '5', multiplier: 12.4, crashedAt: Date.now() - 10000 },
    { id: '6', multiplier: 3.15, crashedAt: Date.now() - 5000 },
  ]);

  // Simulated co-pilots betting in the round
  const [coPilots, setCoPilots] = useState<DemoPassenger[]>([
    { name: 'Kipchoge99', avatar: '⚡', stake: 100, cashedOut: false },
    { name: 'NairobiStriker', avatar: '🎯', stake: 50, cashedOut: false },
    { name: 'TacticalPro', avatar: '👑', stake: 250, cashedOut: false },
    { name: 'MombasaAce', avatar: '🦅', stake: 25, cashedOut: false },
  ]);

  const animationFrameRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const crashPointRef = useRef<number>(2.0);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  // Launch countdown when player places bet or starts round
  const handleStartRound = () => {
    if (user.points < stake) {
      alert('Insufficient demo virtual points. Please use the demo refill button.');
      return;
    }

    sound.playTap();
    // Deduct virtual stake
    updateUser({ points: Math.max(0, user.points - stake) });
    setHasBet(true);
    setHasCashedOut(false);
    setCashoutMultiplier(null);
    setLastWinAmount(null);
    setMultiplier(1.0);
    setGameState('COUNTDOWN');
    setCountdown(3);

    // Reset simulated copilots
    setCoPilots([
      { name: 'Kipchoge99', avatar: '⚡', stake: 100, cashedOut: false },
      { name: 'NairobiStriker', avatar: '🎯', stake: 50, cashedOut: false },
      { name: 'TacticalPro', avatar: '👑', stake: 250, cashedOut: false },
      { name: 'MombasaAce', avatar: '🦅', stake: 25, cashedOut: false },
    ]);
  };

  // Countdown timer
  useEffect(() => {
    if (gameState !== 'COUNTDOWN') return;

    if (countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown((prev) => prev - 1);
        sound.playTap();
      }, 700);
      return () => clearTimeout(timer);
    } else {
      // Determine crash multiplier randomly with realistic distribution
      // 10% instant crash (1.05 - 1.2x), 60% standard (1.2x - 3.5x), 20% high (3.5x - 10x), 10% super nova (> 10x)
      const rand = Math.random();
      let targetCrash = 1.0;
      if (rand < 0.12) {
        targetCrash = Number((1.05 + Math.random() * 0.25).toFixed(2));
      } else if (rand < 0.7) {
        targetCrash = Number((1.3 + Math.random() * 2.2).toFixed(2));
      } else if (rand < 0.9) {
        targetCrash = Number((3.5 + Math.random() * 6.5).toFixed(2));
      } else {
        targetCrash = Number((10.0 + Math.random() * 25.0).toFixed(2));
      }
      crashPointRef.current = targetCrash;
      startTimeRef.current = performance.now();
      setGameState('FLYING');
    }
  }, [gameState, countdown]);

  // Flight game loop
  useEffect(() => {
    if (gameState !== 'FLYING') return;

    const targetCrash = crashPointRef.current;

    const step = (now: number) => {
      const elapsed = (now - startTimeRef.current) / 1000;
      // Exponential flight multiplier progression: 1 + (t * 0.1)^1.8
      const current = 1.0 + Math.pow(elapsed * 0.38, 1.6);

      // Check auto cashout
      if (
        hasBet &&
        !hasCashedOut &&
        autoCashoutEnabled &&
        current >= autoCashout &&
        autoCashout <= targetCrash
      ) {
        handleExecuteCashout(autoCashout);
      }

      // Simulate other copilots randomly cashing out
      setCoPilots((prev) =>
        prev.map((pilot) => {
          if (!pilot.cashedOut && Math.random() < 0.015 && current < targetCrash) {
            return { ...pilot, cashedOut: true, cashedAt: Number(current.toFixed(2)) };
          }
          return pilot;
        })
      );

      if (current >= targetCrash) {
        // Plane Flew Away!
        setMultiplier(targetCrash);
        setGameState('CRASHED');
        sound.playCrash();

        // Record flight history
        setFlightHistory((prev) => [
          { id: String(Date.now()), multiplier: targetCrash, crashedAt: Date.now() },
          ...prev.slice(0, 9),
        ]);

        return;
      }

      setMultiplier(Number(current.toFixed(2)));
      animationFrameRef.current = requestAnimationFrame(step);
    };

    animationFrameRef.current = requestAnimationFrame(step);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [gameState, hasBet, hasCashedOut, autoCashout, autoCashoutEnabled]);

  // Manual Cash Out
  const handleExecuteCashout = (overrideMultiplier?: number) => {
    if (gameState !== 'FLYING' || !hasBet || hasCashedOut) return;

    const winMult = overrideMultiplier || multiplier;
    const winAmount = Math.round(stake * winMult);

    setHasCashedOut(true);
    setCashoutMultiplier(winMult);
    setLastWinAmount(winAmount);

    // Credit user's virtual points immediately
    updateUser({ points: user.points + winAmount });
    sound.playCashout();
  };

  // Trajectory calculation for SVG flight line
  // Normalizes progress from 0 to 1 based on current multiplier
  const flightProgress = Math.min(1, (multiplier - 1) / (crashPointRef.current > 3 ? 10 : 3.5));
  const planeX = 30 + flightProgress * 320;
  const planeY = 170 - Math.pow(flightProgress, 0.75) * 130;

  return (
    <div className="space-y-4">
      {/* 1. Recent Multiplier Ribbon */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 text-xs font-mono scrollbar-none">
        <span className="text-[10px] uppercase font-bold text-slate-500 shrink-0 mr-1 flex items-center gap-1">
          <History className="w-3 h-3 text-emerald-400" />
          <span>Rounds:</span>
        </span>
        {flightHistory.map((flight) => {
          let badgeColor = 'bg-[#0f1f3d] text-sky-300 border-[#1a3866]';
          if (flight.multiplier >= 10) {
            badgeColor = 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-xs shadow-amber-500/20 font-black';
          } else if (flight.multiplier >= 2) {
            badgeColor = 'bg-purple-500/20 text-purple-300 border-purple-500/40 font-bold';
          }
          return (
            <span
              key={flight.id}
              className={`px-2 py-0.5 rounded-lg border text-[11px] shrink-0 font-bold tabular-nums ${badgeColor}`}
            >
              {flight.multiplier.toFixed(2)}x
            </span>
          );
        })}
      </div>

      {/* 2. Main Flight Arena (Aviator Radar View) */}
      <div className="relative w-full h-72 sm:h-84 rounded-3xl bg-gradient-to-b from-[#060e1d] via-[#09152b] to-[#040914] border border-[#162f5e] overflow-hidden shadow-2xl flex flex-col justify-between p-4 select-none">
        {/* Radar grid coordinates background */}
        <div className="absolute inset-0 bg-[radial-gradient(#153066_1px,transparent_1px)] [background-size:24px_24px] opacity-40 pointer-events-none" />

        {/* Top telemetry bar */}
        <div className="relative z-10 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-bold text-slate-200 tracking-wider uppercase text-[11px]">
              Nova Flight · Aviator Flight Zone
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-400 font-mono">
              Virtual EP Only · 100% Free
            </span>
          </div>
        </div>

        {/* Animated Flight Canvas / Multiplier HUD */}
        <div className="relative flex-1 flex items-center justify-center">
          {/* Central Multiplier Indicator */}
          {gameState === 'COUNTDOWN' && (
            <div className="text-center space-y-1 animate-in zoom-in-95 duration-150">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-400">
                Next Flight In
              </span>
              <div className="font-mono font-black text-6xl sm:text-7xl text-emerald-400 animate-pulse">
                {countdown}s
              </div>
              <p className="text-xs text-slate-400">Locking tactical coordinates...</p>
            </div>
          )}

          {gameState === 'IDLE' && (
            <div className="text-center space-y-2 max-w-xs">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
                <Plane className="w-7 h-7 transform -rotate-45" />
              </div>
              <h3 className="font-display font-extrabold text-xl text-white">
                Nova Flight Ready
              </h3>
              <p className="text-xs text-slate-400">
                Choose your virtual EP stake below and hit <strong>Launch Flight</strong>. Cash out before the jet flies away!
              </p>
            </div>
          )}

          {gameState === 'FLYING' && (
            <div className="text-center space-y-1">
              <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold block">
                Ascending Trajectory
              </span>
              <div className="font-mono font-black text-5xl sm:text-7xl text-white tracking-tight tabular-nums drop-shadow-md">
                {multiplier.toFixed(2)}
                <span className="text-emerald-400 text-3xl sm:text-4xl ml-1">x</span>
              </div>
              {hasBet && !hasCashedOut && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold animate-pulse">
                  <span>Current Yield:</span>
                  <span>+{Math.round(stake * multiplier).toLocaleString()} EP</span>
                </div>
              )}
            </div>
          )}

          {gameState === 'CRASHED' && (
            <div className="text-center space-y-2 animate-in zoom-in-95 duration-150">
              <span className="text-xs font-mono uppercase tracking-widest text-rose-400 font-bold block flex items-center justify-center gap-1">
                <AlertTriangle className="w-4 h-4" />
                <span>FLEW AWAY!</span>
              </span>
              <div className="font-mono font-black text-5xl sm:text-7xl text-rose-500 tracking-tight tabular-nums">
                {multiplier.toFixed(2)}x
              </div>
              <p className="text-xs text-slate-300">
                {hasCashedOut
                  ? `🎉 Brilliant timing! You secured +${lastWinAmount?.toLocaleString()} EP @ ${cashoutMultiplier}x!`
                  : hasBet
                  ? 'The jet departed the atmospheric grid before cashout.'
                  : 'Flight completed. Place your stake for the next flight!'}
              </p>
            </div>
          )}

          {/* SVG Supersonic Flight Curve */}
          {(gameState === 'FLYING' || gameState === 'CRASHED') && (
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none overflow-visible"
              viewBox="0 0 400 200"
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="curveGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.1" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.8" />
                </linearGradient>
                <linearGradient id="areaGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Trajectory area fill */}
              <path
                d={`M 30 170 Q ${30 + (planeX - 30) * 0.5} 170, ${planeX} ${planeY} L ${planeX} 170 Z`}
                fill="url(#areaGrad)"
              />

              {/* Glowing flight line */}
              <path
                d={`M 30 170 Q ${30 + (planeX - 30) * 0.5} 170, ${planeX} ${planeY}`}
                fill="none"
                stroke={gameState === 'CRASHED' ? '#ef4444' : '#10b981'}
                strokeWidth="4"
                strokeLinecap="round"
              />

              {/* Jet Sprite */}
              {gameState === 'FLYING' && (
                <g transform={`translate(${planeX - 16}, ${planeY - 16})`}>
                  <circle cx="16" cy="16" r="14" fill="#10b981" fillOpacity="0.2" />
                  <polygon
                    points="26,16 6,8 10,16 6,24"
                    fill="#10b981"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                  {/* Glowing thruster exhaust */}
                  <circle cx="5" cy="16" r="3" fill="#38bdf8" className="animate-ping" />
                </g>
              )}
            </svg>
          )}
        </div>

        {/* Successful Cashout Toast inside the view */}
        {hasCashedOut && lastWinAmount && (
          <div className="absolute top-12 left-1/2 -translate-x-1/2 z-20 px-4 py-2 rounded-2xl bg-emerald-500 text-slate-950 font-black text-sm flex items-center gap-2 shadow-2xl animate-in fade-in slide-in-from-top duration-200">
            <CheckCircle2 className="w-5 h-5" />
            <span>
              CASHED OUT: +{lastWinAmount.toLocaleString()} EP ({cashoutMultiplier}x)
            </span>
          </div>
        )}

        {/* Bottom Arena Footer */}
        <div className="relative z-10 flex items-center justify-between text-[11px] text-slate-400 border-t border-[#14264b] pt-2">
          <div className="flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-emerald-400" />
            <span>Virtual Bankroll:</span>
            <strong className="text-white font-mono">{(user?.points ?? 0).toLocaleString()} EP</strong>
          </div>

          <button
            type="button"
            onClick={refillDemoPoints}
            className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 underline cursor-pointer"
          >
            +1,000 Free Refill
          </button>
        </div>
      </div>

      {/* 3. Action Control Deck (Mobile First, Ergonomic Buttons) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] shadow-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 sm:gap-4 items-center">
          {/* Stake Config Column */}
          <div className="md:col-span-5 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300">Virtual Stake (EP)</span>
              <span className="text-[11px] text-slate-400">Min: 10 EP</span>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <input
                  type="number"
                  min={10}
                  max={user.points}
                  step={10}
                  value={stake}
                  disabled={gameState === 'FLYING' || gameState === 'COUNTDOWN'}
                  onChange={(e) => setStake(Math.max(10, Number(e.target.value)))}
                  className="w-full h-12 px-3.5 rounded-2xl bg-[#081224] border border-[#193264] text-white font-mono font-bold text-base focus:outline-none focus:border-emerald-400 disabled:opacity-50 touch-manipulation"
                />
                <span className="absolute right-3.5 top-3.5 text-xs font-bold text-emerald-400 font-mono">
                  EP
                </span>
              </div>

              {/* Quick Multiplier Buttons */}
              <div className="flex items-center gap-1">
                {[25, 50, 100, 250].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    disabled={gameState === 'FLYING' || gameState === 'COUNTDOWN'}
                    onClick={() => setStake(amt)}
                    className={`px-2.5 py-3 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer touch-manipulation active:scale-95 disabled:opacity-50 ${
                      stake === amt
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                        : 'bg-[#09152b] border-[#162c57] text-slate-300 hover:text-white'
                    }`}
                  >
                    {amt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Auto Cashout Column */}
          <div className="md:col-span-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoCashoutEnabled}
                  onChange={(e) => setAutoCashoutEnabled(e.target.checked)}
                  disabled={gameState === 'FLYING'}
                  className="w-4 h-4 rounded accent-emerald-500 cursor-pointer"
                />
                <span className="font-semibold text-slate-300">Auto Cashout</span>
              </label>
              <span className="text-[11px] text-slate-400">Target</span>
            </div>

            <div className="relative">
              <input
                type="number"
                min={1.1}
                max={50}
                step={0.1}
                value={autoCashout}
                disabled={!autoCashoutEnabled || gameState === 'FLYING'}
                onChange={(e) => setAutoCashout(Number(e.target.value))}
                className="w-full h-12 px-3.5 rounded-2xl bg-[#081224] border border-[#193264] text-white font-mono font-bold text-base focus:outline-none focus:border-emerald-400 disabled:opacity-40 touch-manipulation"
              />
              <span className="absolute right-3.5 top-3.5 text-xs font-bold text-emerald-400 font-mono">
                X
              </span>
            </div>
          </div>

          {/* Primary Action Button (LAUNCH or CASHOUT) */}
          <div className="md:col-span-4">
            {gameState === 'FLYING' && hasBet && !hasCashedOut ? (
              <button
                type="button"
                onClick={() => handleExecuteCashout()}
                className="w-full h-14 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 font-display font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/30 flex flex-col items-center justify-center cursor-pointer touch-manipulation active:scale-95 animate-pulse"
              >
                <span>CASH OUT NOW</span>
                <span className="text-xs font-mono font-extrabold">
                  +{Math.round(stake * multiplier).toLocaleString()} EP ({multiplier.toFixed(2)}x)
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleStartRound}
                disabled={gameState === 'COUNTDOWN' || gameState === 'FLYING'}
                className="w-full h-14 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 text-slate-950 font-display font-black text-base uppercase tracking-wider shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer touch-manipulation active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Plane className="w-5 h-5 transform -rotate-45" />
                <span>
                  {gameState === 'COUNTDOWN'
                    ? `LAUNCHING IN ${countdown}s...`
                    : `LAUNCH FLIGHT (${stake} EP)`}
                </span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 4. Live Flight Co-Pilots Leaderboard */}
      <div className="p-4 rounded-2xl bg-[#09152b] border border-[#162c57] space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-400" />
            <h4 className="font-display font-bold text-white">Live Round Participants</h4>
          </div>
          <span className="text-slate-400 font-mono">{coPilots.length + 1} Pilots in Flight</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {/* User's own status */}
          <div className="p-2.5 rounded-xl bg-[#060e1f] border border-emerald-500/40 flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-sm">{user.avatar}</span>
              <div className="min-w-0">
                <span className="font-bold text-white block truncate text-[11px]">
                  {user.username} (You)
                </span>
                <span className="text-[10px] text-slate-400 font-mono">{stake} EP</span>
              </div>
            </div>
            {hasCashedOut ? (
              <span className="text-[10px] font-bold text-emerald-400 font-mono">
                {cashoutMultiplier}x ✓
              </span>
            ) : gameState === 'FLYING' ? (
              <span className="text-[10px] font-bold text-sky-400 animate-pulse font-mono">
                In Flight
              </span>
            ) : (
              <span className="text-[10px] text-slate-500">Ready</span>
            )}
          </div>

          {/* Co-pilots */}
          {coPilots.map((pilot) => (
            <div
              key={pilot.name}
              className="p-2.5 rounded-xl bg-[#060e1f] border border-[#14264b] flex items-center justify-between"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-sm">{pilot.avatar}</span>
                <div className="min-w-0">
                  <span className="font-semibold text-slate-300 block truncate text-[11px]">
                    {pilot.name}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">{pilot.stake} EP</span>
                </div>
              </div>
              {pilot.cashedOut ? (
                <span className="text-[10px] font-bold text-emerald-400 font-mono">
                  {pilot.cashedAt}x ✓
                </span>
              ) : gameState === 'FLYING' ? (
                <span className="text-[10px] text-sky-400 font-mono animate-pulse">In Flight</span>
              ) : (
                <span className="text-[10px] text-slate-600">Pending</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
