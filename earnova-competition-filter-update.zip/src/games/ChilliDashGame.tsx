import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  RotateCcw,
  Trophy,
  Coins,
  Sparkles,
  ArrowLeft,
  Volume2,
  VolumeX,
  Flame,
  Zap,
  ArrowLeftCircle,
  ArrowRightCircle,
  Shield,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type Lane = 0 | 1 | 2; // 0: Left, 1: Middle, 2: Right

interface ObstacleOrItem {
  id: number;
  lane: Lane;
  y: number; // 0 (top) to 100 (bottom)
  type: 'obstacle' | 'coin' | 'chilli' | 'sombrero';
  icon: string;
}

interface ChilliDashGameProps {
  onBack?: () => void;
}

export const ChilliDashGame: React.FC<ChilliDashGameProps> = ({ onBack }) => {
  const { user, updateUser } = useEarnova();
  const [lane, setLane] = useState<Lane>(1);
  const [distance, setDistance] = useState<number>(0);
  const [coinsCollected, setCoinsCollected] = useState<number>(0);
  const [sizzleMeter, setSizzleMeter] = useState<number>(0);
  const [isSuperSizzle, setIsSuperSizzle] = useState<boolean>(false);
  const [hasShield, setHasShield] = useState<boolean>(false);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [items, setItems] = useState<ObstacleOrItem[]>([]);

  const requestRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number | null>(null);
  const nextSpawnDistanceRef = useRef<number>(20);
  const idCounterRef = useRef<number>(1);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameOver) return;
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        moveLeft();
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        moveRight();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameOver]);

  const moveLeft = () => {
    setLane((prev) => (prev > 0 ? ((prev - 1) as Lane) : 0));
    if (soundEnabled) sound.playTap();
  };

  const moveRight = () => {
    setLane((prev) => (prev < 2 ? ((prev + 1) as Lane) : 2));
    if (soundEnabled) sound.playTap();
  };

  // Main game loop
  const updateGame = useCallback(
    (time: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = time;
      const delta = (time - lastTimeRef.current) / 1000;
      lastTimeRef.current = time;

      const speed = isSuperSizzle ? 75 : 45;

      setDistance((prevDist) => {
        const nextDist = prevDist + speed * delta;

        // Spawn items
        if (nextDist >= nextSpawnDistanceRef.current) {
          nextSpawnDistanceRef.current = nextDist + (isSuperSizzle ? 14 : 22);
          const itemLane = Math.floor(Math.random() * 3) as Lane;
          const rand = Math.random();

          let type: ObstacleOrItem['type'] = 'obstacle';
          let icon = '🌵';

          if (rand < 0.45) {
            type = 'coin';
            icon = '🪙';
          } else if (rand < 0.65) {
            type = 'chilli';
            icon = '🌶️';
          } else if (rand < 0.75) {
            type = 'sombrero';
            icon = '🤠';
          } else {
            type = 'obstacle';
            icon = Math.random() > 0.5 ? '🌵' : '🛢️';
          }

          setItems((prevItems) => [
            ...prevItems,
            { id: idCounterRef.current++, lane: itemLane, y: 0, type, icon },
          ]);
        }

        return nextDist;
      });

      // Move items down
      setItems((prevItems) => {
        const updated: ObstacleOrItem[] = [];

        for (const item of prevItems) {
          const nextY = item.y + (speed * delta * 1.5);

          // Check collision with player at y around 80-92%
          if (nextY >= 75 && nextY <= 92 && item.lane === lane) {
            if (item.type === 'coin') {
              setCoinsCollected((c) => c + 1);
              if (soundEnabled) sound.playWin();
              continue; // Collect and remove
            } else if (item.type === 'chilli') {
              setSizzleMeter((prev) => {
                const next = prev + 30;
                if (next >= 100 && !isSuperSizzle) {
                  setIsSuperSizzle(true);
                  confetti({ particleCount: 50, spread: 60 });
                  if (soundEnabled) sound.playBonus();
                }
                return Math.min(100, next);
              });
              continue;
            } else if (item.type === 'sombrero') {
              setHasShield(true);
              if (soundEnabled) sound.playBonus();
              continue;
            } else if (item.type === 'obstacle') {
              if (isSuperSizzle) {
                // Destroy obstacle in super sizzle mode!
                continue;
              } else if (hasShield) {
                setHasShield(false);
                continue;
              } else {
                // Crash!
                setIsPlaying(false);
                setGameOver(true);
                const epBonus = Math.max(30, Math.floor(distance / 5) + coinsCollected * 20);
                updateUser({ points: user.points + epBonus });
                return prevItems;
              }
            }
          }

          if (nextY < 105) {
            updated.push({ ...item, y: nextY });
          }
        }

        return updated;
      });

      if (isPlaying && !gameOver) {
        requestRef.current = requestAnimationFrame(updateGame);
      }
    },
    [
      isSuperSizzle,
      lane,
      hasShield,
      isPlaying,
      gameOver,
      soundEnabled,
      distance,
      coinsCollected,
      updateUser,
      user.points,
    ]
  );

  // Super Sizzle timeout
  useEffect(() => {
    if (!isSuperSizzle) return;
    const timer = setTimeout(() => {
      setIsSuperSizzle(false);
      setSizzleMeter(0);
    }, 6000);
    return () => clearTimeout(timer);
  }, [isSuperSizzle]);

  // Animation frame hook
  useEffect(() => {
    if (isPlaying && !gameOver) {
      lastTimeRef.current = performance.now();
      requestRef.current = requestAnimationFrame(updateGame);
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isPlaying, gameOver, updateGame]);

  const handleStart = () => {
    setIsPlaying(true);
    setGameOver(false);
    setDistance(0);
    setCoinsCollected(0);
    setSizzleMeter(0);
    setIsSuperSizzle(false);
    setHasShield(false);
    setItems([]);
    setLane(1);
    nextSpawnDistanceRef.current = 20;
    lastTimeRef.current = performance.now();
  };

  const lanePositions = ['left-[18%]', 'left-[50%]', 'left-[82%]'];

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-red-900/50">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#0c1830] border border-red-500/40 text-red-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🌶️</span>
              <h2 className="font-display font-black text-lg sm:text-xl text-yellow-300 tracking-tight">
                Chilli Dash
              </h2>
            </div>
            <p className="text-[11px] text-red-300/80 font-mono">
              Sizzling Reflex Runner · Non-Wagering Entertainment
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-[#0c1830] border border-red-500/40 text-red-300 hover:text-white cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleStart}
            className="p-2 rounded-xl bg-[#0c1830] border border-red-500/40 text-red-300 hover:text-white cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-gradient-to-r from-[#2e0705] via-[#3d0b07] to-[#1a0403] border border-red-500/40 shadow-xl">
        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-red-300 block">Distance</span>
          <span className="font-mono font-black text-xl text-yellow-300 tabular-nums">
            {Math.floor(distance)}m
          </span>
          <span className="text-[9px] text-red-200/60 block">Speed: {isSuperSizzle ? 'SUPER 75' : '45'} km/h</span>
        </div>

        <div className="text-center border-x border-red-500/30">
          <span className="text-[10px] uppercase font-bold text-red-300 block">Gold Coins</span>
          <span className="font-mono font-black text-xl text-amber-300 tabular-nums">
            {coinsCollected}
          </span>
          <span className="text-[9px] text-emerald-400 block font-semibold">
            {hasShield ? '🛡️ Shield Active' : 'Dodge Obstacles'}
          </span>
        </div>

        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-red-300 block">Virtual EP</span>
          <span className="font-mono font-black text-base text-emerald-400 tabular-nums">
            {(user?.points ?? 0).toLocaleString()}
          </span>
          <span className="text-[9px] text-slate-400 block">Demo Balance</span>
        </div>
      </div>

      {/* Sizzle Boost Meter */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] font-mono">
          <span className="text-amber-300 font-bold flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-red-400 animate-pulse" />
            {isSuperSizzle ? '🔥 SUPER SIZZLE DASH ACTIVE (INVINCIBLE)!' : 'Sizzle Boost Meter'}
          </span>
          <span className="text-yellow-400 font-bold">{sizzleMeter}%</span>
        </div>
        <div className="h-3 w-full bg-[#170302] rounded-full overflow-hidden p-0.5 border border-red-900/60">
          <div
            className={`h-full rounded-full transition-all duration-300 ${
              isSuperSizzle
                ? 'bg-gradient-to-r from-yellow-300 via-orange-500 to-red-500 animate-pulse'
                : 'bg-gradient-to-r from-red-600 to-amber-400'
            }`}
            style={{ width: `${sizzleMeter}%` }}
          />
        </div>
      </div>

      {/* 3-Lane Highway Track */}
      <div className="relative h-80 sm:h-96 rounded-3xl bg-gradient-to-b from-[#2b0805] via-[#1c0503] to-[#0a0201] border-2 border-red-600/70 overflow-hidden shadow-2xl">
        {/* Lane Dividers */}
        <div className="absolute inset-0 flex">
          <div className="w-1/3 border-r-2 border-dashed border-red-500/20" />
          <div className="w-1/3 border-r-2 border-dashed border-red-500/20" />
          <div className="w-1/3" />
        </div>

        {/* Incoming Items */}
        {items.map((item) => {
          const laneClasses = ['left-[16%]', 'left-[50%]', 'left-[84%]'];
          return (
            <div
              key={item.id}
              className={`absolute -translate-x-1/2 -translate-y-1/2 text-3xl sm:text-4xl transition-transform ${laneClasses[item.lane]}`}
              style={{ top: `${item.y}%` }}
            >
              {item.icon}
            </div>
          );
        })}

        {/* El Chilli Character */}
        <div
          className={`absolute bottom-6 -translate-x-1/2 flex flex-col items-center justify-center transition-all duration-150 ${lanePositions[lane]}`}
        >
          <div
            className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center relative shadow-2xl ${
              isSuperSizzle
                ? 'bg-gradient-to-r from-amber-400 to-red-500 ring-4 ring-yellow-300 animate-bounce'
                : 'bg-gradient-to-b from-orange-500 to-red-700 border-2 border-amber-400'
            }`}
          >
            <span className="text-3xl sm:text-4xl filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
              🌶️
            </span>
            <span className="absolute -top-1 right-0 text-sm">🕶️</span>
            {hasShield && (
              <span className="absolute -top-3 text-lg animate-pulse">🤠</span>
            )}
          </div>
          {isSuperSizzle && (
            <span className="text-[9px] font-black uppercase text-yellow-300 mt-1 bg-black/70 px-1.5 py-0.2 rounded">
              SIZZLE!
            </span>
          )}
        </div>

        {/* Start Game prompt */}
        {!isPlaying && !gameOver && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center z-10">
            <span className="text-5xl mb-2 animate-bounce">🌶️🕶️</span>
            <h3 className="font-display font-black text-2xl text-yellow-300">
              CHILLI DASH HIGHWAY
            </h3>
            <p className="text-xs text-red-200 mt-1 max-w-xs">
              Dodge spiky cacti and rolling barrels! Collect gold coins, fire peppers, and hit Super Sizzle mode.
            </p>
            <button
              type="button"
              onClick={handleStart}
              className="mt-4 px-8 py-3 rounded-2xl bg-gradient-to-r from-red-600 via-amber-500 to-yellow-400 text-slate-950 font-display font-black text-xs uppercase tracking-wider shadow-xl hover:scale-105 active:scale-95 transition-transform cursor-pointer"
            >
              Start Dash
            </button>
          </div>
        )}

        {/* Game Over modal */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20 animate-fade-in">
            <span className="text-5xl mb-2">💥</span>
            <h3 className="font-display font-black text-2xl text-white">DASH COMPLETED!</h3>
            <p className="text-xs text-slate-300 mt-1">
              Distance: <strong className="text-yellow-300 font-mono">{Math.floor(distance)}m</strong> · Coins: <strong className="text-amber-400 font-mono">{coinsCollected}</strong>
            </p>
            <div className="my-3 px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs">
              +{Math.floor(distance / 5) + coinsCollected * 20} Virtual Demo EP Earned!
            </div>
            <button
              type="button"
              onClick={handleStart}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg hover:scale-105 active:scale-95 transition-all"
            >
              Dash Again
            </button>
          </div>
        )}
      </div>

      {/* Mobile Touch Navigation Controls */}
      <div className="grid grid-cols-2 gap-3 pt-1">
        <button
          type="button"
          onClick={moveLeft}
          className="py-4 rounded-2xl bg-gradient-to-r from-[#2e0705] to-[#1c0503] border-2 border-red-500/50 hover:border-red-400 active:scale-95 transition-all flex items-center justify-center gap-2 text-white font-display font-black text-sm uppercase tracking-wider cursor-pointer select-none touch-manipulation"
        >
          <ArrowLeftCircle className="w-5 h-5 text-amber-400" />
          <span>LANE LEFT</span>
        </button>

        <button
          type="button"
          onClick={moveRight}
          className="py-4 rounded-2xl bg-gradient-to-r from-[#1c0503] to-[#2e0705] border-2 border-red-500/50 hover:border-red-400 active:scale-95 transition-all flex items-center justify-center gap-2 text-white font-display font-black text-sm uppercase tracking-wider cursor-pointer select-none touch-manipulation"
        >
          <span>LANE RIGHT</span>
          <ArrowRightCircle className="w-5 h-5 text-amber-400" />
        </button>
      </div>
    </div>
  );
};
