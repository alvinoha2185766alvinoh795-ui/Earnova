import React, { useState } from 'react';
import {
  Home,
  Trophy,
  Activity,
  Ticket,
  Grid,
  X,
  MessageSquare,
  GraduationCap,
  TrendingUp,
  Brain,
  History,
  Award,
  User,
  Star,
  Wallet,
  ChevronRight,
  Settings,
  ArrowDownLeft,
  ArrowUpRight,
  Plane,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface BottomNavProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenFavorites: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenFavorites,
}) => {
  const { slip, setIsSlipOpen, language, user } = useEarnova();
  const { t } = useTranslation(language);
  const [showMoreDrawer, setShowMoreDrawer] = useState(false);

  const handleNav = (tabId: string) => {
    onSelectTab(tabId);
    setShowMoreDrawer(false);
  };

  const moreFeatures = [
    { id: 'novaplay', label: 'NovaPlay (Aviator)', icon: Plane },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'deposit', label: 'Deposit', icon: ArrowDownLeft },
    { id: 'withdraw', label: 'Withdraw', icon: ArrowUpRight },
    { id: 'ucl', label: t('championsLeague'), icon: Trophy },
    { id: 'community', label: t('community'), icon: MessageSquare },
    { id: 'academy', label: t('academy'), icon: GraduationCap },
    { id: 'performance', label: t('performance'), icon: TrendingUp },
    { id: 'trivia', label: t('trivia'), icon: Brain },
    { id: 'history', label: t('history'), icon: History },
    { id: 'favorites', label: t('favoriteClubs'), icon: Star },
  ];

  return (
    <>
      {/* Floating Prediction Slip Banner (When user has selections in slip) */}
      {slip.length > 0 && (
        <div className="fixed bottom-18 left-3 right-3 z-40 md:hidden animate-in slide-in-from-bottom-2 duration-150">
          <button
            type="button"
            onClick={() => setIsSlipOpen(true)}
            className="w-full py-2.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-between shadow-xl shadow-emerald-500/30 cursor-pointer active:scale-98 transition-transform touch-manipulation"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-slate-950 text-emerald-400 flex items-center justify-center text-xs font-mono font-bold">
                {slip.length}
              </div>
              <span>{slip.length === 1 ? '1 Selection in Slip' : `${slip.length} Selections in Slip`}</span>
            </div>
            <span className="flex items-center gap-1 uppercase tracking-wider text-[11px] font-black">
              <Ticket className="w-3.5 h-3.5" />
              <span>Open Slip →</span>
            </span>
          </button>
        </div>
      )}

      {/* Mobile Slide-Up More Menu */}
      {showMoreDrawer && (
        <div
          className="fixed inset-0 z-50 flex items-end bg-black/75 backdrop-blur-xs md:hidden"
          onClick={() => setShowMoreDrawer(false)}
        >
          <div
            className="w-full bg-[#0a1428] border-t border-[#182f5c] rounded-t-3xl p-5 space-y-4 pb-safe animate-in slide-in-from-bottom duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[#14264b] pb-3">
              <h3 className="font-display font-bold text-base text-white">
                More EARNOVA Features
              </h3>
              <button
                type="button"
                onClick={() => setShowMoreDrawer(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-4 gap-2.5">
              {moreFeatures.map((feat) => {
                const Icon = feat.icon;
                const isActive = currentTab === feat.id;
                return (
                  <button
                    key={feat.id}
                    type="button"
                    onClick={() => handleNav(feat.id)}
                    className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer touch-manipulation active:scale-95 ${
                      isActive
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-bold'
                        : 'bg-[#0e1d3b] border-[#162e5c] text-slate-300 hover:text-white'
                    }`}
                  >
                    <Icon className="w-5 h-5 text-emerald-400" />
                    <span className="text-[10px] font-medium leading-tight">
                      {feat.label}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="pt-1 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowMoreDrawer(false);
                  onOpenFavorites();
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-[#0e1d3b] border border-[#162e5c] text-xs font-semibold text-amber-300 flex items-center justify-center gap-2 cursor-pointer touch-manipulation"
              >
                <Star className="w-4 h-4 fill-amber-300" />
                <span>{t('manageFavorites')}</span>
              </button>
              <button
                type="button"
                onClick={() => handleNav('wallet')}
                className="py-2.5 px-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-xs font-semibold text-emerald-300 flex items-center justify-center gap-1.5 cursor-pointer touch-manipulation"
              >
                <Wallet className="w-4 h-4" />
                <span>Wallet</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Primary Fixed Bottom Navigation Bar - Optimized for Android Mobile touch ergonomics */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070d18]/95 backdrop-blur-lg border-t border-[#162548] md:hidden pb-safe">
        <div className="grid grid-cols-6 items-center h-16 px-0.5">
          {/* 1. Home / Dashboard */}
          <button
            type="button"
            onClick={() => onSelectTab('home')}
            className={`flex flex-col items-center justify-center h-full min-h-[48px] transition-all cursor-pointer touch-manipulation active:scale-95 ${
              currentTab === 'home'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight mt-1 truncate max-w-full px-0.5">
              {t('dashboard')}
            </span>
          </button>

          {/* 2. Fixtures */}
          <button
            type="button"
            onClick={() => onSelectTab('matches')}
            className={`flex flex-col items-center justify-center h-full min-h-[48px] transition-all cursor-pointer touch-manipulation active:scale-95 ${
              currentTab === 'matches'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight mt-1 truncate max-w-full px-0.5">
              {t('fixtures')}
            </span>
          </button>

          {/* 3. Live Centre */}
          <button
            type="button"
            onClick={() => onSelectTab('live')}
            className={`flex flex-col items-center justify-center h-full min-h-[48px] transition-all cursor-pointer touch-manipulation active:scale-95 relative ${
              currentTab === 'live'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="relative">
              <Activity className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <span className="text-[9px] font-medium tracking-tight mt-1 truncate max-w-full px-0.5">
              {t('liveCentre')}
            </span>
          </button>

          {/* 4. WALLET - 1-tap direct access on mobile */}
          <button
            type="button"
            onClick={() => onSelectTab('wallet')}
            className={`flex flex-col items-center justify-center h-full min-h-[48px] transition-all cursor-pointer touch-manipulation active:scale-95 relative ${
              currentTab === 'wallet'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="relative">
              <div
                className={`p-1 rounded-xl transition-colors ${
                  currentTab === 'wallet'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'text-slate-400'
                }`}
              >
                <Wallet className="w-5 h-5" />
              </div>
            </div>
            <span className="text-[9px] font-medium tracking-tight mt-0.5 truncate max-w-full px-0.5">
              {t('wallet')}
            </span>
          </button>

          {/* 5. LEADERBOARD / RANKS - 1-tap direct access */}
          <button
            type="button"
            onClick={() => onSelectTab('leaderboard')}
            className={`flex flex-col items-center justify-center h-full min-h-[48px] transition-all cursor-pointer touch-manipulation active:scale-95 ${
              currentTab === 'leaderboard'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-5 h-5" />
            <span className="text-[9px] font-medium tracking-tight mt-1 truncate max-w-full px-0.5">
              {t('ranks')}
            </span>
          </button>

          {/* 6. PROFILE / ACCOUNT */}
          <button
            type="button"
            onClick={() => onSelectTab('profile')}
            className={`flex flex-col items-center justify-center h-full min-h-[48px] transition-all cursor-pointer touch-manipulation active:scale-95 ${
              currentTab === 'profile'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="w-5 h-5 rounded-full bg-[#132752] border border-emerald-500/40 flex items-center justify-center text-[10px]">
              {user.avatar || <User className="w-3.5 h-3.5 text-emerald-400" />}
            </div>
            <span className="text-[9px] font-medium tracking-tight mt-1 truncate max-w-full px-0.5">
              {t('profile')}
            </span>
          </button>
        </div>
      </nav>
    </>
  );
};
