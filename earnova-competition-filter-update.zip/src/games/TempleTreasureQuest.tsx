import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  RotateCcw,
  Trophy,
  Coins,
  Sparkles,
  ArrowLeft,
  Volume2,
  VolumeX,
  Play,
  Flame,
  Award,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type GemType = 'emerald' | 'ruby' | 'sapphire' | 'amber' | 'amethyst' | 'diamond';

interface GemItem {
  id: string;
  type: GemType;
  matched?: boolean;
  isBomb?: boolean;
}

const GEM_CONFIG: Record<GemType, { label: string; icon: string; color: string; border: string; glow: string; points: number }> = {
  emerald: { label: 'Emerald', icon: '💎', color: 'bg-emerald-600', border: 'border-emerald-400', glow: '#10b981', points: 30 },
  ruby: { label: 'Ruby', icon: '♦️', color: 'bg-rose-600', border: 'border-rose-400', glow: '#f43f5e', points: 40 },
  sapphire: { label: 'Sapphire', icon: '🔷', color: 'bg-blue-600', border: 'border-blue-400', glow: '#3b82f6', points: 35 },
  amber: { label: 'Sun Amber', icon: '☀️', color: 'bg-amber-600', border: 'border-yellow-400', glow: '#fbbf24', points: 50 },
  amethyst: { label: 'Amethyst', icon: '🔮', color: 'bg-purple-600', border: 'border-purple-400', glow: '#a855f7', points: 45 },
  diamond: { label: 'Diamond', icon: '💠', color: 'bg-cyan-500', border: 'border-cyan-300', glow: '#06b6d4', points: 60 },
};

const GEM_TYPES: GemType[] = ['emerald', 'ruby', 'sapphire', 'amber', 'amethyst', 'diamond'];
const GRID_SIZE = 6;
const TARGET_SCORE = 1500;
const INITIAL_MOVES = 20;

const createRandomGem = (row: number, col: number): GemItem => {
  const type = GEM_TYPES[Math.floor(Math.random() * GEM_TYPES.length)];
  return { id: `gem-${row}-${col}-${Date.now()}-${Math.random()}`, type };
};

const createInitialBoard = (): GemItem[][] => {
  const board: GemItem[][] = [];
  for (let r = 0; r < GRID_SIZE; r++) {
    const row: GemItem[] = [];
    for (let c = 0; c < GRID_SIZE; c++) {
      let gem = createRandomGem(r, c);
      // Avoid initial 3-in-a-row
      while (
        (c >= 2 && row[c - 1]?.type === gem.type && row[c - 2]?.type === gem.type) ||
        (r >= 2 && board[r - 1]?.[c]?.type === gem.type && board[r - 2]?.[c]?.type === gem.type)
      ) {
        gem = createRandomGem(r, c);
      }
      row.push(gem);
    }
    board.push(row);
  }
  return board;
};

interface TempleTreasureQuestProps {
  onBack?: () => void;
}

export const TempleTreasureQuest: React.FC<TempleTreasureQuestProps> = ({ onBack }) => {
  const { user, updateUser, refillDemoPoints } = useEarnova();
  const [board, setBoard] = useState<GemItem[][]>(() => createInitialBoard());
  const [selectedGem, setSelectedGem] = useState<{ r: number; c: number } | null>(null);
  const [score, setScore] = useState<number>(0);
  const [movesLeft, setMovesLeft] = useState<number>(INITIAL_MOVES);
  const [comboMultiplier, setComboMultiplier] = useState<number>(1);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);
  const [questWon, setQuestWon] = useState<boolean>(false);
  const [questFailed, setQuestFailed] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [lastRewardEarned, setLastRewardEarned] = useState<number>(0);

  // Check for matches on the board
  const findMatches = useCallback((b: GemItem[][]): { r: number; c: number }[] => {
    const matchedCoords = new Set<string>();

    // Horizontal check
    for (let r = 0; r < GRID_SIZE; r++) {
      let matchLength = 1;
      for (let c = 0; c < GRID_SIZE; c++) {
        const current = b[r][c];
        const next = c < GRID_SIZE - 1 ? b[r][c + 1] : null;

        if (next && current.type === next.type) {
          matchLength++;
        } else {
          if (matchLength >= 3) {
            for (let i = 0; i < matchLength; i++) {
              matchedCoords.add(`${r},${c - i}`);
            }
          }
          matchLength = 1;
        }
      }
    }

    // Vertical check
    for (let c = 0; c < GRID_SIZE; c++) {
      let matchLength = 1;
      for (let r = 0; r < GRID_SIZE; r++) {
        const current = b[r][c];
        const next = r < GRID_SIZE - 1 ? b[r + 1][c] : null;

        if (next && current.type === next.type) {
          matchLength++;
        } else {
          if (matchLength >= 3) {
            for (let i = 0; i < matchLength; i++) {
              matchedCoords.add(`${r - i},${c}`);
            }
          }
          matchLength = 1;
        }
      }
    }

    return Array.from(matchedCoords).map((coord) => {
      const [r, c] = coord.split(',').map(Number);
      return { r, c };
    });
  }, []);

  // Process cascades and refills
  const processBoardCascades = useCallback((currentBoard: GemItem[][], currentCombo: number) => {
    const matches = findMatches(currentBoard);
    if (matches.length === 0) {
      setIsAnimating(false);
      setComboMultiplier(1);
      return;
    }

    setIsAnimating(true);
    if (soundEnabled) {
      sound.playWin();
    }

    // Calculate score for this match wave
    let waveScore = 0;
    matches.forEach(({ r, c }) => {
      const gem = currentBoard[r][c];
      waveScore += (GEM_CONFIG[gem.type]?.points || 30) * currentCombo;
    });

    setScore((prev) => {
      const newScore = prev + waveScore;
      if (newScore >= TARGET_SCORE && !questWon) {
        setQuestWon(true);
        confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
        const bonusEP = 250;
        setLastRewardEarned(bonusEP);
        updateUser({ points: user.points + bonusEP });
        if (soundEnabled) sound.playBonus();
      }
      return newScore;
    });

    // Mark matched and animate collapse
    const nextBoard = currentBoard.map((row) => row.map((gem) => ({ ...gem })));

    // Collapse columns downwards
    setTimeout(() => {
      for (let c = 0; c < GRID_SIZE; c++) {
        let writeRow = GRID_SIZE - 1;
        for (let r = GRID_SIZE - 1; r >= 0; r--) {
          const isMatched = matches.some((m) => m.r === r && m.c === c);
          if (!isMatched) {
            if (writeRow !== r) {
              nextBoard[writeRow][c] = nextBoard[r][c];
            }
            writeRow--;
          }
        }
        // Fill top empty cells with fresh gems
        while (writeRow >= 0) {
          nextBoard[writeRow][c] = createRandomGem(writeRow, c);
          writeRow--;
        }
      }

      setBoard(nextBoard);
      setComboMultiplier(currentCombo + 1);

      // Check next cascade wave after short delay
      setTimeout(() => {
        processBoardCascades(nextBoard, currentCombo + 1);
      }, 350);
    }, 280);
  }, [findMatches, soundEnabled, questWon, updateUser, user.points]);

  // Handle tile swap click
  const handleTileClick = (r: number, c: number) => {
    if (isAnimating || questWon || questFailed || movesLeft <= 0) return;

    if (soundEnabled) sound.playTap();

    if (!selectedGem) {
      setSelectedGem({ r, c });
      return;
    }

    // Check if adjacent (not diagonal)
    const isAdjacent =
      (Math.abs(selectedGem.r - r) === 1 && selectedGem.c === c) ||
      (Math.abs(selectedGem.c - c) === 1 && selectedGem.r === r);

    if (!isAdjacent) {
      setSelectedGem({ r, c });
      return;
    }

    // Try swap
    const newBoard = board.map((row) => row.map((gem) => ({ ...gem })));
    const temp = newBoard[selectedGem.r][selectedGem.c];
    newBoard[selectedGem.r][selectedGem.c] = newBoard[r][c];
    newBoard[r][c] = temp;

    const matches = findMatches(newBoard);

    if (matches.length > 0) {
      // Valid move!
      setBoard(newBoard);
      setSelectedGem(null);
      setMovesLeft((prev) => {
        const nextMoves = prev - 1;
        if (nextMoves <= 0 && score < TARGET_SCORE) {
          setQuestFailed(true);
        }
        return nextMoves;
      });
      processBoardCascades(newBoard, 1);
    } else {
      // Invalid swap - animate bounce back
      setSelectedGem(null);
      if (soundEnabled) sound.playTap();
    }
  };

  const handleReset = () => {
    setBoard(createInitialBoard());
    setSelectedGem(null);
    setScore(0);
    setMovesLeft(INITIAL_MOVES);
    setComboMultiplier(1);
    setIsAnimating(false);
    setQuestWon(false);
    setQuestFailed(false);
    setLastRewardEarned(0);
  };

  const progressPercent = Math.min(100, Math.round((score / TARGET_SCORE) * 100));

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* Top Aztec Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-900/50">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🗿</span>
              <h2 className="font-display font-black text-lg sm:text-xl text-yellow-300 tracking-tight">
                Temple Treasure Quest
              </h2>
            </div>
            <p className="text-[11px] text-amber-200/80 font-mono">
              Aztec Gem Matching · Virtual Demo Points Only
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
            title="Toggle Sound"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="p-2 rounded-xl bg-[#0c1830] border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
            title="Reset Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Target & Moves Scoreboard */}
      <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-gradient-to-r from-[#1a1202] via-[#2a1b05] to-[#120d02] border border-amber-500/40 shadow-xl">
        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-amber-400 block">Score</span>
          <span className="font-mono font-black text-xl text-yellow-300 tabular-nums">
            {score.toLocaleString()}
          </span>
          <span className="text-[9px] text-amber-200/60 block">Target: {TARGET_SCORE}</span>
        </div>

        <div className="text-center border-x border-amber-500/30">
          <span className="text-[10px] uppercase font-bold text-amber-400 block">Moves Left</span>
          <span
            className={`font-mono font-black text-xl tabular-nums ${
              movesLeft <= 5 ? 'text-rose-400 animate-pulse' : 'text-white'
            }`}
          >
            {movesLeft}
          </span>
          <span className="text-[9px] text-emerald-400 block">Combo: {comboMultiplier}x</span>
        </div>

        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-amber-400 block">Virtual Balance</span>
          <span className="font-mono font-black text-base text-emerald-400 tabular-nums">
            {(user?.points ?? 0).toLocaleString()}
          </span>
          <span className="text-[9px] text-amber-300 block font-mono">EP Points</span>
        </div>
      </div>

      {/* Target Progress Bar */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] font-mono">
          <span className="text-amber-300 font-bold flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            Aztec Sun Idol Progress
          </span>
          <span className="text-yellow-400 font-bold">{progressPercent}%</span>
        </div>
        <div className="h-2.5 w-full bg-[#0a0f1d] rounded-full overflow-hidden p-0.5 border border-amber-900/60">
          <div
            className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* 6x6 Aztec Gem Grid */}
      <div className="relative p-3 rounded-3xl bg-gradient-to-b from-[#1c1304] to-[#0d0901] border-2 border-amber-600/70 shadow-2xl">
        {/* Aztec Corner Ornaments */}
        <div className="absolute top-1 left-2 text-xs text-amber-500 select-none">☀️</div>
        <div className="absolute top-1 right-2 text-xs text-amber-500 select-none">☀️</div>
        <div className="absolute bottom-1 left-2 text-xs text-amber-500 select-none">🗿</div>
        <div className="absolute bottom-1 right-2 text-xs text-amber-500 select-none">🗿</div>

        <div className="grid grid-cols-6 gap-1.5 sm:gap-2 max-w-[420px] mx-auto p-1">
          {board.map((row, r) =>
            row.map((gem, c) => {
              const isSelected = selectedGem?.r === r && selectedGem?.c === c;
              const config = GEM_CONFIG[gem.type];

              return (
                <button
                  key={gem.id}
                  type="button"
                  onClick={() => handleTileClick(r, c)}
                  className={`aspect-square rounded-2xl flex items-center justify-center relative cursor-pointer touch-manipulation transition-all duration-150 transform select-none ${
                    config.color
                  } border-2 ${config.border} shadow-lg ${
                    isSelected
                      ? 'scale-110 ring-4 ring-yellow-300 z-10 animate-pulse brightness-125'
                      : 'hover:scale-105 active:scale-95'
                  }`}
                  style={{
                    boxShadow: isSelected
                      ? `0 0 16px ${config.glow}`
                      : `0 2px 8px rgba(0,0,0,0.5)`,
                  }}
                >
                  <span className="text-2xl sm:text-3xl filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] pointer-events-none">
                    {config.icon}
                  </span>
                </button>
              );
            })
          )}
        </div>

        {/* Win Overlay Modal */}
        {questWon && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center p-6 text-center z-20 animate-fade-in">
            <div className="w-16 h-16 rounded-full bg-gradient-to-b from-amber-400 to-amber-700 flex items-center justify-center text-3xl shadow-2xl shadow-yellow-500/60 mb-3 animate-bounce">
              🏆
            </div>
            <h3 className="font-display font-black text-2xl text-yellow-300">
              TEMPLE CONQUERED!
            </h3>
            <p className="text-xs text-slate-300 mt-1 max-w-xs">
              You uncovered the Aztec Idol with {score.toLocaleString()} points and earned{' '}
              <strong className="text-emerald-400">+{lastRewardEarned} EP</strong> virtual demo reward!
            </p>
            <div className="mt-4 flex gap-3">
              <button
                type="button"
                onClick={handleReset}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg hover:scale-105 active:scale-95 transition-all"
              >
                Play Next Quest
              </button>
            </div>
          </div>
        )}

        {/* Failed Overlay Modal */}
        {questFailed && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center p-6 text-center z-20 animate-fade-in">
            <div className="text-4xl mb-2">⏳</div>
            <h3 className="font-display font-black text-xl text-rose-400">Out of Moves!</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              You scored {score.toLocaleString()} / {TARGET_SCORE}. Try another attempt to claim the Aztec treasure!
            </p>
            <button
              type="button"
              onClick={handleReset}
              className="mt-4 px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer hover:bg-amber-400 active:scale-95 transition-all"
            >
              Try Again
            </button>
          </div>
        )}
      </div>

      {/* Guide Banner */}
      <div className="p-3 rounded-2xl bg-[#091326] border border-amber-500/30 flex items-center justify-between text-xs text-amber-200/90">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-400" />
          Swap adjacent gems to match 3+ in a line and trigger cascading Aztec combos!
        </span>
      </div>
    </div>
  );
};
