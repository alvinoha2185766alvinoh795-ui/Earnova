import React from 'react';
import { Activity, ChevronRight, SlidersHorizontal, Brain, Star } from 'lucide-react';
import { Match } from '../types';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface MatchCardProps {
  match: Match;
  featured?: boolean;
}

const MatchCardComponent: React.FC<MatchCardProps> = ({ match, featured }) => {
  const {
    togglePick,
    isSelectionActive,
    setSelectedMarketsMatch,
    setSelectedMatchDetail,
    setSelectedIntelligenceMatch,
    favoriteTeamIds,
    toggleFavoriteTeam,
    language,
  } = useEarnova();
  const { t } = useTranslation(language);

  const handlePick1X2 = (
    key: 'home' | 'draw' | 'away',
    label: string,
    odds: number,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    togglePick({
      matchId: match.id,
      matchTitle: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
      marketType: 'matchResult',
      marketName: 'Match Result',
      selectionKey: key,
      selectionLabel: label,
      odds,
    });
  };

  const isHomeSelected = isSelectionActive(match.id, 'home');
  const isDrawSelected = isSelectionActive(match.id, 'draw');
  const isAwaySelected = isSelectionActive(match.id, 'away');

  const isLive = match.status === 'live';
  const isFinished = match.status === 'finished';

  const isHomeFav = favoriteTeamIds.includes(match.homeTeam.id);
  const isAwayFav = favoriteTeamIds.includes(match.awayTeam.id);

  return (
    <div
      className={`rounded-2xl border transition-all duration-200 bg-[#0d1a33] ${
        featured
          ? 'border-emerald-500/40 shadow-lg shadow-emerald-950/20'
          : 'border-[#172a50] hover:border-[#223d74]'
      }`}
    >
      {/* Top Metadata Row */}
      <div className="px-4 pt-3.5 pb-2 flex items-center justify-between border-b border-[#14264a] text-xs text-slate-400">
        <div className="flex items-center gap-2 truncate">
          <span className="font-medium text-slate-300 truncate">
            {match.leagueName}
          </span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>{match.leagueCountry}</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* AI Intelligence quick trigger */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setSelectedIntelligenceMatch(match);
            }}
            className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/30 transition-colors cursor-pointer"
            title="Earnova Match Intelligence AI"
          >
            <Brain className="w-3 h-3" />
            <span className="hidden sm:inline">AI Intel</span>
          </button>

          {isLive ? (
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/80" />
              <span className="font-mono tabular-nums">{match.minute}&apos; LIVE</span>
            </div>
          ) : isFinished ? (
            <span className="font-medium text-slate-400">Full Time</span>
          ) : (
            <span className="font-medium text-slate-300 font-mono">
              {match.startTime}
            </span>
          )}
        </div>
      </div>

      {/* Main Match Fixture Row */}
      <div
        onClick={() => setSelectedMatchDetail(match)}
        className="p-4 cursor-pointer hover:bg-[#102143]/50 transition-colors"
      >
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          {/* Home Team */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="relative">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 border border-white/10 shadow-inner"
                style={{ backgroundColor: match.homeTeam.crestBg }}
              >
                {match.homeTeam.crestIcon}
              </div>
              {isHomeFav && (
                <Star className="w-3 h-3 text-amber-400 fill-amber-400 absolute -top-1 -left-1" />
              )}
            </div>
            <div className="min-w-0">
              <h4 className="font-semibold text-sm text-white truncate">
                {match.homeTeam.name}
              </h4>
              <p className="text-[11px] text-slate-400 truncate">
                Home · {match.homeTeam.city}
              </p>
            </div>
          </div>

          {/* Scores / VS Center Column */}
          <div className="text-center px-2 shrink-0">
            {isLive || isFinished ? (
              <div className="flex items-center justify-center gap-1.5 font-mono font-extrabold text-2xl text-white tracking-wider tabular-nums">
                <span className={match.homeScore > match.awayScore ? 'text-emerald-400' : 'text-white'}>
                  {match.homeScore}
                </span>
                <span className="text-slate-500 text-lg">-</span>
                <span className={match.awayScore > match.homeScore ? 'text-emerald-400' : 'text-white'}>
                  {match.awayScore}
                </span>
              </div>
            ) : (
              <div className="text-center">
                <span className="text-xs font-bold text-slate-400 bg-[#14264a] px-2 py-0.5 rounded">
                  VS
                </span>
              </div>
            )}
            <span className="text-[10px] text-slate-400 block mt-0.5 truncate">
              {match.homeTeam.stadium}
            </span>
          </div>

          {/* Away Team */}
          <div className="flex items-center justify-end gap-2.5 sm:gap-3 text-right">
            <div className="min-w-0">
              <h4 className="font-semibold text-sm text-white truncate">
                {match.awayTeam.name}
              </h4>
              <p className="text-[11px] text-slate-400 truncate">
                Away · {match.awayTeam.city}
              </p>
            </div>
            <div className="relative">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 border border-white/10 shadow-inner"
                style={{ backgroundColor: match.awayTeam.crestBg }}
              >
                {match.awayTeam.crestIcon}
              </div>
              {isAwayFav && (
                <Star className="w-3 h-3 text-amber-400 fill-amber-400 absolute -top-1 -right-1" />
              )}
            </div>
          </div>
        </div>

        {/* Live event teaser */}
        {isLive && match.events.length > 0 && (
          <div className="mt-3 pt-2.5 border-t border-[#14264a] flex items-center justify-between text-xs text-slate-300">
            <div className="flex items-center gap-1.5 truncate">
              <Activity className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="text-emerald-400 font-mono font-medium">
                {match.events[0].minute}&apos;
              </span>
              <span className="truncate">
                {match.events[0].player} ({match.events[0].detail || match.events[0].type})
              </span>
            </div>
            <span className="text-[11px] text-emerald-400 flex items-center gap-0.5 shrink-0 ml-2">
              {t('viewTracker')} <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        )}
      </div>

      {/* 1X2 Quick Odds Row */}
      <div className="p-3 bg-[#0a152a] rounded-b-2xl border-t border-[#14264a] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        <div className="grid grid-cols-3 gap-2 flex-1">
          {/* 1 (Home Win) */}
          <button
            onClick={(e) =>
              handlePick1X2('home', `${match.homeTeam.shortName} (Home)`, match.odds.matchResult.home, e)
            }
            className={`flex flex-col items-center justify-center py-2 px-2.5 rounded-xl border transition-all min-h-[46px] cursor-pointer ${
              isHomeSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/50 hover:bg-[#142954]'
            }`}
          >
            <span className={`text-[10px] uppercase font-semibold ${isHomeSelected ? 'text-slate-900' : 'text-slate-400'}`}>
              1 ({match.homeTeam.code})
            </span>
            <span className="font-mono font-bold text-xs sm:text-sm tabular-nums mt-0.5">
              {match.odds.matchResult.home.toFixed(2)}x
            </span>
          </button>

          {/* X (Draw) */}
          <button
            onClick={(e) =>
              handlePick1X2('draw', 'Draw (X)', match.odds.matchResult.draw, e)
            }
            className={`flex flex-col items-center justify-center py-2 px-2.5 rounded-xl border transition-all min-h-[46px] cursor-pointer ${
              isDrawSelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/50 hover:bg-[#142954]'
            }`}
          >
            <span className={`text-[10px] uppercase font-semibold ${isDrawSelected ? 'text-slate-900' : 'text-slate-400'}`}>
              X (Draw)
            </span>
            <span className="font-mono font-bold text-xs sm:text-sm tabular-nums mt-0.5">
              {match.odds.matchResult.draw.toFixed(2)}x
            </span>
          </button>

          {/* 2 (Away Win) */}
          <button
            onClick={(e) =>
              handlePick1X2('away', `${match.awayTeam.shortName} (Away)`, match.odds.matchResult.away, e)
            }
            className={`flex flex-col items-center justify-center py-2 px-2.5 rounded-xl border transition-all min-h-[46px] cursor-pointer ${
              isAwaySelected
                ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'bg-[#102143] border-[#1a3363] text-slate-200 hover:border-emerald-500/50 hover:bg-[#142954]'
            }`}
          >
            <span className={`text-[10px] uppercase font-semibold ${isAwaySelected ? 'text-slate-900' : 'text-slate-400'}`}>
              2 ({match.awayTeam.code})
            </span>
            <span className="font-mono font-bold text-xs sm:text-sm tabular-nums mt-0.5">
              {match.odds.matchResult.away.toFixed(2)}x
            </span>
          </button>
        </div>

        {/* More Markets Button */}
        <button
          onClick={() => setSelectedMarketsMatch(match)}
          className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-[#13254d] hover:bg-[#1a3166] text-xs font-semibold text-emerald-300 border border-[#1f3c78] hover:border-emerald-500/50 transition-colors shrink-0 min-h-[44px] cursor-pointer"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>{t('moreMarkets')}</span>
        </button>
      </div>
    </div>
  );
};

export const MatchCard = React.memo(MatchCardComponent);
export default MatchCard;
