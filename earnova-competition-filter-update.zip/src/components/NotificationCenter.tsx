import React from 'react';
import { X, Trash2, Bell, CheckCheck } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';

export const NotificationCenter: React.FC = () => {
  const {
    notifications,
    isNotificationCenterOpen,
    setIsNotificationCenterOpen,
    markNotificationRead,
    clearAllNotifications,
    setSelectedMatchDetail,
    matches,
  } = useEarnova();

  if (!isNotificationCenterOpen) return null;

  const handleMatchClick = (matchId?: string) => {
    if (!matchId) return;
    const match = matches.find((m) => m.id === matchId);
    if (match) {
      setSelectedMatchDetail(match);
      setIsNotificationCenterOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-md bg-[#0a1428] border-l border-[#1a2e57] h-full flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-[#16274b] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-emerald-400" />
            <h3 className="font-display font-bold text-base text-white">
              Live Game Alerts
            </h3>
          </div>
          <div className="flex items-center gap-2">
            {notifications.length > 0 && (
              <button
                onClick={clearAllNotifications}
                className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 px-2 py-1 rounded transition-colors"
                title="Clear all alerts"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
            <button
              onClick={() => setIsNotificationCenterOpen(false)}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-[#122245] transition-colors"
              aria-label="Close notifications"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List of alerts */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notifications.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center text-slate-400">
              <CheckCheck className="w-10 h-10 text-slate-600 mb-2 stroke-[1.5]" />
              <p className="text-sm">You are all caught up!</p>
              <p className="text-xs text-slate-500 mt-1">
                Live match goals, red cards, and prediction settlements will appear here.
              </p>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  markNotificationRead(item.id);
                  if (item.matchId) handleMatchClick(item.matchId);
                }}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  item.read
                    ? 'bg-[#0d1a33]/60 border-[#14264b] hover:border-[#1e386e]'
                    : 'bg-[#102040] border-emerald-500/30 hover:border-emerald-500/60'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-sm font-semibold text-white">
                    {item.title}
                  </h4>
                  <span className="text-[11px] text-slate-400 shrink-0 font-mono">
                    {formatTime(item.timestamp)}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  {item.message}
                </p>
                {item.matchId && (
                  <span className="inline-block text-[11px] text-emerald-400 font-medium mt-2">
                    Tap to open match tracker &rarr;
                  </span>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-[#16274b] bg-[#070e1c] text-[11px] text-slate-400 text-center">
          Real-time updates are simulated automatically for ongoing games.
        </div>
      </div>
    </div>
  );
};

function formatTime(timestamp: number): string {
  const diffSec = Math.floor((Date.now() - timestamp) / 1000);
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  return `${diffHours}h ago`;
}
