import React, { useState, useMemo } from 'react';
import { Search, Trophy, Filter } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { MatchCard } from '../components/MatchCard';

export const MatchesView: React.FC = () => {
  const { matches } = useEarnova();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'live' | 'today' | 'tomorrow' | 'settled'>('all');
  const [leagueFilter, setLeagueFilter] = useState<string>('all');

  const leagues = useMemo(() => {
    const map = new Map<string, string>();
    matches.forEach((m) => {
      map.set(m.leagueId, m.leagueName);
    });
    return Array.from(map.entries());
  }, [matches]);

  const filteredMatches = useMemo(() => {
    return matches.filter((m) => {
      // Status filter
      if (statusFilter === 'live' && m.status !== 'live') return false;
      if (statusFilter === 'today' && m.dateKey !== 'today') return false;
      if (statusFilter === 'tomorrow' && m.dateKey !== 'tomorrow') return false;
      if (statusFilter === 'settled' && m.status !== 'finished') return false;

      // League filter
      if (leagueFilter !== 'all' && m.leagueId !== leagueFilter) return false;

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const home = m.homeTeam.name.toLowerCase();
        const away = m.awayTeam.name.toLowerCase();
        const league = m.leagueName.toLowerCase();
        return home.includes(query) || away.includes(query) || league.includes(query);
      }

      return true;
    });
  }, [matches, statusFilter, leagueFilter, searchQuery]);

  return (
    <div className="space-y-5 pb-12">
      {/* Title & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
            Football Fixtures
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Demonstration match schedule with real-time simulated markets
          </p>
        </div>

        {/* Search Input */}
        <div className="relative sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search teams or leagues..."
            className="w-full h-10 pl-10 pr-3 rounded-xl bg-[#0d1c3a] border border-[#182f5c] text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-400 transition-colors"
          />
        </div>
      </div>

      {/* Filter Tabs (Segmented controls) */}
      <div className="flex flex-col gap-3">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'all'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
            }`}
          >
            All Fixtures ({matches.length})
          </button>
          <button
            onClick={() => setStatusFilter('live')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'live'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
            }`}
          >
            Live Now ({matches.filter((m) => m.status === 'live').length})
          </button>
          <button
            onClick={() => setStatusFilter('today')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'today'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
            }`}
          >
            Today ({matches.filter((m) => m.dateKey === 'today').length})
          </button>
          <button
            onClick={() => setStatusFilter('tomorrow')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'tomorrow'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
            }`}
          >
            Tomorrow ({matches.filter((m) => m.dateKey === 'tomorrow').length})
          </button>
          <button
            onClick={() => setStatusFilter('settled')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              statusFilter === 'settled'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
            }`}
          >
            Settled / Results ({matches.filter((m) => m.status === 'finished').length})
          </button>
        </div>

        {/* League Horizontal Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-slate-400 flex items-center gap-1 shrink-0 mr-1">
            <Trophy className="w-3.5 h-3.5 text-emerald-400" />
            League:
          </span>
          <button
            onClick={() => setLeagueFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              leagueFilter === 'all'
                ? 'bg-[#152e5d] text-emerald-400 border border-emerald-500/40'
                : 'bg-[#0a152a] text-slate-400 hover:text-white border border-[#14264b]'
            }`}
          >
            All Competitions
          </button>
          {leagues.map(([id, name]) => (
            <button
              key={id}
              onClick={() => setLeagueFilter(id)}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                leagueFilter === id
                  ? 'bg-[#152e5d] text-emerald-400 border border-emerald-500/40'
                  : 'bg-[#0a152a] text-slate-400 hover:text-white border border-[#14264b]'
              }`}
            >
              {name}
            </button>
          ))}
        </div>
      </div>

      {/* Match Cards Grid */}
      {filteredMatches.length === 0 ? (
        <div className="py-16 text-center text-slate-400 rounded-2xl bg-[#091326] border border-[#14264b]">
          <Filter className="w-10 h-10 text-slate-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-300">No matches found</p>
          <p className="text-xs text-slate-500 mt-1">
            Try adjusting your search query or selecting a different status filter.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredMatches.map((m) => (
            <MatchCard key={m.id} match={m} />
          ))}
        </div>
      )}
    </div>
  );
};
