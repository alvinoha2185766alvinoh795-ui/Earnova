import React, { useState } from 'react';
import { Sparkles, Trophy, Coins, RotateCcw, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

interface PlayingCard {
  suit: '♠' | '♥' | '♦' | '♣';
  value: string;
  score: number;
}

const SUITS: Array<'♠' | '♥' | '♦' | '♣'> = ['♠', '♥', '♦', '♣'];
const VALUES = [
  { val: '2', score: 2 },
  { val: '3', score: 3 },
  { val: '4', score: 4 },
  { val: '5', score: 5 },
  { val: '6', score: 6 },
  { val: '7', score: 7 },
  { val: '8', score: 8 },
  { val: '9', score: 9 },
  { val: '10', score: 10 },
  { val: 'J', score: 10 },
  { val: 'Q', score: 10 },
  { val: 'K', score: 10 },
  { val: 'A', score: 11 },
];

const drawRandomCard = (): PlayingCard => {
  const suit = SUITS[Math.floor(Math.random() * SUITS.length)];
  const item = VALUES[Math.floor(Math.random() * VALUES.length)];
  return { suit, value: item.val, score: item.score };
};

const calculateHandScore = (hand: PlayingCard[]): number => {
  let score = 0;
  let aceCount = 0;

  hand.forEach((card) => {
    score += card.score;
    if (card.value === 'A') aceCount++;
  });

  while (score > 21 && aceCount > 0) {
    score -= 10;
    aceCount--;
  }

  return score;
};

export const TwentyOneGame: React.FC = () => {
  const { user, updateUser, refillDemoPoints } = useEarnova();

  const [stake, setStake] = useState<number>(50);
  const [playerHand, setPlayerHand] = useState<PlayingCard[]>([]);
  const [dealerHand, setDealerHand] = useState<PlayingCard[]>([]);
  const [gameState, setGameState] = useState<'IDLE' | 'PLAYING' | 'RESOLVED'>('IDLE');
  const [gameResult, setGameResult] = useState<string | null>(null);
  const [winPayout, setWinPayout] = useState<number>(0);

  const startNewDeal = () => {
    if (user.points < stake) {
      alert('Insufficient virtual points. Use demo refill to top up EP.');
      return;
    }

    sound.playTap();
    updateUser({ points: Math.max(0, user.points - stake) });

    const p1 = drawRandomCard();
    const d1 = drawRandomCard();
    const p2 = drawRandomCard();
    const d2 = drawRandomCard();

    const pHand = [p1, p2];
    const dHand = [d1, d2];

    setPlayerHand(pHand);
    setDealerHand(dHand);
    setGameState('PLAYING');
    setGameResult(null);
    setWinPayout(0);

    // Check for natural 21 blackjack
    const pScore = calculateHandScore(pHand);
    if (pScore === 21) {
      setTimeout(() => {
        resolveDealer(pHand, dHand);
      }, 500);
    }
  };

  const handleHit = () => {
    if (gameState !== 'PLAYING') return;
    sound.playTap();

    const nextCard = drawRandomCard();
    const updated = [...playerHand, nextCard];
    setPlayerHand(updated);

    const score = calculateHandScore(updated);
    if (score > 21) {
      // Bust
      sound.playCrash();
      setGameState('RESOLVED');
      setGameResult('BUST! You exceeded 21.');
      setWinPayout(0);
    } else if (score === 21) {
      resolveDealer(updated, dealerHand);
    }
  };

  const handleStand = () => {
    if (gameState !== 'PLAYING') return;
    sound.playTap();
    resolveDealer(playerHand, dealerHand);
  };

  const resolveDealer = (finalPlayerHand: PlayingCard[], currentDealerHand: PlayingCard[]) => {
    let dHand = [...currentDealerHand];
    let dScore = calculateHandScore(dHand);

    // Dealer draws to 16, stands on 17
    while (dScore < 17) {
      dHand.push(drawRandomCard());
      dScore = calculateHandScore(dHand);
    }

    setDealerHand(dHand);
    setGameState('RESOLVED');

    const pScore = calculateHandScore(finalPlayerHand);

    if (dScore > 21) {
      // Dealer Bust, Player Wins!
      sound.playCashout();
      const win = stake * 2;
      setWinPayout(win);
      setGameResult(`DEALER BUST (${dScore})! You Win!`);
      updateUser({ points: user.points + win });
    } else if (pScore > dScore) {
      // Player Higher
      sound.playCashout();
      const win = stake * 2;
      setWinPayout(win);
      setGameResult(`VICTORY! ${pScore} beats Dealer ${dScore}!`);
      updateUser({ points: user.points + win });
    } else if (pScore === dScore) {
      // Push / Tie
      sound.playTap();
      setWinPayout(stake);
      setGameResult(`PUSH! Scores tied at ${pScore}. Stake returned.`);
      updateUser({ points: user.points + stake });
    } else {
      // Dealer Wins
      sound.playCrash();
      setWinPayout(0);
      setGameResult(`Dealer wins with ${dScore} against your ${pScore}.`);
    }
  };

  const playerScore = calculateHandScore(playerHand);
  const dealerScore = calculateHandScore(
    gameState === 'PLAYING' ? [dealerHand[0]] : dealerHand
  );

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Title */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Twenty One · Tactical Blackjack</span>
        </div>
        <h2 className="font-display font-black text-2xl text-white">Twenty One</h2>
        <p className="text-xs text-slate-400">Target 21 and beat the dealer's hand to double your EP!</p>
      </div>

      {/* Card Table Felt */}
      <div className="p-6 rounded-3xl bg-gradient-to-b from-[#0a1836] via-[#071329] to-[#040c1a] border-2 border-[#193a73] shadow-2xl space-y-6">
        {/* Dealer Hand Zone */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Dealer's Hand</span>
            <span className="font-mono font-bold text-white">
              Score: {gameState === 'PLAYING' ? `${dealerScore} + ?` : dealerScore}
            </span>
          </div>

          <div className="flex items-center gap-2 justify-center py-2">
            {dealerHand.map((c, i) => {
              const hide = gameState === 'PLAYING' && i === 1;
              const isRed = c.suit === '♥' || c.suit === '♦';
              return (
                <div
                  key={i}
                  className={`w-16 h-24 rounded-xl flex flex-col justify-between p-2 shadow-lg border text-base font-bold ${
                    hide
                      ? 'bg-blue-900 border-blue-700 text-blue-400 flex items-center justify-center'
                      : 'bg-white border-slate-300 text-slate-900'
                  }`}
                >
                  {hide ? (
                    <span className="text-2xl">🂠</span>
                  ) : (
                    <>
                      <div className={`text-left leading-none ${isRed ? 'text-rose-600' : 'text-slate-900'}`}>
                        {c.value}
                        <span className="text-xs block">{c.suit}</span>
                      </div>
                      <div className="text-center text-xl">{c.suit}</div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Player Hand Zone */}
        <div className="space-y-2 border-t border-[#13274f] pt-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Your Hand</span>
            <span className="font-mono font-bold text-emerald-400">
              Score: {playerScore}
            </span>
          </div>

          <div className="flex items-center gap-2 justify-center py-2">
            {playerHand.map((c, i) => {
              const isRed = c.suit === '♥' || c.suit === '♦';
              return (
                <div
                  key={i}
                  className="w-16 h-24 rounded-xl bg-white border border-slate-300 shadow-lg flex flex-col justify-between p-2 text-base font-bold text-slate-900"
                >
                  <div className={`text-left leading-none ${isRed ? 'text-rose-600' : 'text-slate-900'}`}>
                    {c.value}
                    <span className="text-xs block">{c.suit}</span>
                  </div>
                  <div className="text-center text-xl">{c.suit}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Game Result Banner */}
        {gameResult && (
          <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-400 text-center animate-in zoom-in-95 duration-150">
            <span className="font-display font-black text-sm text-white block">{gameResult}</span>
            {winPayout > 0 && (
              <span className="text-emerald-400 font-mono font-bold text-xs mt-0.5 block">
                +{winPayout} EP Added
              </span>
            )}
          </div>
        )}

        {/* Action Buttons */}
        {gameState === 'PLAYING' ? (
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={handleHit}
              className="py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider cursor-pointer active:scale-95 transition-all shadow-md"
            >
              HIT (+ CARD)
            </button>
            <button
              type="button"
              onClick={handleStand}
              className="py-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider cursor-pointer active:scale-95 transition-all shadow-md"
            >
              STAND (HOLD)
            </button>
          </div>
        ) : (
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-2">
              {[25, 50, 100, 250].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setStake(amt)}
                  className={`flex-1 py-2 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                    stake === amt
                      ? 'bg-blue-500 text-white border-blue-400'
                      : 'bg-[#081224] border-[#162c57] text-slate-300 hover:text-white'
                  }`}
                >
                  {amt}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={startNewDeal}
              disabled={user.points < stake}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-500 via-emerald-500 to-emerald-400 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg active:scale-95 transition-all cursor-pointer disabled:opacity-50"
            >
              DEAL CARDS ({stake} EP)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
