import React, { useMemo } from 'react';
import {
  Flame,
  TrendingUp,
  Sparkles,
  Trophy,
  ShieldCheck,
  ChevronRight,
  Clock,
  Coins,
  Brain,
  GraduationCap,
  Swords,
  WifiOff,
  Wallet,
  Star,
  Activity,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Award,
  Plane,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { MatchCard } from '../components/MatchCard';
import { useTranslation } from '../utils/i18n';
import { GameCardArtwork } from '../components/GameCardArtwork';
import { SIX_ORIGINAL_GAMES } from './NovaPlayView';

interface HomeViewProps {
  onNavigateToMatches: () => void;
  onNavigateToLive: () => void;
  onNavigateToHistory: () => void;
  onNavigateToLeaderboard: () => void;
  onNavigateToUCL: () => void;
  onNavigateToAcademy: () => void;
  onNavigateToCommunity: () => void;
  onNavigateToTrivia: () => void;
  onNavigateToWallet: () => void;
  onNavigateToFavorites: () => void;
  onNavigateToProfile?: () => void;
  onNavigateToDeposit?: () => void;
  onNavigateToWithdraw?: () => void;
  onNavigateToNovaPlay?: (gameId?: string) => void;
}

const HomeViewComponent: React.FC<HomeViewProps> = ({
  onNavigateToMatches,
  onNavigateToLive,
  onNavigateToHistory,
  onNavigateToLeaderboard,
  onNavigateToUCL,
  onNavigateToAcademy,
  onNavigateToCommunity,
  onNavigateToTrivia,
  onNavigateToWallet,
  onNavigateToFavorites,
  onNavigateToProfile,
  onNavigateToDeposit,
  onNavigateToWithdraw,
  onNavigateToNovaPlay,
}) => {
  const { matches, user, placedPredictions, claimDailyBonus, language, lowDataMode, favoriteTeamIds } = useEarnova();
  const { t } = useTranslation(language);
  const [selectedCompetition, setSelectedCompetition] = React.useState<string>('All competitions');
  const [favoriteGames, setFavoriteGames] = React.useState<Record<string, boolean>>({
    temple_treasure: true,
    pharaohs_treasure: true,
    royal_crown: true,
  });

  // Current bundled fixtures are demonstration data. Map only competitions
  // represented in that data; do not label unrelated fixtures as real leagues.
  const competitionAliases: Record<string, string[]> = {
    'All competitions': [],
    'Premier League': ['Premier Circuit'],
    'LaLiga': [],
    'Bundesliga': [],
    'Serie A': ['Serie Elite'],
    'Ligue 1': [],
    'Champions League': ['European Champions Cup'],
    'Europa League': [],
    'Kenyan Premier League': [],
  };
  const selectedMatches = useMemo(() => {
    if (selectedCompetition === 'All competitions') return matches;
    const aliases = competitionAliases[selectedCompetition] || [];
    return matches.filter((m) => aliases.includes(m.leagueName));
  }, [matches, selectedCompetition]);
  const liveMatches = useMemo(() => selectedMatches.filter((m) => m.status === 'live'), [selectedMatches]);
  const featuredMatch = useMemo(
    () => selectedMatches.find((m) => m.isFeatured && m.status !== 'finished') || selectedMatches.find((m) => m.status !== 'finished'),
    [selectedMatches]
  );
  const upcomingToday = useMemo(
    () => selectedMatches.filter((m) => m.dateKey === 'today' && m.status === 'upcoming'),
    [selectedMatches]
  );

  const pendingPredictions = useMemo(
    () => (placedPredictions || []).filter((p) => p && p.status === 'pending'),
    [placedPredictions]
  );
  const pendingStakesTotal = useMemo(
    () => pendingPredictions.reduce((sum, p) => sum + (p?.stake || 0), 0),
    [pendingPredictions]
  );

  // Favorite clubs matches
  const favoriteMatches = useMemo(
    () =>
      (matches || []).filter(
        (m) =>
          m &&
          m.homeTeam &&
          m.awayTeam &&
          Array.isArray(favoriteTeamIds) &&
          (favoriteTeamIds.includes(m.homeTeam.id) ||
            favoriteTeamIds.includes(m.awayTeam.id))
      ),
    [matches, favoriteTeamIds]
  );

  const winRate = useMemo(
    () =>
      user && user.totalPredictions > 0
        ? Math.round(((user.wonPredictions || 0) / user.totalPredictions) * 100)
        : 0,
    [user?.totalPredictions, user?.wonPredictions]
  );

  const handleClaimBonus = () => {
    claimDailyBonus();
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-12">
      {/* Low Data Mode Active Pill */}
      {lowDataMode && (
        <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between text-xs text-amber-300">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Smart Low-Data Mode:</strong> Animations minimized and update frequencies optimized for low network bandwidth.
            </span>
          </div>
          <span className="font-mono text-[10px] text-amber-400 font-bold bg-amber-900/60 px-2 py-0.5 rounded">
            SAVER ACTIVE
          </span>
        </div>
      )}

      {/* 1. Tactical Dashboard KPI Strip & User Greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-[#0c1830] via-[#0e1d3b] to-[#0a152d] border border-[#162c57] shadow-xl">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={onNavigateToProfile}
            className="w-14 h-14 rounded-2xl bg-[#132752] border border-emerald-500/40 flex items-center justify-center text-3xl shadow-inner cursor-pointer hover:scale-105 active:scale-95 transition-transform touch-manipulation"
            title="View User Profile"
            aria-label="View Profile"
          >
            {user.avatar}
          </button>
          <div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onNavigateToProfile}
                className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight hover:text-emerald-400 transition-colors text-left cursor-pointer touch-manipulation"
              >
                {user.username}
              </button>
              <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/40">
                {user.tier}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5 flex-wrap">
              <button
                type="button"
                onClick={onNavigateToLeaderboard}
                className="hover:text-emerald-300 font-medium underline underline-offset-2 cursor-pointer touch-manipulation"
              >
                Rank #{user.rank}
              </button>
              <span>·</span>
              <span>Win Streak: <strong className="text-amber-400">{user.winStreak}W</strong> (Best: {user.longestStreak}W)</span>
            </p>
          </div>
        </div>

        {/* Quick Wallet CTA in Header */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onNavigateToDeposit || onNavigateToWallet}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#081224] border border-[#193264] hover:border-emerald-500/50 text-left transition-colors cursor-pointer group touch-manipulation active:scale-95"
            title="Demo Deposit & Refill Points"
          >
            <Coins className="w-4 h-4 text-emerald-400 shrink-0 group-hover:scale-110 transition-transform" />
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                Virtual Balance
              </span>
              <span className="font-mono font-bold text-sm sm:text-base text-white tabular-nums">
                {(user?.points ?? 0).toLocaleString()} EP
              </span>
            </div>
            <span className="ml-2 px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-bold text-[10px] uppercase">
              + Refill
            </span>
          </button>
        </div>
      </div>

      {/* 2. 4 Dashboard KPI Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Virtual Points Balance */}
        <button
          type="button"
          onClick={onNavigateToWallet}
          className="text-left w-full p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] relative overflow-hidden cursor-pointer hover:border-emerald-500/40 transition-colors group touch-manipulation active:scale-98"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Virtual EP</span>
            <Wallet className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="font-mono font-extrabold text-2xl sm:text-3xl text-white tabular-nums">
              {(user?.points ?? 0).toLocaleString()}
            </span>
            <span className="text-xs font-bold text-emerald-400">EP</span>
          </div>
          <span className="text-[11px] text-emerald-400 mt-1 block font-medium">
            Manage Wallet & Ledger →
          </span>
        </button>

        {/* Accuracy Rate */}
        <div className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Accuracy Rate</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-mono font-extrabold text-2xl sm:text-3xl text-emerald-400 tabular-nums">
              {winRate}%
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {user.wonPredictions} Won of {user.totalPredictions} Placed
          </span>
        </div>

        {/* In-Play Predictions */}
        <button
          type="button"
          onClick={onNavigateToHistory}
          className="text-left w-full p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] cursor-pointer hover:border-[#1e3c75] transition-colors touch-manipulation active:scale-98"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Active In-Play</span>
            <Clock className="w-4 h-4 text-sky-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="font-mono font-extrabold text-2xl sm:text-3xl text-sky-400 tabular-nums">
              {pendingPredictions.length}
            </span>
            <span className="text-xs text-slate-400 font-mono">slips</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {pendingStakesTotal.toLocaleString()} EP at risk →
          </span>
        </button>

        {/* Daily Bonus Claim Widget */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#0e2145] to-[#0c1830] border border-emerald-500/30 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-300">
            <span className="font-semibold text-emerald-300">Daily Bonus</span>
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="my-2">
            <button
              type="button"
              onClick={handleClaimBonus}
              className="w-full py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs tracking-wide shadow-md shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer touch-manipulation"
            >
              {t('claimDailyReward')}
            </button>
          </div>
          <span className="text-[10px] text-slate-400 text-center">
            Free virtual replenishment
          </span>
        </div>
      </div>

      {/* Sports and competition shortcuts: both rows scroll horizontally on mobile */}
      <section className="space-y-3 rounded-2xl border border-[#162c57] bg-[#0a162d] p-3 sm:p-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-sm font-extrabold uppercase tracking-wider text-white">Sports</h2>
          <button type="button" onClick={onNavigateToMatches} className="shrink-0 text-xs font-semibold text-emerald-400">
            All fixtures →
          </button>
        </div>
        <div className="flex gap-2 overflow-x-auto whitespace-nowrap pb-2 [scrollbar-width:thin]">
          {[
            ['⚽', 'Football'],
            ['🏀', 'Basketball'],
            ['🎾', 'Tennis'],
            ['🏉', 'Rugby'],
            ['🏏', 'Cricket'],
          ].map(([icon, label], index) => (
            <button
              key={label}
              type="button"
              onClick={onNavigateToMatches}
              className={`flex shrink-0 items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-bold transition-colors touch-manipulation ${
                index === 0
                  ? 'border-emerald-400/60 bg-emerald-500/15 text-emerald-300'
                  : 'border-[#263b5b] bg-[#101f39] text-slate-200 hover:border-emerald-400/40'
              }`}
            >
              <span aria-hidden="true">{icon}</span>
              <span>{label}</span>
            </button>
          ))}
        </div>

        <div className="border-t border-[#1a2d4d] pt-3">
          <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">Competitions</h3>
          <div className="flex gap-2 overflow-x-auto whitespace-nowrap pb-2 [scrollbar-width:thin]">
            {[
              'All competitions',
              'Premier League',
              'LaLiga',
              'Bundesliga',
              'Serie A',
              'Ligue 1',
              'Champions League',
              'Europa League',
              'Kenyan Premier League',
            ].map((league, index) => (
              <button
                key={league}
                type="button"
                onClick={onNavigateToMatches}
                className={`shrink-0 rounded-full border px-3.5 py-2 text-xs font-semibold transition-colors touch-manipulation ${
                  index === 0
                    ? 'border-emerald-400/60 bg-emerald-500/15 text-emerald-300'
                    : 'border-[#263b5b] bg-[#101f39] text-slate-300 hover:border-emerald-400/40 hover:text-white'
                }`}
              >
                {league}
              </button>
            ))}
          </div>
        </div>
        <p className="text-[10px] text-slate-500">Selected: {selectedCompetition}. Swipe sideways to browse competitions. Fixture data currently uses demo leagues.</p>
      </section>

      {/* 2.5 NovaPlay Aviator Spotlight Feature Card (PRIORITY 1) */}
      <div className="relative p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-[#0a1733] via-[#0d1f42] to-[#081226] border border-amber-500/40 shadow-2xl overflow-hidden transform-gpu">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
          <div className="space-y-2 max-w-xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-amber-400 shadow-sm shadow-amber-400/80" />
              <span className="text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                FEATURED · NOVAPLAY AVIATOR
              </span>
              <span className="text-[11px] text-slate-400 font-mono">100% Free Virtual Points</span>
            </div>

            <h3 className="font-display font-black text-xl sm:text-2xl text-white tracking-tight">
              Nova Flight: Aviator Multiplier Flight
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Experience the adrenaline of Earnova's Aviator-style supersonic flight simulator! Watch the jet ascend, ride multipliers up to <strong className="text-amber-400">50x</strong>, and cash out before the flight departs. Includes 7 original arcade games: Nova Flight, Royal Spin, Lucky Reels, Dice Arena, Rocket Rush, Twenty One & Lucky Wheel.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
            {onNavigateToNovaPlay && (
              <button
                type="button"
                onClick={() => onNavigateToNovaPlay()}
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-emerald-400 to-emerald-500 text-slate-950 font-display font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 hover:brightness-110 active:scale-95 transition-all cursor-pointer touch-manipulation"
              >
                <Plane className="w-4 h-4 transform -rotate-45" />
                <span>PLAY NOVAPLAY AVIATOR →</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 3. Quick Action Launcher Bar (Connecting all primary sections) */}
      <div className="grid grid-cols-4 sm:grid-cols-5 lg:grid-cols-9 gap-2 sm:gap-3">
        {onNavigateToNovaPlay && (
          <button
            type="button"
            onClick={() => onNavigateToNovaPlay()}
            className="p-3 rounded-2xl bg-[#0c1830] border border-amber-500/50 hover:border-amber-400 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95 bg-amber-950/20"
          >
            <Plane className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform transform -rotate-45" />
            <span className="text-xs font-bold text-amber-300">NovaPlay</span>
            <span className="text-[10px] text-amber-400 font-mono">Aviator 50x</span>
          </button>
        )}

        <button
          type="button"
          onClick={onNavigateToMatches}
          className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/40 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95"
        >
          <Trophy className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-bold text-white">Fixtures</span>
          <span className="text-[10px] text-slate-400">All Markets</span>
        </button>

        <button
          type="button"
          onClick={onNavigateToLive}
          className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/40 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95"
        >
          <div className="relative">
            <Activity className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/80" />
          </div>
          <span className="text-xs font-bold text-white">Live Centre</span>
          <span className="text-[10px] text-slate-400">{liveMatches.length} In-Play</span>
        </button>

        <button
          type="button"
          onClick={onNavigateToWallet}
          className="p-3 rounded-2xl bg-[#0c1830] border border-emerald-500/40 hover:border-emerald-400 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95 bg-emerald-950/20"
        >
          <Wallet className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-bold text-white">Wallet</span>
          <span className="text-[10px] text-emerald-300">Refill & Activity</span>
        </button>

        <button
          type="button"
          onClick={onNavigateToLeaderboard}
          className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/40 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95"
        >
          <Award className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-bold text-white">Ranks</span>
          <span className="text-[10px] text-slate-400">#{user.rank} Global</span>
        </button>

        <button
          type="button"
          onClick={onNavigateToProfile}
          className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/40 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95"
        >
          <div className="w-5 h-5 rounded-full bg-[#132752] border border-emerald-500/40 flex items-center justify-center text-xs group-hover:scale-110 transition-transform">
            {user.avatar}
          </div>
          <span className="text-xs font-bold text-white">Profile</span>
          <span className="text-[10px] text-slate-400">Account & Audio</span>
        </button>

        <button
          type="button"
          onClick={onNavigateToAcademy}
          className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/40 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95"
        >
          <GraduationCap className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-bold text-white">Academy</span>
          <span className="text-[10px] text-slate-400">Courses</span>
        </button>

        <button
          type="button"
          onClick={onNavigateToTrivia}
          className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] hover:border-emerald-500/40 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95"
        >
          <Brain className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-bold text-white">Trivia</span>
          <span className="text-[10px] text-slate-400">+100 EP Daily</span>
        </button>

        <button
          type="button"
          onClick={onNavigateToFavorites}
          className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] hover:border-amber-400/40 flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer group touch-manipulation active:scale-95"
        >
          <Star className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-bold text-white">Favorites</span>
          <span className="text-[10px] text-slate-400">{favoriteTeamIds.length} Clubs</span>
        </button>
      </div>
      {/* 3.5 "Other Games" Gallery Section Matching Reference Screenshot */}
      <div className="space-y-4 pt-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-1.5 h-6 bg-yellow-400 rounded-full" />
            <h2 className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight">
              Other Games
            </h2>
          </div>

          {onNavigateToNovaPlay && (
            <button
              type="button"
              onClick={() => onNavigateToNovaPlay()}
              className="px-3.5 py-1.5 rounded-full border border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 transition-all font-display font-bold text-xs flex items-center gap-1 cursor-pointer touch-manipulation active:scale-95"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* 3-Column / 2-Column Responsive Card Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
          {SIX_ORIGINAL_GAMES.map((game) => {
            const isFav = !!favoriteGames[game.id];
            return (
              <div
                key={game.id}
                onClick={() => onNavigateToNovaPlay?.(game.id)}
                className="rounded-2xl sm:rounded-3xl bg-[#0a162d] border border-[#162c57] hover:border-yellow-400/60 transition-all flex flex-col justify-between overflow-hidden cursor-pointer group touch-manipulation hover:scale-[1.02] active:scale-98 shadow-lg"
              >
                {/* Artwork */}
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#060e1d]">
                  <GameCardArtwork gameId={game.artworkKey} />
                </div>

                {/* Footer: Title below Image + Favorite Star */}
                <div className="p-2.5 sm:p-3 flex items-center justify-between gap-2 bg-[#0c1830]">
                  <div className="min-w-0">
                    <h3 className="font-display font-extrabold text-xs sm:text-sm text-white group-hover:text-yellow-300 transition-colors truncate">
                      {game.title}
                    </h3>
                    <p className="text-[10px] text-slate-400 truncate">
                      {game.subtitle}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setFavoriteGames((prev) => ({ ...prev, [game.id]: !prev[game.id] }));
                    }}
                    className="p-1 sm:p-1.5 rounded-lg hover:bg-white/10 text-slate-400 transition-all cursor-pointer shrink-0"
                    title={isFav ? 'Remove from Favourites' : 'Add to Favourites'}
                  >
                    <Star
                      className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform active:scale-125 ${
                        isFav
                          ? 'fill-yellow-400 text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.6)]'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Promo Bar matching screenshot */}
        <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-[#0d2218] via-[#08182b] to-[#1a1506] border border-yellow-400/30 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-xl">🪙</span>
            <div>
              <span className="text-[10px] uppercase text-yellow-400 font-bold block">Start from as low as</span>
              <strong className="text-white font-mono text-sm">KSh 10 (Virtual EP)</strong>
            </div>
          </div>
          <div className="h-6 w-px bg-yellow-400/30 hidden sm:block" />
          <div className="flex items-center gap-2 text-right sm:text-left">
            <span className="text-xl">🏆</span>
            <div>
              <span className="text-[10px] uppercase text-emerald-400 font-bold block">Play with more</span>
              <strong className="text-yellow-300 font-display text-sm">Up to your desire!</strong>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Active In-Play Predictions Highlight */}
      {pendingPredictions.length > 0 && (
        <div className="p-5 rounded-3xl bg-[#0c1830] border border-sky-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-sky-400 shadow-sm shadow-sky-400/80" />
              <h3 className="font-display font-bold text-base text-white">
                Active Predictions In Play ({pendingPredictions.length})
              </h3>
            </div>
            <button
              onClick={onNavigateToHistory}
              className="text-xs font-semibold text-sky-400 hover:underline cursor-pointer"
            >
              Full Slip History →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingPredictions.slice(0, 2).map((pred) => (
              <div
                key={pred.id}
                className="p-3.5 rounded-2xl bg-[#081224] border border-[#14264b] flex items-center justify-between gap-3"
              >
                <div>
                  <span className="text-[10px] font-mono text-sky-400 font-bold uppercase tracking-wider block">
                    {pred.type === 'accumulator' ? `ACCUMULATOR (${pred.selections?.length || 0} Legs)` : 'SINGLE PICK'}
                  </span>
                  <p className="text-xs font-semibold text-white mt-0.5 truncate max-w-[220px]">
                    {(pred.selections || []).map((s) => s.selectionLabel).join(' · ')}
                  </p>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Staked {pred.stake || 0} EP @ {pred.totalOdds || 1}x
                  </span>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                    Potential Return
                  </span>
                  <span className="font-mono font-bold text-emerald-400 text-sm sm:text-base">
                    +{Number(pred.potentialReturn || 0).toLocaleString()} EP
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. Followed Teams Fixture Alert Strip */}
      {favoriteMatches.length > 0 && (
        <div className="p-4 rounded-2xl bg-[#0e1d3b] border border-amber-500/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
              <Star className="w-4 h-4 fill-amber-400" />
            </div>
            <div>
              <h4 className="font-bold text-xs sm:text-sm text-white">
                Followed Club Match Day
              </h4>
              <p className="text-xs text-slate-300">
                You have {favoriteMatches.length} fixtures involving your favorite clubs today.
              </p>
            </div>
          </div>
          <button
            onClick={onNavigateToFavorites}
            className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs whitespace-nowrap cursor-pointer shrink-0"
          >
            View Alerts
          </button>
        </div>
      )}

      {/* 6. Live Matches Section */}
      {liveMatches.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/80" />
              <h3 className="font-display font-bold text-lg text-white">
                {t('liveNow')} ({liveMatches.length})
              </h3>
            </div>
            <button
              onClick={onNavigateToLive}
              className="text-xs font-semibold text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>{t('viewTracker')}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {liveMatches.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        </div>
      )}

      {/* 7. Featured Match of the Day */}
      {selectedCompetition !== 'All competitions' && selectedMatches.length === 0 && (
        <div className="rounded-2xl border border-[#263b5b] bg-[#101f39] p-4 text-sm text-slate-300">
          No demo fixtures are currently available for {selectedCompetition}. Choose another competition or All competitions.
        </div>
      )}
      {featuredMatch && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-lg text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-emerald-400" />
              <span>Match of the Day</span>
            </h3>
            <button
              onClick={onNavigateToMatches}
              className="text-xs font-semibold text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>{t('fixtures')}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <MatchCard key={`featured-${featuredMatch.id}`} match={featuredMatch} featured={true} />
        </div>
      )}

      {/* 8. Upcoming Today Matches */}
      {upcomingToday.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-lg text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>Upcoming Today</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              {upcomingToday.length} fixtures scheduled
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {upcomingToday.slice(0, 4).map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        </div>
      )}

      {/* 9. Prediction Academy & Daily Trivia Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Academy Highlight */}
        <button
          type="button"
          onClick={onNavigateToAcademy}
          className="text-left p-5 rounded-3xl bg-gradient-to-br from-[#0c1830] to-[#09152b] border border-[#162c57] hover:border-emerald-500/40 transition-all cursor-pointer group flex items-start gap-4 touch-manipulation active:scale-98"
        >
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 group-hover:scale-105 transition-transform">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
              Interactive Training
            </span>
            <h4 className="font-display font-bold text-base text-white mt-0.5">
              Prediction Academy
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              Master football probability, xG modeling & value odds to earn certified credentials.
            </p>
          </div>
        </button>

        {/* Community & Duels Highlight */}
        <button
          type="button"
          onClick={onNavigateToCommunity}
          className="text-left p-5 rounded-3xl bg-gradient-to-br from-[#0c1830] to-[#09152b] border border-[#162c57] hover:border-emerald-500/40 transition-all cursor-pointer group flex items-start gap-4 touch-manipulation active:scale-98"
        >
          <div className="w-12 h-12 rounded-2xl bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400 shrink-0 group-hover:scale-105 transition-transform">
            <Swords className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400">
              Social Community
            </span>
            <h4 className="font-display font-bold text-base text-white mt-0.5">
              Fan Community & Duels
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              Debate tactics, challenge friends in head-to-head prediction duels, and share insights.
            </p>
          </div>
        </button>
      </div>
    </div>
  );
};

export const HomeView = React.memo(HomeViewComponent);
