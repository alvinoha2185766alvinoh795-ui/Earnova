import React, { useState } from 'react';
import { Sparkles, RefreshCw, Trophy, Zap, Coins, CheckCircle2 } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type GemType = 'emerald' | 'sapphire' | 'ruby' | 'amethyst' | 'topaz';

interface Cell {
  id: string;
  type: GemType;
}

const GEM_CONFIG: Record<GemType, { color: string; bg: string; icon: string; border: string }> = {
  emerald: { color: '#10b981', bg: 'bg-emerald-500/20', icon: '💎', border: 'border-emerald-500/50' },
  sapphire: { color: '#38bdf8', bg: 'bg-sky-500/20', icon: '🔷', border: 'border-sky-500/50' },
  ruby: { color: '#ef4444', bg: 'bg-rose-500/20', icon: '🔴', border: 'border-rose-500/50' },
  amethyst: { color: '#a855f7', bg: 'bg-purple-500/20', icon: '🟣', border: 'border-purple-500/50' },
  topaz: { color: '#f59e0b', bg: 'bg-amber-500/20', icon: '🟡', border: 'border-amber-500/50' },
};

const GEM_TYPES: GemType[] = ['emerald', 'sapphire', 'ruby', 'amethyst', 'topaz'];

const createInitialGrid = (): Cell[][] => {
  return Array(5)
    .fill(null)
    .map((_, r) =>
      Array(5)
        .fill(null)
        .map((_, c) => ({
          id: `${r}-${c}-${Math.random()}`,
          type: GEM_TYPES[Math.floor(Math.random() * GEM_TYPES.length)],
        }))
    );
};

export const CrystalGridGame: React.FC = () => {
  const { user, updateUser } = useEarnova();

  const [grid, setGrid] = useState<Cell[][]>(createInitialGrid);
  const [selectedCell, setSelectedCell] = useState<{ r: number; c: number } | null>(null);
  const [score, setScore] = useState<number>(0);
  const [movesLeft, setMovesLeft] = useState<number>(15);
  const [combo, setCombo] = useState<number>(1);
  const [epRewardEarned, setEpRewardEarned] = useState<number>(0);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);

  const handleCellClick = (r: number, c: number) => {
    if (isGameOver || movesLeft <= 0) return;
    sound.playTap();

    if (!selectedCell) {
      setSelectedCell({ r, c });
      return;
    }

    // Check adjacency
    const isAdjacent =
      (Math.abs(selectedCell.r - r) === 1 && selectedCell.c === c) ||
      (Math.abs(selectedCell.c - c) === 1 && selectedCell.r === r);

    if (isAdjacent) {
      // Swap cells
      const newGrid = grid.map((row) => [...row]);
      const temp = newGrid[selectedCell.r][selectedCell.c].type;
      newGrid[selectedCell.r][selectedCell.c].type = newGrid[r][c].type;
      newGrid[r][c].type = temp;

      // Find matches in row or col
      const targetType = newGrid[r][c].type;
      let matchedCount = 1;

      // Check horizontal matches around (r,c)
      let left = c - 1;
      while (left >= 0 && newGrid[r][left].type === targetType) {
        matchedCount++;
        left--;
      }
      let right = c + 1;
      while (right < 5 && newGrid[r][right].type === targetType) {
        matchedCount++;
        right++;
      }

      if (matchedCount >= 3) {
        // Cascade match!
        sound.playCashout();
        const pointsGained = matchedCount * 100 * combo;
        setScore((prev) => prev + pointsGained);
        setCombo((prev) => prev + 1);

        // Regenerate matched items
        for (let col = left + 1; col < right; col++) {
          newGrid[r][col] = {
            id: `${r}-${col}-${Math.random()}`,
            type: GEM_TYPES[Math.floor(Math.random() * GEM_TYPES.length)],
          };
        }
      } else {
        setCombo(1);
      }

      setGrid(newGrid);
      setMovesLeft((prev) => {
        const next = prev - 1;
        if (next <= 0) {
          setIsGameOver(true);
          // Award final EP
          const finalReward = Math.max(50, Math.floor(score / 5));
          setEpRewardEarned(finalReward);
          updateUser({ points: user.points + finalReward });
        }
        return next;
      });
      setSelectedCell(null);
    } else {
      setSelectedCell({ r, c });
    }
  };

  const handleReset = () => {
    setGrid(createInitialGrid());
    setSelectedCell(null);
    setScore(0);
    setMovesLeft(15);
    setCombo(1);
    setIsGameOver(false);
    setEpRewardEarned(0);
    sound.playTap();
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Title */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs font-bold">
          <Zap className="w-3.5 h-3.5" />
          <span>NovaPlay Cascading Crystals</span>
        </div>
        <h2 className="font-display font-extrabold text-2xl text-white">Crystal Grid</h2>
        <p className="text-xs text-slate-400">Match 3 or more gems to trigger cascading combos & earn EP!</p>
      </div>

      {/* KPI HUD */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Score</span>
          <span className="font-mono font-black text-xl text-emerald-400 tabular-nums">{score}</span>
        </div>
        <div className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Moves Left</span>
          <span className="font-mono font-black text-xl text-white tabular-nums">{movesLeft}</span>
        </div>
        <div className="p-3 rounded-2xl bg-[#0c1830] border border-[#162c57] text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Combo</span>
          <span className="font-mono font-black text-xl text-amber-400 tabular-nums">{combo}x</span>
        </div>
      </div>

      {/* 5x5 Game Board */}
      <div className="p-4 rounded-3xl bg-[#0c1830] border border-[#162c57] shadow-xl">
        <div className="grid grid-cols-5 gap-2">
          {grid.map((row, r) =>
            row.map((cell, c) => {
              const isSelected = selectedCell?.r === r && selectedCell?.c === c;
              const cfg = GEM_CONFIG[cell.type];
              return (
                <button
                  key={cell.id}
                  type="button"
                  onClick={() => handleCellClick(r, c)}
                  className={`w-full aspect-square rounded-2xl flex items-center justify-center text-2xl sm:text-3xl transition-all cursor-pointer touch-manipulation active:scale-90 border ${
                    cfg.bg
                  } ${cfg.border} ${
                    isSelected ? 'ring-2 ring-white scale-105 shadow-lg' : 'hover:scale-98'
                  }`}
                >
                  <span>{cfg.icon}</span>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Game Over Banner */}
      {isGameOver && (
        <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-400 text-center space-y-2 animate-in zoom-in-95 duration-150">
          <div className="text-xs uppercase font-bold text-emerald-400">Match Completed!</div>
          <div className="font-display font-black text-2xl text-white">
            Final Score: {score}
          </div>
          <p className="text-xs text-slate-300">
            Earned <strong className="text-emerald-400 font-mono">+{epRewardEarned} EP</strong> virtual bonus!
          </p>
          <button
            type="button"
            onClick={handleReset}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs uppercase tracking-wider"
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
};
