import React, { useState } from 'react';
import { Sparkles, Trophy, Coins, RotateCcw, ShieldCheck } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type DicePrediction = 'under7' | 'lucky7' | 'over7' | 'doubles' | 'snake_eyes' | 'midnight';

interface PredictionOption {
  id: DicePrediction;
  label: string;
  multiplier: number;
  condition: (d1: number, d2: number) => boolean;
}

const PREDICTIONS: PredictionOption[] = [
  { id: 'under7', label: 'Under 7 (2-6)', multiplier: 2.0, condition: (d1, d2) => d1 + d2 < 7 },
  { id: 'lucky7', label: 'Exact 7 (Lucky 7)', multiplier: 5.8, condition: (d1, d2) => d1 + d2 === 7 },
  { id: 'over7', label: 'Over 7 (8-12)', multiplier: 2.0, condition: (d1, d2) => d1 + d2 > 7 },
  { id: 'doubles', label: 'Doubles (Any Pair)', multiplier: 6.0, condition: (d1, d2) => d1 === d2 },
  { id: 'snake_eyes', label: 'Snake Eyes (Total 2)', multiplier: 30.0, condition: (d1, d2) => d1 === 1 && d2 === 1 },
  { id: 'midnight', label: 'Boxcars (Total 12)', multiplier: 30.0, condition: (d1, d2) => d1 === 6 && d2 === 6 },
];

const DICE_DOTS: Record<number, string> = {
  1: '⚀',
  2: '⚁',
  3: '⚂',
  4: '⚃',
  5: '⚄',
  6: '⚅',
};

export const DiceArenaGame: React.FC = () => {
  const { user, updateUser, refillDemoPoints } = useEarnova();

  const [die1, setDie1] = useState<number>(3);
  const [die2, setDie2] = useState<number>(4);
  const [selectedPrediction, setSelectedPrediction] = useState<DicePrediction>('under7');
  const [stake, setStake] = useState<number>(50);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [rollHistory, setRollHistory] = useState<Array<{ d1: number; d2: number; total: number }>>([
    { d1: 3, d2: 4, total: 7 },
    { d1: 5, d2: 2, total: 7 },
    { d1: 1, d2: 4, total: 5 },
    { d1: 6, d2: 3, total: 9 },
  ]);

  const handleRoll = () => {
    if (isRolling) return;
    if (user.points < stake) {
      alert('Insufficient virtual points. Use demo refill to top up EP.');
      return;
    }

    sound.playTap();
    // Deduct stake
    updateUser({ points: Math.max(0, user.points - stake) });
    setIsRolling(true);
    setLastWin(null);

    // Tumbling animation
    let count = 0;
    const interval = setInterval(() => {
      count++;
      sound.playSpinTick();
      setDie1(Math.floor(Math.random() * 6) + 1);
      setDie2(Math.floor(Math.random() * 6) + 1);
      if (count > 12) {
        clearInterval(interval);
      }
    }, 80);

    setTimeout(() => {
      clearInterval(interval);
      const finalD1 = Math.floor(Math.random() * 6) + 1;
      const finalD2 = Math.floor(Math.random() * 6) + 1;
      const total = finalD1 + finalD2;

      setDie1(finalD1);
      setDie2(finalD2);
      setIsRolling(false);
      setRollHistory((prev) => [{ d1: finalD1, d2: finalD2, total }, ...prev.slice(0, 7)]);

      // Check prediction outcome
      const chosen = PREDICTIONS.find((p) => p.id === selectedPrediction);
      if (chosen && chosen.condition(finalD1, finalD2)) {
        const winAmount = Math.round(stake * chosen.multiplier);
        sound.playCashout();
        setLastWin(winAmount);
        updateUser({ points: user.points - stake + winAmount });
      } else {
        sound.playCrash();
        setLastWin(0);
      }
    }, 1200);
  };

  const currentTotal = die1 + die2;

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Title */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Dice Arena · Tactical Roll</span>
        </div>
        <h2 className="font-display font-black text-2xl text-white">Dice Arena</h2>
        <p className="text-xs text-slate-400">Predict the dice combination for up to 30x payouts!</p>
      </div>

      {/* Arena Stage */}
      <div className="p-6 rounded-3xl bg-gradient-to-b from-[#180e29] via-[#0f091c] to-[#080512] border-2 border-rose-500/30 shadow-2xl space-y-4 text-center">
        {/* Rolling Dice Display */}
        <div className="flex items-center justify-center gap-6 py-4">
          {/* Die 1 */}
          <div
            className={`w-20 h-20 rounded-2xl bg-gradient-to-tr from-rose-700 via-rose-600 to-rose-500 text-white flex items-center justify-center text-6xl shadow-xl shadow-rose-600/30 border-2 border-white/40 transition-transform ${
              isRolling ? 'animate-bounce scale-110' : ''
            }`}
          >
            {DICE_DOTS[die1]}
          </div>

          {/* Die 2 */}
          <div
            className={`w-20 h-20 rounded-2xl bg-gradient-to-tr from-emerald-700 via-emerald-600 to-emerald-500 text-white flex items-center justify-center text-6xl shadow-xl shadow-emerald-600/30 border-2 border-white/40 transition-transform ${
              isRolling ? 'animate-bounce scale-110' : ''
            }`}
          >
            {DICE_DOTS[die2]}
          </div>
        </div>

        {/* Total Callout */}
        <div className="text-xs font-mono font-bold text-slate-300">
          Total: <span className="font-display font-black text-2xl text-white ml-1">{currentTotal}</span>
        </div>

        {/* Win Alert */}
        {lastWin !== null && !isRolling && (
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400 animate-in zoom-in-95 duration-150">
            {lastWin > 0 ? (
              <span className="font-display font-black text-lg text-emerald-300">
                WINNER: +{lastWin.toLocaleString()} EP!
              </span>
            ) : (
              <span className="text-xs text-slate-400">Dice landed on {currentTotal}. Better luck next roll!</span>
            )}
          </div>
        )}
      </div>

      {/* Prediction Market Options */}
      <div className="p-4 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3">
        <span className="text-xs font-semibold text-slate-300 block">Choose Market Prediction:</span>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {PREDICTIONS.map((p) => {
            const isSelected = selectedPrediction === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPrediction(p.id)}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between gap-1 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-rose-500/20 border-rose-400 text-white ring-1 ring-rose-400'
                    : 'bg-[#081224] border-[#14264b] text-slate-400 hover:text-white'
                }`}
              >
                <span className="font-bold text-[11px] block">{p.label}</span>
                <span className="font-mono font-black text-rose-400 text-xs">{p.multiplier}x Payout</span>
              </button>
            );
          })}
        </div>

        {/* Stake Buttons */}
        <div className="flex items-center gap-2 pt-2 border-t border-[#14264b]">
          {[25, 50, 100, 250].map((amt) => (
            <button
              key={amt}
              type="button"
              disabled={isRolling}
              onClick={() => setStake(amt)}
              className={`flex-1 py-2 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                stake === amt
                  ? 'bg-rose-500 text-white border-rose-400'
                  : 'bg-[#081224] border-[#162c57] text-slate-300 hover:text-white'
              }`}
            >
              {amt}
            </button>
          ))}
        </div>

        {/* Roll Button */}
        <button
          type="button"
          onClick={handleRoll}
          disabled={isRolling || user.points < stake}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 hover:brightness-110 text-white font-black text-sm uppercase tracking-wider shadow-lg active:scale-95 transition-all cursor-pointer disabled:opacity-50"
        >
          {isRolling ? 'ROLLING DICE...' : `ROLL DICE (${stake} EP)`}
        </button>
      </div>
    </div>
  );
};
