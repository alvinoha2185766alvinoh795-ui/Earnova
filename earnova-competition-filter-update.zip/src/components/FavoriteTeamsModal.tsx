import React, { useState } from 'react';
import { X, Star, Bell, Shield, Check } from 'lucide-react';
import { TEAMS } from '../data/mockData';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface FavoriteTeamsModalProps {
  onClose: () => void;
}

export const FavoriteTeamsModal: React.FC<FavoriteTeamsModalProps> = ({ onClose }) => {
  const { favoriteTeamIds, toggleFavoriteTeam, language } = useEarnova();
  const { t } = useTranslation(language);

  const [goalAlerts, setGoalAlerts] = useState(true);
  const [redCardAlerts, setRedCardAlerts] = useState(true);
  const [kickoffAlerts, setKickoffAlerts] = useState(true);
  const [settlementAlerts, setSettlementAlerts] = useState(true);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#091326] border border-[#1b3464] rounded-3xl w-full max-w-xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#14264b] bg-gradient-to-r from-[#0a162e] to-[#0c1a36] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Star className="w-5 h-5 fill-amber-400" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-white">
                {t('manageFavorites')}
              </h3>
              <p className="text-xs text-slate-400">
                Follow clubs to receive prioritized match alerts and timeline feeds
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-[#122245] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Followed Clubs Grid */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-300 block">
              Follow Clubs ({favoriteTeamIds.length} Selected)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-2 gap-2.5">
              {Object.values(TEAMS).map((team) => {
                const isFav = favoriteTeamIds.includes(team.id);
                return (
                  <button
                    key={team.id}
                    onClick={() => toggleFavoriteTeam(team.id)}
                    className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between gap-2 cursor-pointer ${
                      isFav
                        ? 'bg-amber-950/30 border-amber-500/60 text-white'
                        : 'bg-[#0c1830] border-[#162c57] text-slate-300 hover:border-[#1e3b74]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-xl shrink-0">{team.crestIcon}</span>
                      <div className="min-w-0">
                        <h4 className="font-semibold text-xs truncate text-white">{team.name}</h4>
                        <span className="text-[10px] text-slate-400 block truncate">{team.city}</span>
                      </div>
                    </div>
                    <Star
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isFav ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                      }`}
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Alert Notification Rules */}
          <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-3 text-xs">
            <h4 className="font-semibold text-slate-200">
              {t('customNotifications')}
            </h4>

            <div className="space-y-2.5 divide-y divide-[#14264a]">
              <div className="pt-2 flex items-center justify-between">
                <div>
                  <span className="text-white font-medium block">{t('goalAlerts')}</span>
                  <span className="text-slate-400 text-[11px]">Instant audio ping when a followed team scores</span>
                </div>
                <input
                  type="checkbox"
                  checked={goalAlerts}
                  onChange={(e) => setGoalAlerts(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 rounded"
                />
              </div>

              <div className="pt-2.5 flex items-center justify-between">
                <div>
                  <span className="text-white font-medium block">{t('kickoffAlerts')}</span>
                  <span className="text-slate-400 text-[11px]">Reminder 15 minutes before match kickoff</span>
                </div>
                <input
                  type="checkbox"
                  checked={kickoffAlerts}
                  onChange={(e) => setKickoffAlerts(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 rounded"
                />
              </div>

              <div className="pt-2.5 flex items-center justify-between">
                <div>
                  <span className="text-white font-medium block">{t('redCardAlerts')}</span>
                  <span className="text-slate-400 text-[11px]">Real-time warnings when a red card is issued</span>
                </div>
                <input
                  type="checkbox"
                  checked={redCardAlerts}
                  onChange={(e) => setRedCardAlerts(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 rounded"
                />
              </div>

              <div className="pt-2.5 flex items-center justify-between">
                <div>
                  <span className="text-white font-medium block">{t('settlementAlerts')}</span>
                  <span className="text-slate-400 text-[11px]">Notification whenever a prediction settles as won or lost</span>
                </div>
                <input
                  type="checkbox"
                  checked={settlementAlerts}
                  onChange={(e) => setSettlementAlerts(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 rounded"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#070e1c] border-t border-[#14264b] flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Alerts sync across all active sessions.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
          >
            {t('done')}
          </button>
        </div>
      </div>
    </div>
  );
};
