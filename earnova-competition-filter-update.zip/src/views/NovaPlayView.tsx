import React, { useState } from 'react';
import {
  RotateCcw,
  Coins,
  ShieldCheck,
  ChevronRight,
  ArrowLeft,
  Play,
  Award,
  Star,
  Sparkles,
  Plane,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { GameCardArtwork } from '../components/GameCardArtwork';
import { TempleTreasureQuest } from '../games/TempleTreasureQuest';
import { FruitSplashGame } from '../games/FruitSplashGame';
import { PharaohsTreasureGame } from '../games/PharaohsTreasureGame';
import { ChilliDashGame } from '../games/ChilliDashGame';
import { SpellboundTrioGame } from '../games/SpellboundTrioGame';
import { RoyalCrownChallenge } from '../games/RoyalCrownChallenge';
import { NovaFlightAviator } from '../games/NovaFlightAviator';

interface NovaPlayViewProps {
  onBack?: () => void;
  onNavigateToWallet?: () => void;
  initialGameId?: string;
}

export type MiniGameId =
  | 'temple_treasure'
  | 'fruit_splash'
  | 'pharaohs_treasure'
  | 'chilli_dash'
  | 'spellbound_trio'
  | 'royal_crown'
  | 'nova_flight';

export interface GameInfo {
  id: MiniGameId;
  title: string;
  subtitle: string;
  category: string;
  tag: string;
  description: string;
  artworkKey: string;
}

export const SIX_ORIGINAL_GAMES: GameInfo[] = [
  {
    id: 'temple_treasure',
    title: 'Temple Treasure Quest',
    subtitle: 'Aztec Gems',
    category: 'Gem Match Puzzle',
    tag: 'AZTEC ADVENTURE',
    description: 'Ancient Aztec-inspired gem matching puzzle. Swap adjacent jewels to form 3+ rows, trigger cascades, and discover the Sun God idol.',
    artworkKey: 'temple_treasure',
  },
  {
    id: 'fruit_splash',
    title: 'Fruit Splash',
    subtitle: 'Extra Juicy',
    category: 'Arcade Cluster',
    tag: 'EXTRA JUICY',
    description: 'Colourful fruit-matching arcade game. Connect juicy clusters of watermelon, bell, and grapes to trigger the 3x Splash Fever!',
    artworkKey: 'fruit_splash',
  },
  {
    id: 'pharaohs_treasure',
    title: "Pharaoh's Treasure",
    subtitle: '3 Pots of Egypt',
    category: 'Egyptian Relic Puzzle',
    tag: '3 POTS OF EGYPT',
    description: 'Egyptian-themed treasure puzzle. Crack open 16 sacred hieroglyph tablets to charge the Urns of Ra, Osiris, and Anubis.',
    artworkKey: 'pharaohs_treasure',
  },
  {
    id: 'chilli_dash',
    title: 'Chilli Dash',
    subtitle: 'Chilli Heat',
    category: 'Reflex Runner',
    tag: 'SIZZLING REFLEX',
    description: 'Colourful reflex and obstacle game. Help El Chilli sprint down desert highway, dodge barrels, and unleash the Super Sizzle dash!',
    artworkKey: 'chilli_dash',
  },
  {
    id: 'spellbound_trio',
    title: 'Spellbound Trio',
    subtitle: 'Wild Spells',
    category: 'Elemental Spell Quest',
    tag: 'WILD MAGIC',
    description: 'Magical fantasy matching puzzle with Sylva (Nature), Ignis (Fire), and Astra (Frost). Match elemental runes to unleash sorceress spells.',
    artworkKey: 'spellbound_trio',
  },
  {
    id: 'royal_crown',
    title: 'Royal Crown Challenge',
    subtitle: 'Burning Classics Royal',
    category: 'Regal Memory Challenge',
    tag: 'BURNING CLASSICS',
    description: 'Royal-themed memory and puzzle game. Uncover matching pairs of Imperial Crowns, Sceptres, and Chalices to rank as King of Earnova.',
    artworkKey: 'royal_crown',
  },
];

export const NovaPlayView: React.FC<NovaPlayViewProps> = ({ onBack, onNavigateToWallet, initialGameId }) => {
  const { user, refillDemoPoints } = useEarnova();
  const [activeGame, setActiveGame] = useState<MiniGameId | null>(
    (initialGameId as MiniGameId) || null
  );
  const [isLoadingGame, setIsLoadingGame] = useState<boolean>(false);
  const [loadingGameTitle, setLoadingGameTitle] = useState<string>('');
  const [favorites, setFavorites] = useState<Record<string, boolean>>({
    temple_treasure: true,
    fruit_splash: false,
    pharaohs_treasure: true,
    chilli_dash: false,
    spellbound_trio: false,
    royal_crown: true,
  });
  const [showAllView, setShowAllView] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'all' | 'puzzles' | 'arcade' | 'reflex'>('all');

  const toggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setFavorites((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleLaunchGame = (game: GameInfo) => {
    setIsLoadingGame(true);
    setLoadingGameTitle(game.title);
    setTimeout(() => {
      setActiveGame(game.id);
      setIsLoadingGame(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 400);
  };

  const filteredGames = SIX_ORIGINAL_GAMES.filter((g) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'puzzles') return g.id === 'temple_treasure' || g.id === 'pharaohs_treasure' || g.id === 'royal_crown';
    if (activeTab === 'arcade') return g.id === 'fruit_splash' || g.id === 'spellbound_trio';
    if (activeTab === 'reflex') return g.id === 'chilli_dash';
    return true;
  });

  return (
    <div className="space-y-6 pb-16 max-w-6xl mx-auto">
      {/* 1. Header Bar with Back button and Virtual Points display */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#14264b]">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#0c1830] hover:bg-[#122347] border border-[#162c57] text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer touch-manipulation active:scale-95"
            >
              <ArrowLeft className="w-4 h-4 text-emerald-400" />
              <span>Back</span>
            </button>
          )}

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display font-extrabold text-2xl text-white tracking-tight flex items-center gap-2">
                <span className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-slate-950 font-black text-sm shadow-md">
                  ⭐
                </span>
                <span>NovaPlay Games</span>
              </h1>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-yellow-500/20 text-yellow-300 border border-yellow-500/40">
                6 Original Mini-Games
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              100% Free virtual simulation. Zero real-money wagering or fiat payouts.
            </p>
          </div>
        </div>

        {/* Bankroll Pill */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="px-3.5 py-2 rounded-xl bg-[#0c1830] border border-[#162c57] flex items-center gap-2">
            <Coins className="w-4 h-4 text-yellow-400" />
            <div className="text-right">
              <span className="text-[10px] uppercase text-slate-400 block font-semibold leading-none">
                Virtual Balance
              </span>
              <span className="font-mono font-black text-sm text-emerald-400 tabular-nums">
                {(user?.points ?? 0).toLocaleString()} EP
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={refillDemoPoints}
            className="px-3 py-2 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer touch-manipulation active:scale-95"
          >
            + Refill
          </button>
        </div>
      </div>

      {/* Loading Overlay */}
      {isLoadingGame && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-3xl shadow-2xl animate-spin mb-4">
            ⚡
          </div>
          <h3 className="font-display font-black text-xl text-yellow-300">
            Loading {loadingGameTitle}...
          </h3>
          <p className="text-xs text-slate-400 mt-1">Initializing free virtual demo session</p>
        </div>
      )}

      {/* 2. Active Playable Game Screen (if a game is active) */}
      {activeGame && (
        <div className="p-4 sm:p-6 rounded-3xl bg-[#09152b] border-2 border-yellow-500/40 shadow-2xl relative animate-fade-in">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#14264b]">
            <button
              type="button"
              onClick={() => setActiveGame(null)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0c1830] hover:bg-[#122347] border border-[#162c57] text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer touch-manipulation active:scale-95"
            >
              <ArrowLeft className="w-4 h-4 text-yellow-400" />
              <span>Back to Games Gallery</span>
            </button>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              Playing in Demo Mode (EP Points)
            </span>
          </div>

          {activeGame === 'temple_treasure' && <TempleTreasureQuest onBack={() => setActiveGame(null)} />}
          {activeGame === 'fruit_splash' && <FruitSplashGame onBack={() => setActiveGame(null)} />}
          {activeGame === 'pharaohs_treasure' && <PharaohsTreasureGame onBack={() => setActiveGame(null)} />}
          {activeGame === 'chilli_dash' && <ChilliDashGame onBack={() => setActiveGame(null)} />}
          {activeGame === 'spellbound_trio' && <SpellboundTrioGame onBack={() => setActiveGame(null)} />}
          {activeGame === 'royal_crown' && <RoyalCrownChallenge onBack={() => setActiveGame(null)} />}
          {activeGame === 'nova_flight' && <NovaFlightAviator />}
        </div>
      )}

      {/* 3. "Other Games" Gallery Header matching user screenshot */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-1.5 h-6 bg-yellow-400 rounded-full" />
            <h2 className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight">
              Other Games
            </h2>
          </div>

          <button
            type="button"
            onClick={() => setShowAllView(!showAllView)}
            className="px-3.5 py-1.5 rounded-full border border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 transition-all font-display font-bold text-xs flex items-center gap-1 cursor-pointer touch-manipulation active:scale-95"
          >
            <span>{showAllView ? 'Featured (6)' : 'View All'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Category Filter Tabs */}
        {showAllView && (
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {(['all', 'puzzles', 'arcade', 'reflex'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                  activeTab === tab
                    ? 'bg-yellow-400 text-slate-950 font-black shadow-sm'
                    : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        )}

        {/* 3-Column Game Card Grid matching Reference Screenshot */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
          {filteredGames.map((game) => {
            const isFav = !!favorites[game.id];
            const isCurrent = activeGame === game.id;

            return (
              <div
                key={game.id}
                onClick={() => handleLaunchGame(game)}
                className={`rounded-2xl sm:rounded-3xl bg-[#0a162d] border transition-all flex flex-col justify-between overflow-hidden cursor-pointer group touch-manipulation hover:scale-[1.02] active:scale-98 ${
                  isCurrent
                    ? 'border-yellow-400 ring-2 ring-yellow-400/30'
                    : 'border-[#162c57] hover:border-yellow-400/60 shadow-lg'
                }`}
              >
                {/* Artwork Thumbnail Container */}
                <div className="relative aspect-[16/10] sm:aspect-[16/10] w-full overflow-hidden bg-[#060e1d]">
                  <GameCardArtwork gameId={game.artworkKey} />

                  {/* Play Scrim on Hover */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="w-12 h-12 rounded-full bg-yellow-400 text-slate-950 flex items-center justify-center shadow-xl transform scale-75 group-hover:scale-100 transition-transform">
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </span>
                  </div>
                </div>

                {/* Card Footer: Title below Image + Favorite Star on Right (Exact layout from screenshot) */}
                <div className="p-2.5 sm:p-3 flex items-center justify-between gap-2 bg-[#0c1830]">
                  <div className="min-w-0">
                    <h3 className="font-display font-extrabold text-xs sm:text-sm text-white group-hover:text-yellow-300 transition-colors truncate">
                      {game.title}
                    </h3>
                    <p className="text-[10px] text-slate-400 truncate">
                      {game.subtitle}
                    </p>
                  </div>

                  {/* Favorite Star Button */}
                  <button
                    type="button"
                    onClick={(e) => toggleFavorite(e, game.id)}
                    className="p-1 sm:p-1.5 rounded-lg hover:bg-white/10 text-slate-400 transition-all cursor-pointer shrink-0"
                    title={isFav ? 'Remove from Favourites' : 'Add to Favourites'}
                    aria-label="Toggle favourite"
                  >
                    <Star
                      className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform active:scale-125 ${
                        isFav
                          ? 'fill-yellow-400 text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.6)]'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Optional Nova Flight Aviator Launcher Section */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-[#0a1733] via-[#0d1f42] to-[#081226] border border-amber-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
            <Plane className="w-6 h-6 transform -rotate-45" />
          </div>
          <div>
            <h4 className="font-display font-extrabold text-sm sm:text-base text-white">
              Nova Flight (Aviator Crash Simulator)
            </h4>
            <p className="text-xs text-slate-300">
              Supersonic tactical flight simulation with multipliers up to 50x in demo EP.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setActiveGame('nova_flight')}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-md hover:brightness-110 active:scale-95 transition-all self-start sm:self-auto shrink-0"
        >
          Launch Aviator →
        </button>
      </div>

      {/* 5. Free-to-Play Disclaimer */}
      <div className="p-4 rounded-2xl bg-[#081224] border border-[#14264b] flex items-center gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-5 h-5 text-yellow-400 shrink-0" />
        <span>
          <strong>Earnova Non-Wagering Fair-Play:</strong> All mini-games are for recreational entertainment only. Utilizes free virtual demo points (EP). No real currency wagering or cash prizes.
        </span>
      </div>
    </div>
  );
};
