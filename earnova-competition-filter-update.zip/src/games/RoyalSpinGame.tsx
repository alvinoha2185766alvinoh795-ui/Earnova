import React, { useState } from 'react';
import { Crown, Sparkles, Coins, RotateCcw, CheckCircle2, Trophy } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type BetType = 'red' | 'black' | 'even' | 'odd' | 'low' | 'high' | 'straight';

interface BetPlaced {
  type: BetType;
  value?: number;
  amount: number;
}

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

export const RoyalSpinGame: React.FC = () => {
  const { user, updateUser, refillDemoPoints } = useEarnova();

  const [selectedChip, setSelectedChip] = useState<number>(25);
  const [currentBets, setCurrentBets] = useState<BetPlaced[]>([]);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [lastResult, setLastResult] = useState<{ number: number; color: 'red' | 'black' | 'green' } | null>(null);
  const [roundWinnings, setRoundWinnings] = useState<number | null>(null);
  const [history, setHistory] = useState<Array<{ number: number; color: 'red' | 'black' | 'green' }>>([
    { number: 14, color: 'red' },
    { number: 22, color: 'black' },
    { number: 0, color: 'green' },
    { number: 31, color: 'black' },
    { number: 7, color: 'red' },
  ]);

  const totalBetAmount = currentBets.reduce((sum, b) => sum + b.amount, 0);

  const addBet = (type: BetType, value?: number) => {
    if (isSpinning) return;
    if (user.points < totalBetAmount + selectedChip) {
      alert('Insufficient virtual points. Use demo refill to top up EP.');
      return;
    }
    sound.playTap();

    setCurrentBets((prev) => {
      const existing = prev.find((b) => b.type === type && b.value === value);
      if (existing) {
        return prev.map((b) =>
          b.type === type && b.value === value ? { ...b, amount: b.amount + selectedChip } : b
        );
      }
      return [...prev, { type, value, amount: selectedChip }];
    });
  };

  const clearBets = () => {
    if (isSpinning) return;
    sound.playTap();
    setCurrentBets([]);
  };

  const handleSpin = () => {
    if (isSpinning || currentBets.length === 0) return;
    if (user.points < totalBetAmount) {
      alert('Insufficient virtual points.');
      return;
    }

    sound.playTap();
    // Deduct total bet
    updateUser({ points: Math.max(0, user.points - totalBetAmount) });
    setIsSpinning(true);
    setRoundWinnings(null);

    // Pick winning roulette number 0 - 36
    const winningNum = Math.floor(Math.random() * 37);
    const winningColor: 'red' | 'black' | 'green' =
      winningNum === 0 ? 'green' : RED_NUMBERS.includes(winningNum) ? 'red' : 'black';

    // Animate wheel rotation
    const baseTurns = 6 + Math.floor(Math.random() * 3);
    const newRotation = wheelRotation + baseTurns * 360 + Math.floor(Math.random() * 360);
    setWheelRotation(newRotation);

    // Sound ticks
    let ticks = 0;
    const tickInterval = setInterval(() => {
      ticks++;
      sound.playSpinTick();
      if (ticks > 18) clearInterval(tickInterval);
    }, 140);

    setTimeout(() => {
      clearInterval(tickInterval);
      setIsSpinning(false);
      setLastResult({ number: winningNum, color: winningColor });
      setHistory((prev) => [{ number: winningNum, color: winningColor }, ...prev.slice(0, 9)]);

      // Calculate total payout from currentBets
      let totalPayout = 0;
      currentBets.forEach((b) => {
        if (b.type === 'straight' && b.value === winningNum) {
          totalPayout += b.amount * 36; // 35:1 + original
        } else if (b.type === 'red' && winningColor === 'red') {
          totalPayout += b.amount * 2;
        } else if (b.type === 'black' && winningColor === 'black') {
          totalPayout += b.amount * 2;
        } else if (b.type === 'even' && winningNum !== 0 && winningNum % 2 === 0) {
          totalPayout += b.amount * 2;
        } else if (b.type === 'odd' && winningNum !== 0 && winningNum % 2 !== 0) {
          totalPayout += b.amount * 2;
        } else if (b.type === 'low' && winningNum >= 1 && winningNum <= 18) {
          totalPayout += b.amount * 2;
        } else if (b.type === 'high' && winningNum >= 19 && winningNum <= 36) {
          totalPayout += b.amount * 2;
        }
      });

      if (totalPayout > 0) {
        sound.playCashout();
        setRoundWinnings(totalPayout);
        updateUser({ points: user.points - totalBetAmount + totalPayout });
      } else {
        sound.playCrash();
        setRoundWinnings(0);
      }
    }, 3200);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Title */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold">
          <Crown className="w-3.5 h-3.5" />
          <span>Royal Spin · European Roulette</span>
        </div>
        <h2 className="font-display font-black text-2xl text-white">Royal Spin Arena</h2>
        <p className="text-xs text-slate-400">Place virtual chips on colors, evens/odds, or lucky numbers!</p>
      </div>

      {/* History Ribbon */}
      <div className="flex items-center justify-center gap-2 text-xs font-mono">
        <span className="text-[10px] uppercase text-slate-500 font-bold">Recent:</span>
        {history.map((h, i) => (
          <span
            key={i}
            className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs text-white shadow-sm ${
              h.color === 'green' ? 'bg-emerald-600' : h.color === 'red' ? 'bg-rose-600' : 'bg-slate-900 border border-slate-700'
            }`}
          >
            {h.number}
          </span>
        ))}
      </div>

      {/* Rotating Wheel & Winning Callout */}
      <div className="relative p-6 rounded-3xl bg-[#09152b] border border-[#162f5e] shadow-2xl flex flex-col items-center justify-center">
        <div className="relative w-48 h-48 sm:w-56 sm:h-56">
          <div
            className="w-full h-full rounded-full border-4 border-amber-400/80 shadow-2xl bg-[#061021] flex items-center justify-center overflow-hidden"
            style={{
              transform: `rotate(${wheelRotation}deg)`,
              transition: isSpinning ? 'transform 3.2s cubic-bezier(0.12, 0.8, 0.33, 1)' : 'none',
            }}
          >
            <div className="w-full h-full rounded-full border-8 border-dashed border-amber-400/50 flex items-center justify-center">
              <div className="w-28 h-28 rounded-full bg-emerald-950/80 border-2 border-emerald-400 flex items-center justify-center text-center p-2">
                <Crown className="w-8 h-8 text-amber-400 animate-pulse" />
              </div>
            </div>
          </div>

          {/* Center Result Display */}
          {lastResult && !isSpinning && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-slate-950 border-2 border-amber-400 flex flex-col items-center justify-center text-white font-mono shadow-2xl animate-in zoom-in-95 duration-150">
              <span className="text-xl font-black">{lastResult.number}</span>
              <span className="text-[9px] uppercase font-bold text-amber-300">{lastResult.color}</span>
            </div>
          )}
        </div>

        {/* Winnings Callout */}
        {roundWinnings !== null && !isSpinning && (
          <div className="mt-3 text-center animate-in zoom-in-95 duration-150">
            {roundWinnings > 0 ? (
              <span className="px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-300 font-bold text-sm">
                WON: +{roundWinnings.toLocaleString()} EP!
              </span>
            ) : (
              <span className="text-xs text-slate-400">No match this spin. Try another placement!</span>
            )}
          </div>
        )}
      </div>

      {/* Chip Value Selector */}
      <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0c1830] border border-[#162c57]">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-slate-400 font-semibold mr-1">Chip:</span>
          {[10, 25, 50, 100, 250].map((amt) => (
            <button
              key={amt}
              type="button"
              onClick={() => setSelectedChip(amt)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                selectedChip === amt
                  ? 'bg-amber-400 text-slate-950 shadow-md font-black scale-105'
                  : 'bg-[#081224] text-slate-300 hover:text-white border border-[#14264b]'
              }`}
            >
              {amt}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={clearBets}
          disabled={isSpinning || currentBets.length === 0}
          className="text-xs text-slate-400 hover:text-rose-400 disabled:opacity-40 cursor-pointer"
        >
          Clear
        </button>
      </div>

      {/* Betting Board (Outside bets & Quick Numbers) */}
      <div className="p-4 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3">
        {/* Outside Bets Grid */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => addBet('red')}
            className="py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer touch-manipulation active:scale-95 shadow-sm"
          >
            <span>Red (1:1)</span>
          </button>
          <button
            type="button"
            onClick={() => addBet('black')}
            className="py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer touch-manipulation active:scale-95 shadow-sm"
          >
            <span>Black (1:1)</span>
          </button>
          <button
            type="button"
            onClick={() => addBet('straight', 0)}
            className="py-3 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer touch-manipulation active:scale-95 shadow-sm"
          >
            <span>Zero (35:1)</span>
          </button>

          <button
            type="button"
            onClick={() => addBet('even')}
            className="py-2.5 rounded-xl bg-[#081224] border border-[#162c57] hover:border-slate-500 text-slate-200 font-bold text-xs uppercase cursor-pointer"
          >
            Even (1:1)
          </button>
          <button
            type="button"
            onClick={() => addBet('odd')}
            className="py-2.5 rounded-xl bg-[#081224] border border-[#162c57] hover:border-slate-500 text-slate-200 font-bold text-xs uppercase cursor-pointer"
          >
            Odd (1:1)
          </button>
          <button
            type="button"
            onClick={() => addBet('low')}
            className="py-2.5 rounded-xl bg-[#081224] border border-[#162c57] hover:border-slate-500 text-slate-200 font-bold text-xs uppercase cursor-pointer"
          >
            1 - 18 (1:1)
          </button>
        </div>

        {/* Selected Bets Summary */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-[#14264b]">
          <span>
            Total Bets: <strong className="text-white font-mono">{totalBetAmount} EP</strong>
          </span>
          <span>
            Available: <strong className="text-emerald-400 font-mono">{(user?.points ?? 0).toLocaleString()} EP</strong>
          </span>
        </div>

        {/* Spin Button */}
        <button
          type="button"
          onClick={handleSpin}
          disabled={isSpinning || currentBets.length === 0}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400 hover:brightness-110 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/25 active:scale-95 transition-all cursor-pointer touch-manipulation disabled:opacity-50"
        >
          {isSpinning ? 'SPINNING ROULETTE...' : `SPIN WHEEL (${totalBetAmount} EP)`}
        </button>
      </div>
    </div>
  );
};
