import React, { useState } from 'react';
import { History, CheckCircle2, XCircle, Clock, Award, Coins } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';

export const HistoryView: React.FC = () => {
  const { placedPredictions, user } = useEarnova();
  const [filter, setFilter] = useState<'all' | 'pending' | 'won' | 'lost'>('all');

  const filtered = placedPredictions.filter((p) => {
    if (filter === 'all') return true;
    return p.status === filter;
  });

  const totalWon = placedPredictions.filter((p) => p.status === 'won').length;
  const totalLost = placedPredictions.filter((p) => p.status === 'lost').length;
  const totalPending = placedPredictions.filter((p) => p.status === 'pending').length;

  return (
    <div className="space-y-6 pb-12">
      {/* View Header */}
      <div>
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
          Prediction History
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Review your virtual sports prediction slips, settled results, and point yields
        </p>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400">Total Placed</span>
          <div className="mt-1 font-mono font-bold text-2xl text-white tabular-nums">
            {placedPredictions.length}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400">Won Slips</span>
          <div className="mt-1 font-mono font-bold text-2xl text-emerald-400 tabular-nums">
            {totalWon}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400">Lost Slips</span>
          <div className="mt-1 font-mono font-bold text-2xl text-slate-400 tabular-nums">
            {totalLost}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#0c1830] border border-[#162c57]">
          <span className="text-xs text-slate-400">Pending / In Play</span>
          <div className="mt-1 font-mono font-bold text-2xl text-sky-400 tabular-nums">
            {totalPending}
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => setFilter('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
            filter === 'all'
              ? 'bg-emerald-500 text-slate-950 font-bold'
              : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
          }`}
        >
          All Predictions ({placedPredictions.length})
        </button>
        <button
          onClick={() => setFilter('pending')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
            filter === 'pending'
              ? 'bg-emerald-500 text-slate-950 font-bold'
              : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
          }`}
        >
          Pending ({totalPending})
        </button>
        <button
          onClick={() => setFilter('won')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
            filter === 'won'
              ? 'bg-emerald-500 text-slate-950 font-bold'
              : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
          }`}
        >
          Won ({totalWon})
        </button>
        <button
          onClick={() => setFilter('lost')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
            filter === 'lost'
              ? 'bg-emerald-500 text-slate-950 font-bold'
              : 'bg-[#0d1a33] text-slate-300 hover:text-white border border-[#16294f]'
          }`}
        >
          Lost ({totalLost})
        </button>
      </div>

      {/* Predictions Feed */}
      {filtered.length === 0 ? (
        <div className="py-16 text-center text-slate-400 rounded-2xl bg-[#091326] border border-[#14264b]">
          <History className="w-10 h-10 text-slate-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-300">No predictions found</p>
          <p className="text-xs text-slate-500 mt-1">
            Browse today&apos;s fixtures and lock in your first prediction to start tracking.
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {filtered.map((item) => {
            const isWon = item.status === 'won';
            const isLost = item.status === 'lost';
            const isPending = item.status === 'pending';

            return (
              <div
                key={item.id}
                className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162a52] transition-all hover:border-[#1f3a74]"
              >
                {/* Header info */}
                <div className="flex items-center justify-between border-b border-[#14264a] pb-3 mb-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">
                      {item.type === 'accumulator'
                        ? `Combo Accumulator (${item.selections.length} Legs)`
                        : 'Single Prediction'}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-400 font-mono">
                      {new Date(item.timestamp).toLocaleDateString()} {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  {/* Status Indicator */}
                  <div className="flex items-center gap-1.5 font-semibold">
                    {isWon && (
                      <span className="text-emerald-400 flex items-center gap-1 font-mono">
                        <CheckCircle2 className="w-4 h-4" />
                        WON (+{item.potentialReturn} EP)
                      </span>
                    )}
                    {isLost && (
                      <span className="text-rose-400 flex items-center gap-1 font-mono">
                        <XCircle className="w-4 h-4" />
                        LOST (-{item.stake} EP)
                      </span>
                    )}
                    {isPending && (
                      <span className="text-sky-400 flex items-center gap-1 font-mono">
                        <Clock className="w-4 h-4 animate-spin" />
                        IN PLAY / PENDING
                      </span>
                    )}
                  </div>
                </div>

                {/* Selections in this slip */}
                <div className="space-y-2 mb-3">
                  {item.selections.map((sel, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-[#0f2040] border border-[#172c54] flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="text-[11px] text-slate-400 block truncate">
                          {sel.matchTitle}
                        </span>
                        <div className="flex items-center gap-2 mt-0.5">
                          <strong className="text-white font-semibold">
                            {sel.selectionLabel}
                          </strong>
                          <span className="text-[11px] text-slate-400">
                            ({sel.marketName})
                          </span>
                        </div>
                      </div>
                      <span className="font-mono font-bold text-emerald-400 tabular-nums">
                        {sel.odds.toFixed(2)}x
                      </span>
                    </div>
                  ))}
                </div>

                {/* Footer calculations & Result info */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-[#14264a] text-xs">
                  <div className="flex items-center gap-4 text-slate-300">
                    <div>
                      <span className="text-slate-400 mr-1">Stake:</span>
                      <strong className="font-mono text-white tabular-nums">{item.stake} EP</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 mr-1">Total Odds:</span>
                      <strong className="font-mono text-emerald-400 tabular-nums">{item.totalOdds.toFixed(2)}x</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 mr-1">Potential Return:</span>
                      <strong className="font-mono text-white tabular-nums">{item.potentialReturn} EP</strong>
                    </div>
                  </div>

                  {item.resultDetails && (
                    <span className="text-[11px] text-slate-400 italic">
                      {item.resultDetails}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
