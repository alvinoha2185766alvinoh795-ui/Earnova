import React, { useState } from 'react';
import { Award, Trophy, Flame, TrendingUp, Crown, Medal } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';

interface LeaderboardViewProps {
  onNavigateToProfile?: () => void;
  onNavigateToWallet?: () => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  onNavigateToProfile,
  onNavigateToWallet,
}) => {
  const { leaderboard, user } = useEarnova();
  const [timeframe, setTimeframe] = useState<'weekly' | 'alltime' | 'today'>('weekly');

  const top3 = leaderboard.slice(0, 3);
  const remaining = leaderboard.slice(3);

  const winRate =
    user.totalPredictions > 0
      ? Math.round((user.wonPredictions / user.totalPredictions) * 100)
      : 0;

  return (
    <div className="space-y-6 sm:space-y-8 pb-12">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
            Global Tactical Rankings
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Compete with football predictors globally using virtual Earnova Points (EP)
          </p>
        </div>

        {/* Timeframe Filter Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-[#0c1830] rounded-xl border border-[#162a52] shrink-0 self-start sm:self-auto">
          <button
            onClick={() => setTimeframe('weekly')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              timeframe === 'weekly'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Weekly Cup
          </button>
          <button
            onClick={() => setTimeframe('alltime')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              timeframe === 'alltime'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All-Time
          </button>
          <button
            onClick={() => setTimeframe('today')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              timeframe === 'today'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Today
          </button>
        </div>
      </div>

      {/* Top 3 Podium */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
        {/* Silver #2 */}
        {top3[1] && (
          <div className="p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] flex flex-col items-center text-center order-2 sm:order-1 sm:mt-6">
            <div className="relative mb-2">
              <div className="w-16 h-16 rounded-2xl bg-[#14264b] border-2 border-slate-400 flex items-center justify-center text-3xl shadow-lg">
                {top3[1].avatar}
              </div>
              <span className="absolute -bottom-2 -right-1 w-6 h-6 rounded-full bg-slate-300 text-slate-950 font-bold text-xs flex items-center justify-center shadow">
                2
              </span>
            </div>
            <h3 className="font-semibold text-sm text-white mt-2">
              {top3[1].username}
            </h3>
            <span className="text-[11px] text-slate-400">{top3[1].tier}</span>
            <div className="mt-3 font-mono font-bold text-lg text-white tabular-nums">
              {top3[1].points.toLocaleString()}{' '}
              <span className="text-xs text-emerald-400">EP</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-1">
              {top3[1].winRate}% Win Rate · {top3[1].streak}W Streak
            </span>
          </div>
        )}

        {/* Gold #1 */}
        {top3[0] && (
          <div className="p-6 rounded-2xl bg-gradient-to-b from-[#112752] to-[#0c1830] border-2 border-amber-400/60 shadow-xl shadow-amber-950/30 flex flex-col items-center text-center order-1 sm:order-2">
            <Crown className="w-6 h-6 text-amber-400 mb-1" />
            <div className="relative mb-2">
              <div className="w-20 h-20 rounded-2xl bg-[#1a3366] border-2 border-amber-400 flex items-center justify-center text-4xl shadow-xl">
                {top3[0].avatar}
              </div>
              <span className="absolute -bottom-2 -right-1 w-7 h-7 rounded-full bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center justify-center shadow-lg">
                1
              </span>
            </div>
            <h3 className="font-display font-bold text-base text-white mt-2">
              {top3[0].username}
            </h3>
            <span className="text-xs text-amber-300 font-semibold">{top3[0].tier}</span>
            <div className="mt-3 font-mono font-black text-2xl text-amber-300 tabular-nums">
              {top3[0].points.toLocaleString()}{' '}
              <span className="text-xs text-emerald-400">EP</span>
            </div>
            <span className="text-xs text-slate-300 mt-1">
              {top3[0].winRate}% Win Rate · {top3[0].streak}W Streak 🔥
            </span>
          </div>
        )}

        {/* Bronze #3 */}
        {top3[2] && (
          <div className="p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] flex flex-col items-center text-center order-3 sm:mt-10">
            <div className="relative mb-2">
              <div className="w-16 h-16 rounded-2xl bg-[#14264b] border-2 border-amber-700 flex items-center justify-center text-3xl shadow-lg">
                {top3[2].avatar}
              </div>
              <span className="absolute -bottom-2 -right-1 w-6 h-6 rounded-full bg-amber-700 text-white font-bold text-xs flex items-center justify-center shadow">
                3
              </span>
            </div>
            <h3 className="font-semibold text-sm text-white mt-2">
              {top3[2].username}
            </h3>
            <span className="text-[11px] text-slate-400">{top3[2].tier}</span>
            <div className="mt-3 font-mono font-bold text-lg text-white tabular-nums">
              {top3[2].points.toLocaleString()}{' '}
              <span className="text-xs text-emerald-400">EP</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-1">
              {top3[2].winRate}% Win Rate · {top3[2].streak}W Streak
            </span>
          </div>
        )}
      </div>

      {/* Leaderboard Table */}
      <div className="rounded-2xl bg-[#0c1830] border border-[#162c57] overflow-hidden">
        <div className="p-4 border-b border-[#14264a] flex items-center justify-between">
          <h3 className="font-display font-bold text-sm text-white">
            Top Tactical Predictors
          </h3>
          <span className="text-xs text-slate-400">
            Updated every 15 minutes
          </span>
        </div>

        <div className="divide-y divide-[#14264a]">
          {remaining.map((item) => (
            <div
              key={item.rank}
              className="px-4 py-3 sm:px-6 flex items-center justify-between gap-4 hover:bg-[#102040]/50 transition-colors text-xs"
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="font-mono font-bold text-slate-400 w-6 tabular-nums">
                  #{item.rank}
                </span>
                <span className="text-lg">{item.avatar}</span>
                <div className="min-w-0">
                  <h4 className="font-semibold text-sm text-white truncate">
                    {item.username}
                  </h4>
                  <span className="text-[11px] text-slate-400 truncate block">
                    {item.tier}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-5 sm:gap-8 shrink-0">
                <div className="hidden sm:block text-right">
                  <span className="text-slate-400 block text-[10px]">Win Rate</span>
                  <span className="font-mono font-semibold text-slate-200 tabular-nums">
                    {item.winRate}%
                  </span>
                </div>
                <div className="hidden sm:block text-right">
                  <span className="text-slate-400 block text-[10px]">Streak</span>
                  <span className="font-mono font-semibold text-amber-400 tabular-nums">
                    {item.streak}W
                  </span>
                </div>
                <div className="text-right min-w-[70px]">
                  <span className="text-slate-400 block text-[10px]">Score</span>
                  <span className="font-mono font-bold text-sm text-emerald-400 tabular-nums">
                    {item.points.toLocaleString()} EP
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pinned Current User Rank Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#0d2247] to-[#0c1830] border-2 border-emerald-500/50 shadow-lg shadow-emerald-950/30 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onNavigateToProfile}
          className="flex items-center gap-3 text-left cursor-pointer group touch-manipulation"
          title="View Your Profile"
        >
          <span className="font-mono font-extrabold text-lg text-emerald-400 tabular-nums">
            #{user.rank}
          </span>
          <span className="text-2xl group-hover:scale-110 transition-transform">{user.avatar}</span>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-semibold text-sm text-white group-hover:text-emerald-400 transition-colors">
                {user.username}
              </h4>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold border border-emerald-500/30">
                YOU
              </span>
            </div>
            <span className="text-[11px] text-slate-400">
              {user.tier} · {winRate}% Accuracy
            </span>
          </div>
        </button>

        <button
          type="button"
          onClick={onNavigateToWallet}
          className="text-right shrink-0 cursor-pointer group touch-manipulation"
          title="Open Virtual Wallet"
        >
          <span className="text-[11px] text-slate-400 block group-hover:text-slate-300">
            Total Balance →
          </span>
          <span className="font-mono font-extrabold text-base sm:text-lg text-emerald-400 tabular-nums group-hover:text-emerald-300">
            {(user?.points ?? 0).toLocaleString()} EP
          </span>
        </button>
      </div>
    </div>
  );
};
