import React, { useState } from 'react';
import { Star, Bell, Calendar, Shield, ArrowRight, Check, Activity, Clock } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';
import { TEAMS } from '../data/mockData';
import { MatchCard } from '../components/MatchCard';

interface FavoritesViewProps {
  onNavigateToMatches: () => void;
  onNavigateToLive: () => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  onNavigateToMatches,
  onNavigateToLive,
}) => {
  const { matches, favoriteTeamIds, toggleFavoriteTeam, language } = useEarnova();
  const { t } = useTranslation(language);

  const [activeFilter, setActiveFilter] = useState<'all' | 'followed'>('followed');
  const [goalAlerts, setGoalAlerts] = useState(true);
  const [kickoffAlerts, setKickoffAlerts] = useState(true);
  const [redCardAlerts, setRedCardAlerts] = useState(true);
  const [settlementAlerts, setSettlementAlerts] = useState(true);

  const allTeams = Object.values(TEAMS);
  const followedTeams = allTeams.filter((tm) => favoriteTeamIds.includes(tm.id));

  // Matches involving favorite teams
  const favoriteMatches = matches.filter(
    (m) =>
      favoriteTeamIds.includes(m.homeTeam.id) ||
      favoriteTeamIds.includes(m.awayTeam.id)
  );

  const liveFavoriteMatches = favoriteMatches.filter((m) => m.status === 'live');
  const upcomingFavoriteMatches = favoriteMatches.filter((m) => m.status === 'upcoming');

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
              {t('favoriteClubs')}
            </h1>
            <span className="text-xs font-bold font-mono px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              {favoriteTeamIds.length} Followed
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            {t('favoriteClubsSubtitle')}
          </p>
        </div>

        {/* Filter Pill */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setActiveFilter('followed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              activeFilter === 'followed'
                ? 'bg-amber-400 text-slate-950 shadow-sm'
                : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
            }`}
          >
            My Clubs ({followedTeams.length})
          </button>
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-amber-400 text-slate-950 shadow-sm'
                : 'bg-[#0c1830] text-slate-400 hover:text-white border border-[#162c57]'
            }`}
          >
            All Teams ({allTeams.length})
          </button>
        </div>
      </div>

      {/* 1. Live Fixtures Involving Favorite Teams */}
      {liveFavoriteMatches.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <h3 className="font-display font-bold text-base text-white">
                Live Matches from Your Followed Clubs
              </h3>
            </div>
            <button
              onClick={onNavigateToLive}
              className="text-xs font-semibold text-emerald-400 hover:underline cursor-pointer"
            >
              Live Centre Tracker →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {liveFavoriteMatches.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        </div>
      )}

      {/* 2. Followed Teams Quick Directory */}
      <div className="p-5 sm:p-6 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-4">
        <div className="flex items-center justify-between border-b border-[#14264b] pb-3">
          <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span>
              {activeFilter === 'followed' ? 'Followed Clubs' : 'All Available Football Clubs'}
            </span>
          </h3>
          <span className="text-xs text-slate-400">
            Tap star to follow / unfollow
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(activeFilter === 'followed' ? followedTeams : allTeams).map((team) => {
            const isFav = favoriteTeamIds.includes(team.id);
            return (
              <div
                key={team.id}
                className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                  isFav
                    ? 'bg-[#0e2145] border-amber-500/40 shadow-sm'
                    : 'bg-[#081224] border-[#16294e]'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-[#070e1c] border border-[#14264b] flex items-center justify-center text-2xl shrink-0">
                    {team.crestIcon}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-bold text-xs text-white truncate">{team.name}</h4>
                    <span className="text-[11px] text-slate-400 block truncate">
                      {team.stadium} · {team.city}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => toggleFavoriteTeam(team.id)}
                  className={`p-2 rounded-xl border transition-all cursor-pointer ${
                    isFav
                      ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                      : 'bg-[#0e1933] border-[#182e59] text-slate-500 hover:text-slate-300'
                  }`}
                  aria-label={isFav ? `Unfollow ${team.name}` : `Follow ${team.name}`}
                >
                  <Star className={`w-4 h-4 ${isFav ? 'fill-amber-300' : ''}`} />
                </button>
              </div>
            );
          })}
        </div>

        {activeFilter === 'followed' && followedTeams.length === 0 && (
          <div className="py-8 text-center text-slate-400 space-y-2">
            <p className="text-xs">You haven't followed any clubs yet.</p>
            <button
              onClick={() => setActiveFilter('all')}
              className="text-xs font-bold text-amber-400 hover:underline"
            >
              Browse all teams to follow your favorites →
            </button>
          </div>
        )}
      </div>

      {/* 3. Upcoming Matches for Followed Clubs */}
      {upcomingFavoriteMatches.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <span>Upcoming Matches for Followed Clubs</span>
            </h3>
            <button
              onClick={onNavigateToMatches}
              className="text-xs font-semibold text-emerald-400 hover:underline cursor-pointer"
            >
              All Fixtures →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {upcomingFavoriteMatches.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        </div>
      )}

      {/* 4. Alert Customization Card */}
      <div className="p-5 sm:p-6 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-4">
        <div className="flex items-center gap-2.5 border-b border-[#14264b] pb-3">
          <Bell className="w-5 h-5 text-emerald-400" />
          <div>
            <h3 className="font-display font-bold text-base text-white">
              {t('customNotifications')}
            </h3>
            <p className="text-xs text-slate-400">
              Customize real-time push and audio triggers for your followed teams
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-[#081224] border border-[#14264b] flex items-center justify-between gap-3">
            <div>
              <span className="text-white font-bold block">{t('goalAlerts')}</span>
              <span className="text-slate-400 text-[11px]">Instant audio ping & toast notification</span>
            </div>
            <input
              type="checkbox"
              checked={goalAlerts}
              onChange={(e) => setGoalAlerts(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          <div className="p-4 rounded-2xl bg-[#081224] border border-[#14264b] flex items-center justify-between gap-3">
            <div>
              <span className="text-white font-bold block">{t('kickoffAlerts')}</span>
              <span className="text-slate-400 text-[11px]">Reminder 15 minutes prior to kickoff</span>
            </div>
            <input
              type="checkbox"
              checked={kickoffAlerts}
              onChange={(e) => setKickoffAlerts(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          <div className="p-4 rounded-2xl bg-[#081224] border border-[#14264b] flex items-center justify-between gap-3">
            <div>
              <span className="text-white font-bold block">{t('redCardAlerts')}</span>
              <span className="text-slate-400 text-[11px]">Immediate disciplinary incident alert</span>
            </div>
            <input
              type="checkbox"
              checked={redCardAlerts}
              onChange={(e) => setRedCardAlerts(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          <div className="p-4 rounded-2xl bg-[#081224] border border-[#14264b] flex items-center justify-between gap-3">
            <div>
              <span className="text-white font-bold block">{t('settlementAlerts')}</span>
              <span className="text-slate-400 text-[11px]">Notification on prediction win or settlement</span>
            </div>
            <input
              type="checkbox"
              checked={settlementAlerts}
              onChange={(e) => setSettlementAlerts(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
