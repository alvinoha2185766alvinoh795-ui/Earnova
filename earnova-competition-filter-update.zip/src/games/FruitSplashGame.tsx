import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  RotateCcw,
  Trophy,
  Coins,
  Sparkles,
  ArrowLeft,
  Volume2,
  VolumeX,
  Flame,
  Zap,
  Timer,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type FruitType = 'watermelon' | 'bell' | 'grapes' | 'strawberry' | 'lemon' | 'cherry';

interface FruitTile {
  id: string;
  type: FruitType;
}

const FRUITS: Record<FruitType, { icon: string; name: string; points: number; bg: string; border: string }> = {
  watermelon: { icon: '🍉', name: 'Watermelon', points: 45, bg: 'from-emerald-600 to-rose-700', border: 'border-emerald-400' },
  bell: { icon: '🔔', name: 'Golden Bell', points: 80, bg: 'from-amber-400 to-yellow-600', border: 'border-yellow-300' },
  grapes: { icon: '🍇', name: 'Grapes', points: 35, bg: 'from-purple-600 to-indigo-800', border: 'border-purple-400' },
  strawberry: { icon: '🍓', name: 'Strawberry', points: 30, bg: 'from-rose-500 to-red-700', border: 'border-rose-400' },
  lemon: { icon: '🍋', name: 'Lemon', points: 25, bg: 'from-yellow-400 to-amber-600', border: 'border-yellow-400' },
  cherry: { icon: '🍒', name: 'Cherries', points: 20, bg: 'from-red-600 to-rose-900', border: 'border-red-400' },
};

const FRUIT_KEYS: FruitType[] = ['watermelon', 'bell', 'grapes', 'strawberry', 'lemon', 'cherry'];
const ROWS = 6;
const COLS = 6;
const GAME_DURATION = 45; // 45 seconds arcade rush

const createFruit = (r: number, c: number): FruitTile => {
  const type = FRUIT_KEYS[Math.floor(Math.random() * FRUIT_KEYS.length)];
  return { id: `fruit-${r}-${c}-${Date.now()}-${Math.random()}`, type };
};

const createFruitGrid = (): FruitTile[][] => {
  const grid: FruitTile[][] = [];
  for (let r = 0; r < ROWS; r++) {
    const row: FruitTile[] = [];
    for (let c = 0; c < COLS; c++) {
      row.push(createFruit(r, c));
    }
    grid.push(row);
  }
  return grid;
};

interface FruitSplashGameProps {
  onBack?: () => void;
}

export const FruitSplashGame: React.FC<FruitSplashGameProps> = ({ onBack }) => {
  const { user, updateUser, refillDemoPoints } = useEarnova();
  const [grid, setGrid] = useState<FruitTile[][]>(() => createFruitGrid());
  const [score, setScore] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(GAME_DURATION);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [frenzyMeter, setFrenzyMeter] = useState<number>(0);
  const [isFrenzyActive, setIsFrenzyActive] = useState<boolean>(false);
  const [combo, setCombo] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [lastSplash, setLastSplash] = useState<string | null>(null);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [earnedEP, setEarnedEP] = useState<number>(0);

  // Timer countdown
  useEffect(() => {
    if (!isPlaying || timeLeft <= 0 || gameOver) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsPlaying(false);
          setGameOver(true);
          // Award demo EP based on score
          const reward = Math.max(50, Math.floor(score / 10));
          setEarnedEP(reward);
          updateUser({ points: user.points + reward });
          confetti({ particleCount: 60, spread: 60 });
          if (soundEnabled) sound.playWin();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlaying, timeLeft, gameOver, score, soundEnabled, updateUser, user.points]);

  // Frenzy timer (lasts 8 seconds once triggered)
  useEffect(() => {
    if (!isFrenzyActive) return;
    const timeout = setTimeout(() => {
      setIsFrenzyActive(false);
      setFrenzyMeter(0);
    }, 8000);
    return () => clearTimeout(timeout);
  }, [isFrenzyActive]);

  // Find connected cluster of identical fruits via flood fill (DFS)
  const getConnectedCluster = (startR: number, startC: number, fruitType: FruitType): { r: number; c: number }[] => {
    const visited = new Set<string>();
    const cluster: { r: number; c: number }[] = [];

    const dfs = (r: number, c: number) => {
      if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
      const key = `${r},${c}`;
      if (visited.has(key)) return;
      if (grid[r][c].type !== fruitType) return;

      visited.add(key);
      cluster.push({ r, c });

      // 4 directions
      dfs(r + 1, c);
      dfs(r - 1, c);
      dfs(r, c + 1);
      dfs(r, c - 1);
    };

    dfs(startR, startC);
    return cluster;
  };

  const handleTileClick = (r: number, c: number) => {
    if (gameOver) return;

    // Auto-start on first tap
    if (!isPlaying && timeLeft > 0) {
      setIsPlaying(true);
    }

    const clickedFruit = grid[r][c];
    const cluster = getConnectedCluster(r, c, clickedFruit.type);

    // Require at least 2 connected fruits to splash
    if (cluster.length < 2) {
      if (soundEnabled) sound.playTap();
      return;
    }

    if (soundEnabled) sound.playBonus();

    const mult = isFrenzyActive ? 3 : 1;
    const clusterPoints = cluster.length * FRUITS[clickedFruit.type].points * mult;
    setScore((prev) => prev + clusterPoints);
    setCombo((prev) => prev + 1);

    // Update frenzy meter
    setFrenzyMeter((prev) => {
      const next = prev + cluster.length * 4;
      if (next >= 100 && !isFrenzyActive) {
        setIsFrenzyActive(true);
        confetti({ particleCount: 40, spread: 50 });
        if (soundEnabled) sound.playWin();
        return 100;
      }
      return Math.min(100, next);
    });

    setLastSplash(`+${clusterPoints} PTS (${cluster.length}x ${FRUITS[clickedFruit.type].name})!`);

    // Gravity fall & replace splashed fruits
    const nextGrid = grid.map((row) => row.map((fruit) => ({ ...fruit })));

    // For each column, collapse downwards
    for (let col = 0; col < COLS; col++) {
      let writeRow = ROWS - 1;
      for (let row = ROWS - 1; row >= 0; row--) {
        const isSplashed = cluster.some((item) => item.r === row && item.c === col);
        if (!isSplashed) {
          if (writeRow !== row) {
            nextGrid[writeRow][col] = nextGrid[row][col];
          }
          writeRow--;
        }
      }
      // Fill upper remaining spaces with fresh juicy fruits
      while (writeRow >= 0) {
        nextGrid[writeRow][col] = createFruit(writeRow, col);
        writeRow--;
      }
    }

    setGrid(nextGrid);
  };

  const handleRestart = () => {
    setGrid(createFruitGrid());
    setScore(0);
    setTimeLeft(GAME_DURATION);
    setIsPlaying(false);
    setGameOver(false);
    setFrenzyMeter(0);
    setIsFrenzyActive(false);
    setCombo(0);
    setLastSplash(null);
    setEarnedEP(0);
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* Header bar */}
      <div className="flex items-center justify-between pb-3 border-b border-rose-900/50">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#0c1830] border border-rose-500/40 text-rose-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🍉</span>
              <h2 className="font-display font-black text-lg sm:text-xl text-white tracking-tight">
                Fruit Splash Arcade
              </h2>
            </div>
            <p className="text-[11px] text-rose-300/80 font-mono">
              Extra Juicy Cluster Matching · 100% Free Demo EP
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-[#0c1830] border border-rose-500/40 text-rose-300 hover:text-white cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleRestart}
            className="p-2 rounded-xl bg-[#0c1830] border border-rose-500/40 text-rose-300 hover:text-white cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Dashboard Strip */}
      <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-gradient-to-r from-[#240316] via-[#350720] to-[#17020d] border border-rose-500/40 shadow-xl">
        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-rose-300 block">Juice Score</span>
          <span className="font-mono font-black text-xl text-yellow-300 tabular-nums">
            {score.toLocaleString()}
          </span>
          {lastSplash ? (
            <span className="text-[9px] text-emerald-400 block font-semibold truncate">
              {lastSplash}
            </span>
          ) : (
            <span className="text-[9px] text-rose-300/60 block">Tap 2+ clusters</span>
          )}
        </div>

        <div className="text-center border-x border-rose-500/30">
          <span className="text-[10px] uppercase font-bold text-rose-300 block">Time Left</span>
          <span
            className={`font-mono font-black text-xl tabular-nums ${
              timeLeft <= 10 ? 'text-rose-400 animate-pulse' : 'text-white'
            }`}
          >
            {timeLeft}s
          </span>
          <span className="text-[9px] text-amber-300 block font-semibold">
            {isFrenzyActive ? '🔥 3X FRENZY' : `Combo: ${combo}x`}
          </span>
        </div>

        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-rose-300 block">Virtual EP</span>
          <span className="font-mono font-black text-base text-emerald-400 tabular-nums">
            {(user?.points ?? 0).toLocaleString()}
          </span>
          <span className="text-[9px] text-slate-400 block">Balance</span>
        </div>
      </div>

      {/* Juice Fever Meter */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] font-mono">
          <span className="text-amber-300 font-bold flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-yellow-400" />
            {isFrenzyActive ? '🔥 EXTRA JUICY FRENZY (3X MULTIPLIER ACTIVE)!' : 'Juice Fever Meter'}
          </span>
          <span className="text-yellow-400 font-bold">{frenzyMeter}%</span>
        </div>
        <div className="h-3 w-full bg-[#12020e] rounded-full overflow-hidden p-0.5 border border-rose-900/60">
          <div
            className={`h-full rounded-full transition-all duration-300 ${
              isFrenzyActive
                ? 'bg-gradient-to-r from-amber-400 via-rose-500 to-yellow-300 animate-pulse'
                : 'bg-gradient-to-r from-rose-600 via-pink-500 to-amber-400'
            }`}
            style={{ width: `${frenzyMeter}%` }}
          />
        </div>
      </div>

      {/* 6x6 Juicy Grid */}
      <div className="relative p-3 rounded-3xl bg-gradient-to-b from-[#2a0518] to-[#12020a] border-2 border-rose-600/60 shadow-2xl overflow-hidden">
        <div className="grid grid-cols-6 gap-1.5 sm:gap-2 max-w-[420px] mx-auto p-1">
          {grid.map((row, r) =>
            row.map((fruit, c) => {
              const info = FRUITS[fruit.type];
              return (
                <button
                  key={fruit.id}
                  type="button"
                  onClick={() => handleTileClick(r, c)}
                  className={`aspect-square rounded-2xl flex items-center justify-center relative cursor-pointer touch-manipulation transition-all duration-150 transform select-none bg-gradient-to-br ${info.bg} border-2 ${info.border} shadow-md hover:scale-105 active:scale-90`}
                >
                  <span className="text-2xl sm:text-3xl filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] pointer-events-none">
                    {info.icon}
                  </span>
                </button>
              );
            })
          )}
        </div>

        {/* Start Game prompt if not playing yet */}
        {!isPlaying && timeLeft === GAME_DURATION && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-xs rounded-3xl flex flex-col items-center justify-center p-6 text-center z-10">
            <span className="text-4xl mb-2 animate-bounce">🍉</span>
            <h3 className="font-display font-black text-xl text-white">Tap Any Cluster to Start!</h3>
            <p className="text-xs text-rose-200 mt-1 max-w-xs">
              Connect groups of 2+ matching fruits to splash juice, build fever, and score big points in 45 seconds.
            </p>
          </div>
        )}

        {/* Game Over Modal */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center p-6 text-center z-20 animate-fade-in">
            <div className="w-16 h-16 rounded-full bg-gradient-to-b from-rose-500 to-amber-500 flex items-center justify-center text-3xl shadow-2xl shadow-rose-500/60 mb-2 animate-bounce">
              🎉
            </div>
            <h3 className="font-display font-black text-2xl text-white">EXTRA JUICY SPLASH!</h3>
            <p className="text-xs text-slate-300 mt-1 max-w-xs">
              Final Score:{' '}
              <strong className="text-yellow-400 font-mono text-sm">{score.toLocaleString()}</strong>
            </p>
            <div className="my-3 px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs">
              +{earnedEP} Virtual Demo EP Won!
            </div>
            <button
              type="button"
              onClick={handleRestart}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg hover:scale-105 active:scale-95 transition-all"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      <div className="p-3 rounded-2xl bg-[#091326] border border-rose-500/30 flex items-center justify-between text-xs text-rose-200">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-rose-400" />
          Tap any 2 or more connected fruits of the same type to splash and trigger cascading juice drops!
        </span>
      </div>
    </div>
  );
};
