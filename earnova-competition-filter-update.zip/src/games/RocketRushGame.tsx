import React, { useState, useEffect, useRef } from 'react';
import { Flame, Play, Sparkles, AlertCircle, Coins, CheckCircle2 } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

export const RocketRushGame: React.FC = () => {
  const { user, updateUser, refillDemoPoints } = useEarnova();

  const [stake, setStake] = useState<number>(50);
  const [multiplier, setMultiplier] = useState<number>(1.0);
  const [status, setStatus] = useState<'IDLE' | 'RUSHING' | 'EXPLODED' | 'CASHED_OUT'>('IDLE');
  const [winAmount, setWinAmount] = useState<number | null>(null);

  const timerRef = useRef<number | null>(null);
  const crashLimitRef = useRef<number>(2.5);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const handleLaunch = () => {
    if (user.points < stake) {
      alert('Insufficient virtual points. Use demo refill.');
      return;
    }

    // Deduct stake
    updateUser({ points: Math.max(0, user.points - stake) });
    sound.playTap();

    setStatus('RUSHING');
    setMultiplier(1.0);
    setWinAmount(null);

    // Random crash threshold between 1.1x and 12x
    const rand = Math.random();
    crashLimitRef.current = Number((1.1 + Math.pow(rand, 2) * 11).toFixed(2));

    const startTime = performance.now();

    timerRef.current = window.setInterval(() => {
      const elapsed = (performance.now() - startTime) / 1000;
      const current = Number((1.0 + Math.pow(elapsed * 0.5, 1.7)).toFixed(2));

      if (current >= crashLimitRef.current) {
        clearInterval(timerRef.current!);
        setMultiplier(crashLimitRef.current);
        setStatus('EXPLODED');
        sound.playCrash();
        return;
      }

      setMultiplier(current);
    }, 50);
  };

  const handleCashout = () => {
    if (status !== 'RUSHING') return;
    if (timerRef.current) clearInterval(timerRef.current);

    const win = Math.round(stake * multiplier);
    setWinAmount(win);
    setStatus('CASHED_OUT');
    updateUser({ points: user.points + win });
    sound.playCashout();
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold">
          <Flame className="w-3.5 h-3.5" />
          <span>Cosmic Rocket Multiplier</span>
        </div>
        <h2 className="font-display font-extrabold text-2xl text-white">Rocket Rush</h2>
        <p className="text-xs text-slate-400">Launch into orbit and eject before critical atmospheric burn!</p>
      </div>

      {/* Screen Display */}
      <div className="relative h-64 rounded-3xl bg-gradient-to-b from-[#0c081f] via-[#120f2e] to-[#060412] border border-[#261d47] overflow-hidden flex flex-col items-center justify-center p-6 shadow-2xl">
        <div className="absolute inset-0 bg-[radial-gradient(#ec4899_1px,transparent_1px)] [background-size:20px_20px] opacity-20 pointer-events-none" />

        {status === 'IDLE' && (
          <div className="text-center space-y-2">
            <span className="text-5xl block animate-bounce">🚀</span>
            <span className="font-display font-bold text-lg text-white">Rocket On Launchpad</span>
            <p className="text-xs text-slate-400">Lock your virtual EP and ignite thrusters.</p>
          </div>
        )}

        {status === 'RUSHING' && (
          <div className="text-center space-y-2">
            <span className="text-xs font-mono uppercase text-rose-400 tracking-widest font-bold">
              Altitude Rising
            </span>
            <div className="font-mono font-black text-6xl text-white tabular-nums drop-shadow-lg">
              {multiplier.toFixed(2)}x
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold block animate-pulse">
              Current: +{Math.round(stake * multiplier).toLocaleString()} EP
            </span>
          </div>
        )}

        {status === 'EXPLODED' && (
          <div className="text-center space-y-1 animate-in zoom-in-95 duration-150">
            <span className="text-4xl block">💥</span>
            <span className="font-mono font-black text-4xl text-rose-500">
              {multiplier.toFixed(2)}x EXPLODED
            </span>
            <p className="text-xs text-slate-300">Atmospheric pressure reached threshold!</p>
          </div>
        )}

        {status === 'CASHED_OUT' && (
          <div className="text-center space-y-1 animate-in zoom-in-95 duration-150">
            <span className="text-4xl block">🎉</span>
            <div className="font-mono font-black text-3xl text-emerald-400">
              +{winAmount?.toLocaleString()} EP
            </div>
            <p className="text-xs text-slate-300">Ejected safely at {multiplier.toFixed(2)}x!</p>
          </div>
        )}
      </div>

      {/* Control Panel */}
      <div className="p-4 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-300">Stake (Virtual EP)</span>
          <span className="font-mono text-emerald-400 font-bold">{(user?.points ?? 0).toLocaleString()} EP Available</span>
        </div>

        <div className="flex items-center gap-2">
          {[25, 50, 100, 250].map((amt) => (
            <button
              key={amt}
              type="button"
              disabled={status === 'RUSHING'}
              onClick={() => setStake(amt)}
              className={`flex-1 py-2.5 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                stake === amt
                  ? 'bg-rose-500 text-white border-rose-400'
                  : 'bg-[#09152b] border-[#162c57] text-slate-300 hover:text-white'
              }`}
            >
              {amt}
            </button>
          ))}
        </div>

        {status === 'RUSHING' ? (
          <button
            type="button"
            onClick={handleCashout}
            className="w-full py-4 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm uppercase tracking-wider animate-pulse shadow-lg cursor-pointer"
          >
            EJECT NOW (+{Math.round(stake * multiplier).toLocaleString()} EP)
          </button>
        ) : (
          <button
            type="button"
            onClick={handleLaunch}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 text-white font-black text-sm uppercase tracking-wider shadow-lg active:scale-95 transition-all cursor-pointer"
          >
            IGNITE ROCKET ({stake} EP)
          </button>
        )}
      </div>
    </div>
  );
};
