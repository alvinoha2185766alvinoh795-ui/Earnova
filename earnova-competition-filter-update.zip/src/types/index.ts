export type Language = 'en' | 'sw';

export interface Team {
  id: string;
  name: string;
  shortName: string;
  code: string;
  crestBg: string;
  crestColor: string;
  crestIcon: string;
  stadium: string;
  city: string;
}

export type MatchStatus = 'upcoming' | 'live' | 'finished';

export interface MatchEvent {
  id: string;
  minute: number;
  type: 'goal' | 'yellow_card' | 'red_card' | 'var' | 'sub';
  teamId: string;
  player: string;
  detail?: string;
}

export interface MatchStats {
  possession: [number, number]; // home, away in %
  shotsOnTarget: [number, number];
  totalShots: [number, number];
  corners: [number, number];
  fouls: [number, number];
  dangerousAttacks: [number, number];
  xG: [number, number];
  passesCompleted?: [number, number];
  passAccuracy?: [number, number];
}

export interface TeamFormGame {
  opponent: string;
  result: 'W' | 'D' | 'L';
  score: string;
  isHome: boolean;
}

export interface TeamIntelligence {
  recentForm: TeamFormGame[];
  cleanSheetRate: number; // percentage
  avgGoalsScored: number;
  avgGoalsConceded: number;
  possessionAvg: number;
  attackRating: number; // out of 100
  defenseRating: number; // out of 100
}

export interface MatchIntelligence {
  homeIntelligence: TeamIntelligence;
  awayIntelligence: TeamIntelligence;
  headToHeadSummary: string;
  aiExplanation: {
    summary: string;
    keyTacticalBattle: string;
    expectedGameFlow: string;
    winProbability: {
      home: number;
      draw: number;
      away: number;
    };
    aiRecommendedPick: {
      market: string;
      pick: string;
      confidence: number; // e.g. 84%
      rationale: string;
    };
  };
}

export interface MatchOdds {
  matchResult: {
    home: number;
    draw: number;
    away: number;
  };
  doubleChance: {
    homeDraw: number; // 1X
    homeAway: number; // 12
    drawAway: number; // X2
  };
  overUnder: {
    over15: number;
    under15: number;
    over25: number;
    under25: number;
    over35: number;
    under35: number;
  };
  btts: {
    yes: number;
    no: number;
  };
  correctScore: Record<string, number>;
}

export interface Match {
  id: string;
  leagueId: string;
  leagueName: string;
  leagueCountry: string;
  homeTeam: Team;
  awayTeam: Team;
  status: MatchStatus;
  minute: number;
  homeScore: number;
  awayScore: number;
  startTime: string;
  dateKey: 'today' | 'tomorrow' | 'settled';
  isFeatured?: boolean;
  odds: MatchOdds;
  events: MatchEvent[];
  stats: MatchStats;
  intelligence?: MatchIntelligence;
  gameweek?: number;
}

export type MarketType = 'matchResult' | 'doubleChance' | 'overUnder' | 'btts' | 'correctScore';

export interface PredictionSelection {
  matchId: string;
  matchTitle: string;
  marketType: MarketType;
  marketName: string;
  selectionKey: string;
  selectionLabel: string;
  odds: number;
}

export interface PlacedPrediction {
  id: string;
  timestamp: number;
  type: 'single' | 'accumulator';
  selections: PredictionSelection[];
  stake: number;
  totalOdds: number;
  potentialReturn: number;
  status: 'pending' | 'won' | 'lost';
  settledAt?: number;
  resultDetails?: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: string;
  category?: 'general' | 'champions' | 'academy' | 'trivia';
}

export interface UserProfile {
  uid?: string;
  email?: string;
  fullName?: string;
  isLoggedIn?: boolean;
  username: string;
  avatar: string;
  points: number;
  tier: string;
  rank: number;
  winStreak: number;
  longestStreak: number;
  totalPredictions: number;
  wonPredictions: number;
  lostPredictions: number;
  lastBonusClaim: number;
  soundEnabled: boolean;
  volume?: number; // 0 to 100
  notificationsEnabled: boolean;
  lowDataMode: boolean;
  favoriteTeamIds: string[];
  badges: Badge[];
  language: Language;
}

export interface NotificationItem {
  id: string;
  type: 'goal' | 'match_start' | 'match_end' | 'prediction_settled' | 'daily_bonus' | 'red_card' | 'friend_challenge' | 'trivia';
  title: string;
  message: string;
  timestamp: number;
  matchId?: string;
  read: boolean;
}

export interface LeaderboardEntry {
  rank: number;
  username: string;
  avatar: string;
  points: number;
  winRate: number;
  streak: number;
  tier: string;
  isCurrentUser?: boolean;
  weeklyPoints?: number;
}

// Community Discussions & Friend Challenges
export interface CommunityComment {
  id: string;
  author: string;
  avatar: string;
  text: string;
  timestamp: number;
  likes: number;
}

export interface CommunityPost {
  id: string;
  matchId?: string;
  matchTitle?: string;
  author: string;
  avatar: string;
  title: string;
  content: string;
  timestamp: number;
  likes: number;
  userLiked?: boolean;
  comments: CommunityComment[];
  tag: 'Prediction' | 'Tactics' | 'Discussion' | 'Debate';
}

export interface FriendChallenge {
  id: string;
  challenger: string;
  avatar: string;
  opponent: string;
  matchId: string;
  matchTitle: string;
  challengerPick: string;
  stakeEP: number;
  status: 'open' | 'accepted' | 'completed';
  winner?: string;
  myPick?: string;
}

// Prediction Academy Certification
export interface AcademyCertificationBadge {
  id: string;
  nameEn: string;
  nameSw: string;
  tierEn: string;
  tierSw: string;
  icon: string;
  badgeLevel: number;
  skillsEn: string[];
  skillsSw: string[];
  certificateCode: string;
  issuedBy: string;
}

export interface AcademyLesson {
  id: string;
  moduleNumber: number;
  titleEn: string;
  titleSw: string;
  descriptionEn: string;
  descriptionSw: string;
  contentEn: string[];
  contentSw: string[];
  quiz: {
    questionEn: string;
    questionSw: string;
    optionsEn: string[];
    optionsSw: string[];
    correctIndex: number;
    explanationEn: string;
    explanationSw: string;
  };
  rewardEP: number;
  completed: boolean;
  certificateBadge: AcademyCertificationBadge;
}

// Daily Trivia
export interface DailyTriviaQuestion {
  id: string;
  questionEn: string;
  questionSw: string;
  optionsEn: string[];
  optionsSw: string[];
  correctIndex: number;
  explanationEn: string;
  explanationSw: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

// Weekly Champions League
export interface TournamentGroup {
  groupName: string;
  standings: {
    team: Team;
    played: number;
    won: number;
    drawn: number;
    lost: number;
    goalsFor: number;
    goalsAgainst: number;
    points: number;
  }[];
}

// Virtual Wallet & Ledger
export type TransactionType =
  | 'deposit'
  | 'withdrawal'
  | 'prediction_stake'
  | 'prediction_payout'
  | 'daily_bonus'
  | 'reward';

export interface WalletTransaction {
  id: string;
  type: TransactionType;
  amount: number; // positive for incoming, negative for deduction
  description: string;
  timestamp: number;
  status: 'completed' | 'processing';
  reference: string;
  balanceAfter: number;
}

export interface DemoDepositPackage {
  id: string;
  name: string;
  epAmount: number;
  description: string;
  tag?: string;
  icon: string;
}

export interface DemoWithdrawalReward {
  id: string;
  name: string;
  epCost: number;
  rewardType: 'vip_badge' | 'tactical_trophy' | 'hall_of_fame' | 'custom_avatar' | 'virtual_payout';
  description: string;
  icon: string;
  deliveryTime: string;
}

