import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowUpRight,
  ShieldAlert,
  Award,
  Coins,
  CheckCircle2,
  Copy,
  Check,
  Info,
  Clock,
  Sparkles,
  AlertCircle,
  FileCheck,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';
import { DEMO_WITHDRAWAL_REWARDS } from '../data/mockData';
import { DemoWithdrawalReward } from '../types';

interface WithdrawalViewProps {
  onBack: () => void;
  onNavigateToWallet: () => void;
  onNavigateToMatches?: () => void;
}

export const WithdrawalView: React.FC<WithdrawalViewProps> = ({
  onBack,
  onNavigateToWallet,
  onNavigateToMatches,
}) => {
  const { user, demoWithdraw, language } = useEarnova();
  const { t } = useTranslation(language);

  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [successResult, setSuccessResult] = useState<{
    certificateId: string;
    reward: DemoWithdrawalReward;
  } | null>(null);
  const [copiedId, setCopiedId] = useState<boolean>(false);

  const handleRedeem = (reward: DemoWithdrawalReward) => {
    if (user.points < reward.epCost) return;
    setIsProcessing(true);
    setTimeout(() => {
      const res = demoWithdraw(reward.id);
      setIsProcessing(false);
      if (res.success && res.certificateId) {
        setSuccessResult({ certificateId: res.certificateId, reward });
      }
    }, 700);
  };

  const copyCertToClipboard = (text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
      }
    } catch {}
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="space-y-6 pb-16 max-w-4xl mx-auto">
      {/* 1. Header Navigation Bar */}
      <div className="flex items-center justify-between gap-4 pb-2 border-b border-[#14264b]">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#0c1830] hover:bg-[#122347] border border-[#162c57] text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer touch-manipulation active:scale-95"
          title="Back to Previous Screen"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-400" />
          <span>Back</span>
        </button>

        <div className="text-right">
          <div className="flex items-center justify-end gap-2">
            <h1 className="font-display font-extrabold text-lg sm:text-2xl text-white tracking-tight">
              Demo Withdrawal & Rewards
            </h1>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Zero Cash Value
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Redeem virtual Earnova Points for verified digital certifications & trophies
          </p>
        </div>
      </div>

      {/* 2. Educational Free-to-Play Disclaimer Notice & Proposed Minimum Withdrawal */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-amber-950/60 via-[#18233c] to-[#071329] border border-amber-500/40 shadow-xl space-y-4">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display font-bold text-base sm:text-lg text-white">
                Demonstration Reward Policy (No Real-Money Cashouts)
              </h2>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950">
                Proposed Min: KSh 50
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              In strict adherence to free-to-play educational standards, <strong>Earnova does not offer real-money cash withdrawals, bank transfers, crypto payouts, or cash prizes</strong>. Points earned through prediction accuracy are simulation trophies. They can be redeemed here for verifiable, cryptographic in-app achievement credentials and showcase trophies.
            </p>
          </div>
        </div>

        {/* Proposed Minimum Withdrawal Highlight Strip (Requirement: Minimum Withdrawal KSh 50) */}
        <div className="p-3.5 rounded-2xl bg-[#081326] border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-black text-xs font-mono shrink-0">
              KSh
            </div>
            <div>
              <span className="text-[11px] font-bold text-white block">
                Proposed Minimum Withdrawal Benchmark: <span className="text-amber-400 font-extrabold text-xs">KSh 50</span> (500 EP)
              </span>
              <span className="text-[10px] text-slate-400 block">
                Simulation threshold for educational reward redemption and prototype testing.
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs font-mono font-bold text-amber-300">
              Min: 500 EP
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-[#1d2d4f] text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Zero monetary payout</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Min withdrawal: KSh 50 (500 EP)</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Verifiable digital credentials</span>
          </div>
        </div>
      </div>

      {/* 3. Current User Points & Eligibility Card */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-[#09152b] border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Redeemable Virtual Bankroll
            </span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="font-mono font-black text-2xl sm:text-3xl text-white tabular-nums">
                {(user?.points ?? 0).toLocaleString()}
              </span>
              <span className="text-sm font-bold text-amber-400 font-mono">EP</span>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onNavigateToWallet}
          className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 self-start sm:self-auto hover:underline cursor-pointer touch-manipulation"
        >
          <span>View Full Wallet Ledger →</span>
        </button>
      </div>

      {/* 4. Virtual Rewards Catalog */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Available Demonstration Credentials</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">Trade EP for Trophies</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {DEMO_WITHDRAWAL_REWARDS.map((reward) => {
            const canAfford = user.points >= reward.epCost;
            return (
              <div
                key={reward.id}
                className={`p-5 rounded-3xl border transition-all flex flex-col justify-between gap-4 ${
                  canAfford
                    ? 'bg-[#0c1830] border-[#162c57] hover:border-amber-400/50 shadow-sm'
                    : 'bg-[#091224]/70 border-[#122345] opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-3xl">{reward.icon}</span>
                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#081224] text-slate-400 border border-[#14264b]">
                      {reward.deliveryTime}
                    </span>
                  </div>

                  <h4 className="font-display font-extrabold text-lg text-white mt-3">
                    {reward.name}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {reward.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#14264b] flex items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                      Required Points
                    </span>
                    <span className="font-mono font-black text-2xl text-amber-400 tabular-nums">
                      {reward.epCost.toLocaleString()} EP
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRedeem(reward)}
                    disabled={!canAfford || isProcessing}
                    className={`px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider active:scale-95 transition-all cursor-pointer touch-manipulation shrink-0 ${
                      canAfford
                        ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md shadow-amber-400/20'
                        : 'bg-[#122347] text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    {isProcessing
                      ? 'Issuing...'
                      : canAfford
                      ? 'Redeem Credential'
                      : 'Insufficient EP'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Success Credential Modal */}
      {successResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#09152b] border border-amber-500/50 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-400/50 text-amber-400 flex items-center justify-center mx-auto text-3xl">
              {successResult.reward.icon}
            </div>
            <div>
              <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                Virtual Credential Issued
              </span>
              <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white mt-1">
                {successResult.reward.name}
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Official demonstration credential successfully generated.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#060e1f] border border-[#14264b] text-left text-xs font-mono space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>Certificate ID:</span>
                <button
                  type="button"
                  onClick={() => copyCertToClipboard(successResult.certificateId)}
                  className="text-amber-300 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <span>{successResult.certificateId}</span>
                  {copiedId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Recipient:</span>
                <span className="text-white">{user.username}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Value Stamp:</span>
                <span className="text-emerald-400">ZERO FIAT VALUE</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setSuccessResult(null)}
                className="flex-1 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer touch-manipulation"
              >
                Done
              </button>
              <button
                type="button"
                onClick={() => {
                  setSuccessResult(null);
                  onNavigateToWallet();
                }}
                className="py-3 px-4 rounded-xl bg-[#0e1d3b] hover:bg-[#142852] border border-[#162c57] text-slate-200 text-xs font-semibold cursor-pointer touch-manipulation"
              >
                View Ledger
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
