import React, { useState } from 'react';
import { X, Trash2, Ticket, AlertCircle, ArrowUpRight, Coins } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';

export const PredictionSlip: React.FC = () => {
  const {
    slip,
    isSlipOpen,
    setIsSlipOpen,
    removePick,
    clearSlip,
    placePrediction,
    user,
    refillDemoPoints,
    requireAuth,
  } = useEarnova();

  const [stake, setStake] = useState<number>(100);
  const [betType, setBetType] = useState<'single' | 'accumulator'>('accumulator');
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  if (!isSlipOpen) return null;

  const totalOdds =
    betType === 'accumulator' && slip.length > 1
      ? Number(slip.reduce((acc, p) => acc * p.odds, 1).toFixed(2))
      : slip.length > 0
      ? Number(slip[0].odds.toFixed(2))
      : 1;

  const potentialReturn = Math.round(stake * totalOdds);
  const isBalanceInsufficient = stake > user.points;

  const handlePlace = () => {
    if (!user.isLoggedIn || !user.email) {
      requireAuth(() => {}, 'Sign in or create an account to lock in your predictions.');
      return;
    }
    setFeedback(null);
    const result = placePrediction(stake, betType);
    if (!result.success) {
      setFeedback({ message: result.message, type: 'error' });
    } else {
      setFeedback({ message: result.message, type: 'success' });
      setTimeout(() => {
        setFeedback(null);
      }, 3500);
    }
  };

  const handleQuickStake = (amount: number) => {
    setStake((prev) => Math.min(user.points, Math.max(10, prev + amount)));
  };

  const handleMaxStake = () => {
    setStake(Math.max(10, user.points));
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-xs">
      <div className="w-full max-w-md bg-[#0a1428] border-l border-[#192f5c] h-full flex flex-col shadow-2xl">
        {/* Slip Top Header */}
        <div className="p-4 border-b border-[#14264b] flex items-center justify-between bg-[#070e1c]">
          <div className="flex items-center gap-2">
            <Ticket className="w-5 h-5 text-emerald-400" />
            <h3 className="font-display font-bold text-base text-white">
              Prediction Slip
            </h3>
            <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold border border-emerald-500/30">
              {slip.length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {slip.length > 0 && (
              <button
                onClick={clearSlip}
                className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 px-2 py-1 rounded transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
            <button
              onClick={() => setIsSlipOpen(false)}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-[#122245] transition-colors"
              aria-label="Close prediction slip"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Prediction Mode Tabs (if 2+ selections) */}
        {slip.length > 1 && (
          <div className="p-2 bg-[#091326] border-b border-[#14264b] flex items-center gap-1.5">
            <button
              onClick={() => setBetType('accumulator')}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                betType === 'accumulator'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-[#112143]'
              }`}
            >
              Combo Multiplier ({slip.length} Legs)
            </button>
            <button
              onClick={() => setBetType('single')}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                betType === 'single'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-[#112143]'
              }`}
            >
              Single Pick
            </button>
          </div>
        )}

        {/* Selections List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {slip.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center text-slate-400 px-6">
              <Ticket className="w-12 h-12 text-slate-600 mb-3 stroke-[1.2]" />
              <p className="text-sm font-semibold text-slate-300">Your slip is currently empty</p>
              <p className="text-xs text-slate-500 mt-1">
                Select 1X2 odds, Double Chance, Over/Under, or Correct Score markets from the fixtures list to build your prediction.
              </p>
            </div>
          ) : (
            slip.map((item) => (
              <div
                key={`${item.matchId}_${item.selectionKey}`}
                className="p-3.5 rounded-xl bg-[#0c1830] border border-[#162a52] relative group"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <span className="text-[11px] text-slate-400 truncate block">
                      {item.matchTitle}
                    </span>
                    <h4 className="text-sm font-semibold text-white mt-0.5 truncate">
                      {item.selectionLabel}
                    </h4>
                    <span className="text-[11px] text-emerald-400/90 font-medium mt-0.5 block">
                      Market: {item.marketName}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-emerald-400 tabular-nums">
                      {item.odds.toFixed(2)}x
                    </span>
                    <button
                      onClick={() => removePick(item.matchId, item.selectionKey)}
                      className="text-slate-500 hover:text-rose-400 p-1 rounded transition-colors"
                      aria-label="Remove pick"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Slip Stake & Summary Section */}
        {slip.length > 0 && (
          <div className="p-4 bg-[#070e1c] border-t border-[#14264b] space-y-3">
            {/* User balance status */}
            <div className="flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-emerald-400" />
                <span>Available EP:</span>
                <span className="font-mono font-bold text-white tabular-nums">
                  {(user?.points ?? 0).toLocaleString()} EP
                </span>
              </div>
              {isBalanceInsufficient && (
                <button
                  onClick={refillDemoPoints}
                  className="text-emerald-400 font-semibold hover:underline"
                >
                  + Refill Demo EP
                </button>
              )}
            </div>

            {/* Stake Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 block">
                Virtual Stake (Points)
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="10"
                  max={user.points}
                  value={stake}
                  onChange={(e) => setStake(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full h-11 px-3.5 rounded-xl bg-[#0c1830] border border-[#1a3363] text-white font-mono font-bold text-sm focus:outline-none focus:border-emerald-400 transition-colors"
                  placeholder="Enter stake..."
                />
                <span className="absolute right-3.5 top-3 text-xs font-semibold text-emerald-400 font-mono">
                  EP
                </span>
              </div>
            </div>

            {/* Quick Stake Preset Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
              <button
                onClick={() => handleQuickStake(50)}
                className="px-2.5 py-1 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-xs font-mono text-slate-300 border border-[#1b3464] transition-colors"
              >
                +50
              </button>
              <button
                onClick={() => handleQuickStake(100)}
                className="px-2.5 py-1 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-xs font-mono text-slate-300 border border-[#1b3464] transition-colors"
              >
                +100
              </button>
              <button
                onClick={() => handleQuickStake(250)}
                className="px-2.5 py-1 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-xs font-mono text-slate-300 border border-[#1b3464] transition-colors"
              >
                +250
              </button>
              <button
                onClick={() => handleQuickStake(500)}
                className="px-2.5 py-1 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-xs font-mono text-slate-300 border border-[#1b3464] transition-colors"
              >
                +500
              </button>
              <button
                onClick={handleMaxStake}
                className="px-2.5 py-1 rounded-lg bg-[#142952] hover:bg-[#1c3870] text-xs font-semibold text-emerald-400 border border-emerald-500/30 transition-colors"
              >
                Max
              </button>
            </div>

            {/* Summary calculation box */}
            <div className="p-3 rounded-xl bg-[#0c1830] border border-[#162a52] space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span>Total Multiplier:</span>
                <span className="font-mono font-bold text-white tabular-nums">
                  {totalOdds.toFixed(2)}x
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Potential Return:</span>
                <span className="font-mono font-extrabold text-sm text-emerald-400 tabular-nums">
                  {potentialReturn.toLocaleString()} EP
                </span>
              </div>
            </div>

            {/* Feedback message */}
            {feedback && (
              <div
                className={`p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                  feedback.type === 'error'
                    ? 'bg-rose-950/60 border border-rose-500/30 text-rose-300'
                    : 'bg-emerald-950/60 border border-emerald-500/30 text-emerald-300'
                }`}
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{feedback.message}</span>
              </div>
            )}

            {/* Action Button */}
            <button
              onClick={handlePlace}
              disabled={isBalanceInsufficient || stake <= 0}
              className="w-full h-12 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-bold text-sm tracking-wide flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-[0.98] transition-all cursor-pointer"
            >
              <span>LOCK IN PREDICTION</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
