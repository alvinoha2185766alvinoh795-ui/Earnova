import React, { useState, useRef } from 'react';
import { Sparkles, Trophy, Coins, RotateCcw, Award } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

interface WheelSector {
  label: string;
  sub: string;
  points: number;
  color: string;
  textColor: string;
}

const SECTORS: WheelSector[] = [
  { label: '+100 EP', sub: 'Tactical Refill', points: 100, color: '#10b981', textColor: '#022c22' },
  { label: '+250 EP', sub: 'Bronze Victory', points: 250, color: '#0f2952', textColor: '#67e8f9' },
  { label: '+50 EP', sub: 'Quick Grant', points: 50, color: '#061326', textColor: '#94a3b8' },
  { label: '+500 EP', sub: 'Silver Trophy', points: 500, color: '#8b5cf6', textColor: '#ffffff' },
  { label: '+150 EP', sub: 'Scout Reward', points: 150, color: '#047857', textColor: '#ffffff' },
  { label: '+2,000 EP', sub: 'MEGA JACKPOT', points: 2000, color: '#f59e0b', textColor: '#000000' },
  { label: '+75 EP', sub: 'Pitch Pass', points: 75, color: '#1e3a8a', textColor: '#ffffff' },
  { label: '+350 EP', sub: 'Gold Whistle', points: 350, color: '#059669', textColor: '#ffffff' },
];

export const LuckyWheelGame: React.FC = () => {
  const { user, updateUser, refillDemoPoints } = useEarnova();

  const [rotation, setRotation] = useState<number>(0);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [winningSector, setWinningSector] = useState<WheelSector | null>(null);
  const [spinCost] = useState<number>(50);

  const spinTimeoutRef = useRef<number | null>(null);

  const handleSpin = () => {
    if (isSpinning) return;
    if (user.points < spinCost) {
      alert('Insufficient virtual points. Use demo refill to top up free EP.');
      return;
    }

    // Deduct spin cost
    updateUser({ points: Math.max(0, user.points - spinCost) });
    sound.playTap();

    setIsSpinning(true);
    setWinningSector(null);

    const sectorCount = SECTORS.length;
    const targetIdx = Math.floor(Math.random() * sectorCount);
    const sectorAngle = 360 / sectorCount;

    const baseTurns = 5 + Math.floor(Math.random() * 3);
    const targetDeg = 360 - (targetIdx * sectorAngle + sectorAngle / 2);
    const totalRotation = rotation + baseTurns * 360 + (targetDeg - (rotation % 360));

    setRotation(totalRotation);

    let ticks = 0;
    const tickInterval = setInterval(() => {
      ticks++;
      sound.playSpinTick();
      if (ticks >= 20) clearInterval(tickInterval);
    }, 150);

    spinTimeoutRef.current = window.setTimeout(() => {
      clearInterval(tickInterval);
      const won = SECTORS[targetIdx];
      setWinningSector(won);
      setIsSpinning(false);

      // Award points
      updateUser({ points: user.points + won.points });
      sound.playCashout();
    }, 3600);
  };

  const sectorAngle = 360 / SECTORS.length;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Lucky Wheel Grand Arena</span>
        </div>
        <h2 className="font-display font-black text-2xl text-white">Lucky Wheel</h2>
        <p className="text-xs text-slate-400">Spin the mega wheel for 50 virtual EP to claim up to +2,000 EP Jackpot!</p>
      </div>

      {/* Wheel Stage */}
      <div className="relative flex flex-col items-center justify-center p-6 rounded-3xl bg-[#0c1830] border border-[#162c57] shadow-2xl">
        {/* Top Pointer Indicator */}
        <div className="absolute top-2 z-20 flex flex-col items-center">
          <div className="w-6 h-7 bg-gradient-to-b from-amber-400 to-amber-500 clip-triangle shadow-lg transform rotate-180 rounded-xs" />
        </div>

        {/* The Rotating Wheel */}
        <div className="relative w-64 h-64 sm:w-76 sm:h-76 my-4">
          <div
            className="w-full h-full rounded-full border-4 border-amber-400/80 shadow-2xl overflow-hidden"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: isSpinning ? 'transform 3.5s cubic-bezier(0.12, 0.8, 0.33, 1)' : 'none',
            }}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {SECTORS.map((sector, i) => {
                const startAngle = (i * sectorAngle * Math.PI) / 180;
                const endAngle = ((i + 1) * sectorAngle * Math.PI) / 180;

                const x1 = 50 + 50 * Math.cos(startAngle);
                const y1 = 50 + 50 * Math.sin(startAngle);
                const x2 = 50 + 50 * Math.cos(endAngle);
                const y2 = 50 + 50 * Math.sin(endAngle);

                const textAngle = i * sectorAngle + sectorAngle / 2;
                const textRad = (textAngle * Math.PI) / 180;
                const textX = 50 + 32 * Math.cos(textRad);
                const textY = 50 + 32 * Math.sin(textRad);

                return (
                  <g key={i}>
                    <path
                      d={`M 50 50 L ${x1} ${y1} A 50 50 0 0 1 ${x2} ${y2} Z`}
                      fill={sector.color}
                      stroke="#081426"
                      strokeWidth="0.8"
                    />
                    <text
                      x={textX}
                      y={textY}
                      fill={sector.textColor}
                      fontSize="3.8"
                      fontWeight="bold"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${textAngle + 90}, ${textX}, ${textY})`}
                    >
                      {sector.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Golden Center Hub */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-amber-200 border-2 border-white shadow-xl flex items-center justify-center font-display font-black text-slate-950 text-xs shadow-amber-500/30">
            SPIN
          </div>
        </div>

        {/* Win Result Modal/Banner */}
        {winningSector && (
          <div className="mt-2 p-3.5 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-emerald-500/10 to-emerald-500/20 border border-emerald-400 text-center animate-in zoom-in-95 duration-200 w-full max-w-sm">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
              Prize Unlocked!
            </span>
            <div className="font-display font-black text-2xl text-white mt-0.5">
              +{winningSector.points} EP
            </div>
            <p className="text-xs text-slate-300">{winningSector.sub} credited to your virtual bankroll.</p>
          </div>
        )}

        {/* Spin CTA Button */}
        <div className="mt-4 w-full max-w-sm flex flex-col gap-2">
          <button
            type="button"
            onClick={handleSpin}
            disabled={isSpinning || user.points < spinCost}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-emerald-500 hover:brightness-110 text-slate-950 font-display font-black text-sm uppercase tracking-wider shadow-lg shadow-emerald-500/25 active:scale-95 transition-all cursor-pointer touch-manipulation disabled:opacity-50"
          >
            {isSpinning ? 'WHEEL IS SPINNING...' : `SPIN LUCKY WHEEL (${spinCost} EP)`}
          </button>

          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Bankroll: <strong className="text-white font-mono">{(user?.points ?? 0).toLocaleString()} EP</strong></span>
            <button
              type="button"
              onClick={refillDemoPoints}
              className="text-emerald-400 hover:text-emerald-300 underline font-semibold"
            >
              +1,000 Refill
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
