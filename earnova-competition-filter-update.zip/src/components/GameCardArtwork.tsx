import React from 'react';

interface GameCardArtworkProps {
  gameId: string;
  className?: string;
}

export const GameCardArtwork: React.FC<GameCardArtworkProps> = ({ gameId, className = 'w-full h-full' }) => {
  switch (gameId) {
    case 'temple_treasure':
      return (
        <div className={`relative overflow-hidden bg-gradient-to-br from-[#1a1202] via-[#2d1f05] to-[#0a1510] flex items-center justify-center ${className}`}>
          {/* Aztec Sun Discs Background */}
          <svg className="absolute inset-0 w-full h-full opacity-35" viewBox="0 0 400 240" fill="none">
            <circle cx="200" cy="120" r="110" stroke="#f59e0b" strokeWidth="2" strokeDasharray="6 4" />
            <circle cx="200" cy="120" r="85" stroke="#fbbf24" strokeWidth="1.5" />
            <circle cx="200" cy="120" r="60" stroke="#d97706" strokeWidth="3" />
            {/* Sun Rays */}
            {Array.from({ length: 16 }).map((_, i) => (
              <line
                key={i}
                x1="200"
                y1="120"
                x2={200 + 120 * Math.cos((i * Math.PI) / 8)}
                y2={120 + 120 * Math.sin((i * Math.PI) / 8)}
                stroke="#f59e0b"
                strokeWidth="1.5"
                strokeOpacity="0.4"
              />
            ))}
          </svg>

          {/* Central Aztec Gold Mask & Glowing Gems */}
          <div className="relative z-10 flex flex-col items-center justify-center p-3 text-center">
            <div className="relative mb-1">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-b from-amber-400 via-amber-600 to-amber-900 border-2 border-yellow-300 flex items-center justify-center shadow-2xl shadow-amber-500/50">
                <span className="text-3xl sm:text-4xl filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">🗿</span>
              </div>
              {/* Surrounding Gems */}
              <span className="absolute -top-1 -left-2 text-base filter drop-shadow-[0_0_6px_#10b981]">💎</span>
              <span className="absolute -top-1 -right-2 text-base filter drop-shadow-[0_0_6px_#ef4444]">♦️</span>
              <span className="absolute -bottom-1 -left-2 text-base filter drop-shadow-[0_0_6px_#3b82f6]">🔷</span>
              <span className="absolute -bottom-1 -right-2 text-base filter drop-shadow-[0_0_6px_#8b5cf6]">🔮</span>
            </div>

            {/* Title Banner */}
            <div className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-600 via-emerald-600 to-amber-600 border border-yellow-300/80 shadow-lg mt-1">
              <span className="font-display font-black text-[11px] sm:text-xs text-yellow-200 uppercase tracking-widest drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
                TEMPLE TREASURE
              </span>
            </div>
            <span className="text-[9px] font-mono font-bold text-emerald-300 mt-0.5 tracking-wider uppercase">
              AZTEC GEM QUEST
            </span>
          </div>

          {/* Gold Coin sparkles */}
          <div className="absolute bottom-1 left-2 text-xs opacity-75">🪙</div>
          <div className="absolute bottom-1 right-2 text-xs opacity-75">🪙</div>
          <div className="absolute top-2 right-2 text-xs text-amber-300">✨</div>
        </div>
      );

    case 'fruit_splash':
      return (
        <div className={`relative overflow-hidden bg-gradient-to-br from-[#2a0418] via-[#3d0826] to-[#120324] flex items-center justify-center ${className}`}>
          {/* Radial glow */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(244,63,94,0.35)_0%,_transparent_70%)]" />

          {/* Fruit Splash Elements */}
          <div className="relative z-10 flex flex-col items-center justify-center p-3 text-center">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <span className="text-2xl sm:text-3xl filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.7)] animate-bounce" style={{ animationDuration: '2.4s' }}>
                🍉
              </span>
              <span className="text-2xl sm:text-3xl filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.7)] animate-bounce" style={{ animationDuration: '2s' }}>
                🔔
              </span>
              <span className="text-2xl sm:text-3xl filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.7)] animate-bounce" style={{ animationDuration: '2.8s' }}>
                🍇
              </span>
              <span className="text-2xl sm:text-3xl filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.7)] animate-bounce" style={{ animationDuration: '2.2s' }}>
                🍓
              </span>
            </div>

            {/* 3D Title Plate */}
            <div className="px-3 py-1 rounded-xl bg-gradient-to-r from-rose-600 via-amber-500 to-rose-600 border border-rose-300/80 shadow-xl shadow-rose-950/50 mt-1">
              <span className="font-display font-black text-[11px] sm:text-xs text-white uppercase tracking-widest drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
                FRUIT SPLASH
              </span>
            </div>
            <span className="text-[9px] font-mono font-bold text-amber-300 mt-0.5 tracking-wider uppercase">
              EXTRA JUICY ARCADE
            </span>
          </div>

          <div className="absolute top-2 left-2 text-xs text-rose-300">💦</div>
          <div className="absolute top-2 right-2 text-xs text-yellow-300">✨</div>
          <div className="absolute bottom-2 left-3 text-xs opacity-80">🍋</div>
          <div className="absolute bottom-2 right-3 text-xs opacity-80">🍒</div>
        </div>
      );

    case 'pharaohs_treasure':
      return (
        <div className={`relative overflow-hidden bg-gradient-to-br from-[#1c1202] via-[#2c1d06] to-[#0d1624] flex items-center justify-center ${className}`}>
          {/* Desert Pyramid & Hieroglyphs */}
          <svg className="absolute inset-0 w-full h-full opacity-30" viewBox="0 0 400 240" fill="none">
            <polygon points="200,40 100,200 300,200" stroke="#f59e0b" strokeWidth="2" fill="none" />
            <polygon points="120,80 50,200 190,200" stroke="#d97706" strokeWidth="1" strokeDasharray="4 4" />
            <circle cx="200" cy="90" r="18" stroke="#fbbf24" strokeWidth="2" />
          </svg>

          {/* Central Golden Pots & Scarab */}
          <div className="relative z-10 flex flex-col items-center justify-center p-3 text-center">
            <div className="relative mb-1 flex items-center justify-center gap-1">
              <span className="text-xl sm:text-2xl filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">🏺</span>
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-sky-400 via-amber-500 to-amber-900 border-2 border-amber-300 flex items-center justify-center shadow-xl shadow-amber-500/40">
                <span className="text-2xl sm:text-3xl filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">🪲</span>
              </div>
              <span className="text-xl sm:text-2xl filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">🏺</span>
            </div>

            {/* Title Banner */}
            <div className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-700 via-amber-500 to-amber-700 border border-yellow-300/80 shadow-lg mt-1">
              <span className="font-display font-black text-[11px] sm:text-xs text-yellow-100 uppercase tracking-widest drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
                PHARAOH'S TREASURE
              </span>
            </div>
            <span className="text-[9px] font-mono font-bold text-sky-300 mt-0.5 tracking-wider uppercase">
              3 POTS OF EGYPT
            </span>
          </div>

          <div className="absolute top-2 left-2 text-xs text-amber-300">☀️</div>
          <div className="absolute bottom-1.5 left-2 text-xs">🪙</div>
          <div className="absolute bottom-1.5 right-2 text-xs">🪙</div>
        </div>
      );

    case 'chilli_dash':
      return (
        <div className={`relative overflow-hidden bg-gradient-to-br from-[#3b0804] via-[#520d06] to-[#1a0301] flex items-center justify-center ${className}`}>
          {/* Flame Rays background */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(239,68,68,0.45)_0%,_transparent_75%)]" />

          {/* Central Chilli with Sunglasses */}
          <div className="relative z-10 flex flex-col items-center justify-center p-3 text-center">
            <div className="relative mb-1 flex items-center justify-center">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-b from-orange-500 via-red-600 to-red-950 border-2 border-amber-400 flex items-center justify-center shadow-2xl shadow-red-500/60 relative">
                <span className="text-3xl sm:text-4xl filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">🌶️</span>
                <span className="absolute -top-1 right-1 text-base">🕶️</span>
              </div>
              <span className="absolute -left-3 text-lg animate-pulse">🔥</span>
              <span className="absolute -right-3 text-lg animate-pulse">🔥</span>
            </div>

            {/* Title Banner */}
            <div className="px-3 py-1 rounded-xl bg-gradient-to-r from-red-600 via-amber-500 to-red-600 border border-yellow-300/80 shadow-lg mt-1">
              <span className="font-display font-black text-[11px] sm:text-xs text-white uppercase tracking-widest drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
                CHILLI DASH
              </span>
            </div>
            <span className="text-[9px] font-mono font-bold text-amber-300 mt-0.5 tracking-wider uppercase">
              SIZZLING REFLEX RUNNER
            </span>
          </div>

          <div className="absolute top-2 left-2 text-xs text-red-400">🔥</div>
          <div className="absolute top-2 right-2 text-xs text-amber-400">⚡</div>
          <div className="absolute bottom-1 right-2 text-xs">🌶️</div>
        </div>
      );

    case 'spellbound_trio':
      return (
        <div className={`relative overflow-hidden bg-gradient-to-br from-[#12082b] via-[#240e4f] to-[#071329] flex items-center justify-center ${className}`}>
          {/* Arcane Magic Rings */}
          <svg className="absolute inset-0 w-full h-full opacity-35" viewBox="0 0 400 240" fill="none">
            <circle cx="200" cy="120" r="95" stroke="#a855f7" strokeWidth="1.5" strokeDasharray="8 6" />
            <polygon points="200,35 270,165 130,165" stroke="#38bdf8" strokeWidth="1" />
            <polygon points="200,205 130,75 270,75" stroke="#34d399" strokeWidth="1" />
          </svg>

          {/* Three Sorceresses Icons */}
          <div className="relative z-10 flex flex-col items-center justify-center p-3 text-center">
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-b from-emerald-500 to-emerald-950 border border-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-500/40">
                <span className="text-lg sm:text-xl">🧝‍♀️</span>
              </div>
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-b from-amber-500 to-rose-950 border-2 border-amber-300 flex items-center justify-center shadow-xl shadow-rose-500/40">
                <span className="text-xl sm:text-2xl">🧙‍♀️</span>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-b from-sky-500 to-indigo-950 border border-sky-400 flex items-center justify-center shadow-lg shadow-sky-500/40">
                <span className="text-lg sm:text-xl">🧚‍♀️</span>
              </div>
            </div>

            {/* Title Banner */}
            <div className="px-3 py-1 rounded-xl bg-gradient-to-r from-purple-700 via-fuchsia-600 to-purple-700 border border-purple-300/80 shadow-lg mt-1">
              <span className="font-display font-black text-[11px] sm:text-xs text-white uppercase tracking-widest drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
                SPELLBOUND TRIO
              </span>
            </div>
            <span className="text-[9px] font-mono font-bold text-fuchsia-300 mt-0.5 tracking-wider uppercase">
              WILD MAGIC RUNE QUEST
            </span>
          </div>

          <div className="absolute top-2 left-2 text-xs text-purple-300">✨</div>
          <div className="absolute top-2 right-2 text-xs text-sky-300">🔮</div>
          <div className="absolute bottom-2 left-3 text-xs text-emerald-300">🌿</div>
          <div className="absolute bottom-2 right-3 text-xs text-amber-300">⚡</div>
        </div>
      );

    case 'royal_crown':
    default:
      return (
        <div className={`relative overflow-hidden bg-gradient-to-br from-[#240821] via-[#380e34] to-[#110419] flex items-center justify-center ${className}`}>
          {/* Royal Diamond Lattice Background */}
          <svg className="absolute inset-0 w-full h-full opacity-25" viewBox="0 0 400 240" fill="none">
            <pattern id="royal-grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M15 0 L30 15 L15 30 L0 15 Z" stroke="#fbbf24" strokeWidth="1" fill="none" />
            </pattern>
            <rect width="100%" height="100%" fill="url(#royal-grid)" />
          </svg>

          {/* Central Imperial Velvet Crown */}
          <div className="relative z-10 flex flex-col items-center justify-center p-3 text-center">
            <div className="relative mb-1 flex items-center justify-center">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-b from-amber-400 via-rose-700 to-purple-950 border-2 border-yellow-300 flex items-center justify-center shadow-2xl shadow-amber-500/50">
                <span className="text-3xl sm:text-4xl filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">👑</span>
              </div>
              <span className="absolute -top-2 text-base filter drop-shadow-[0_0_8px_#fbbf24]">⭐</span>
              <span className="absolute -bottom-1 -left-2 text-xs">💎</span>
              <span className="absolute -bottom-1 -right-2 text-xs">💎</span>
            </div>

            {/* Title Banner */}
            <div className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 border border-yellow-300 shadow-xl mt-1">
              <span className="font-display font-black text-[11px] sm:text-xs text-slate-950 uppercase tracking-widest">
                ROYAL CROWN
              </span>
            </div>
            <span className="text-[9px] font-mono font-bold text-amber-300 mt-0.5 tracking-wider uppercase">
              BURNING CLASSICS CHALLENGE
            </span>
          </div>

          <div className="absolute top-2 left-2 text-xs text-yellow-300">✨</div>
          <div className="absolute top-2 right-2 text-xs text-yellow-300">✨</div>
          <div className="absolute bottom-1.5 left-2 text-xs">⚜️</div>
          <div className="absolute bottom-1.5 right-2 text-xs">⚜️</div>
        </div>
      );
  }
};
