import React, { useState } from 'react';
import {
  User,
  Shield,
  Volume2,
  VolumeX,
  Bell,
  BellOff,
  Coins,
  RefreshCw,
  Sparkles,
  Check,
  Edit2,
  Award,
  RotateCcw,
  Wallet,
  Settings,
  LogIn,
  LogOut,
  Mail,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';

const AVATAR_OPTIONS = ['⚡', '👑', '🎯', '🦅', '🛡️', '⭐', '🔷', '🔴'];

interface ProfileViewProps {
  onNavigateToWallet?: () => void;
  onNavigateToLeaderboard?: () => void;
  onNavigateToSettings?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  onNavigateToWallet,
  onNavigateToLeaderboard,
  onNavigateToSettings,
}) => {
  const {
    user,
    updateUser,
    claimDailyBonus,
    refillDemoPoints,
    resetAllDemoData,
    openAuthModal,
    logoutUser,
  } = useEarnova();

  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(user.username);
  const [bonusClaimStatus, setBonusClaimStatus] = useState<string | null>(null);

  const winRate =
    user.totalPredictions > 0
      ? Math.round((user.wonPredictions / user.totalPredictions) * 100)
      : 0;

  const handleSaveName = () => {
    if (nameInput.trim()) {
      updateUser({ username: nameInput.trim() });
    }
    setIsEditingName(false);
  };

  const handleClaim = () => {
    const res = claimDailyBonus();
    if (res.success) {
      setBonusClaimStatus(`Successfully claimed +${res.amount} EP!`);
    } else {
      setBonusClaimStatus(`Cooldown active. Check back in ~${res.amount} mins.`);
    }
    setTimeout(() => {
      setBonusClaimStatus(null);
    }, 4000);
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl mx-auto">
      {/* Profile Header Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#0c1830] border border-[#162c57] relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {/* Avatar & Selector */}
          <div className="flex flex-col items-center gap-2.5">
            <div className="w-24 h-24 rounded-3xl bg-[#132752] border-2 border-emerald-400 flex items-center justify-center text-5xl shadow-xl shadow-emerald-950/30">
              {user.avatar}
            </div>

            {/* Avatar quick picker */}
            <div className="flex items-center gap-1">
              {AVATAR_OPTIONS.map((av) => (
                <button
                  key={av}
                  onClick={() => updateUser({ avatar: av })}
                  className={`w-7 h-7 rounded-lg text-sm flex items-center justify-center transition-transform hover:scale-110 cursor-pointer ${
                    user.avatar === av
                      ? 'bg-emerald-500/30 ring-1 ring-emerald-400'
                      : 'bg-[#102040] hover:bg-[#152a54]'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>

          {/* User Details */}
          <div className="flex-1 text-center sm:text-left min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
              {isEditingName ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="h-9 px-3 rounded-lg bg-[#081224] border border-emerald-400 text-white font-bold text-base focus:outline-none"
                    maxLength={20}
                  />
                  <button
                    onClick={handleSaveName}
                    className="p-2 rounded-lg bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <h2 className="font-display font-extrabold text-2xl text-white truncate">
                    {user.username}
                  </h2>
                  <button
                    onClick={() => setIsEditingName(true)}
                    className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
                    aria-label="Edit display name"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/40 inline-block self-center sm:self-auto">
                {user.tier}
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5 justify-center sm:justify-start">
              {onNavigateToLeaderboard ? (
                <button
                  type="button"
                  onClick={onNavigateToLeaderboard}
                  className="hover:text-emerald-300 font-medium underline underline-offset-2 cursor-pointer touch-manipulation"
                >
                  Global Rank #{user.rank}
                </button>
              ) : (
                <span>Global Rank #{user.rank}</span>
              )}
              <span>·</span>
              <span>Tactical Predictor Level 8</span>
            </p>

            {/* Virtual Points Callout with Wallet Navigation */}
            <div className="mt-4 flex flex-wrap items-center gap-3 p-3 px-4 rounded-xl bg-[#081326] border border-[#182f5c] justify-center sm:justify-start">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                    Virtual Balance (EP)
                  </span>
                  <span className="font-mono font-black text-xl text-white tabular-nums">
                    {(user?.points ?? 0).toLocaleString()} EP
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 ml-auto">
                {onNavigateToWallet && (
                  <button
                    type="button"
                    onClick={onNavigateToWallet}
                    className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 bg-[#0f2247] hover:bg-[#142c5c] px-3 py-1.5 rounded-lg border border-emerald-500/30 transition-colors cursor-pointer touch-manipulation active:scale-95"
                  >
                    <Wallet className="w-3.5 h-3.5" />
                    <span>Open Wallet</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={refillDemoPoints}
                  className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 bg-[#10244c] hover:bg-[#163066] px-2.5 py-1.5 rounded-lg border border-emerald-500/30 transition-colors cursor-pointer touch-manipulation active:scale-95"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>+1,000 EP</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Account Credentials & Authentication Status */}
      <div className="p-5 sm:p-6 rounded-3xl bg-[#0a162e] border border-amber-500/40 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#14264b]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-white">
                Account Credentials & Security
              </h3>
              <p className="text-xs text-slate-400">
                {user.isLoggedIn !== false && user.email
                  ? 'Authenticated via Earnova Secure Accounts Service'
                  : 'Currently browsing as Guest'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {user.isLoggedIn !== false && user.email ? (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Are you sure you want to log out of your Earnova account?')) {
                    logoutUser();
                  }
                }}
                className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer touch-manipulation active:scale-95"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md hover:brightness-110 active:scale-95"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In / Register</span>
              </button>
            )}
          </div>
        </div>

        {user.isLoggedIn !== false && user.email ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3.5 rounded-2xl bg-[#060f21] border border-[#142852]">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Unique User ID (UID)</span>
              <span className="font-mono text-emerald-400 font-bold block truncate mt-0.5">
                {user.uid || 'user_earnova_demo_apex'}
              </span>
              <span className="text-[9px] text-slate-500">Unique Firebase Account ID</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#060f21] border border-[#142852]">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Registered Email</span>
              <span className="font-semibold text-white block truncate mt-0.5">
                {user.email}
              </span>
              <span className="text-[9px] text-emerald-400">Verified & Active</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#060f21] border border-[#142852]">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Full Name</span>
              <span className="font-semibold text-white block truncate mt-0.5">
                {user.fullName || user.username}
              </span>
              <span className="text-[9px] text-slate-500">@{user.username}</span>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-4">
            <p className="text-xs text-amber-200">
              Sign in or create an account to persist your predictions, rank on the Weekly Leaderboard, and claim daily virtual bonuses.
            </p>
            <button
              type="button"
              onClick={() => openAuthModal('register')}
              className="px-4 py-2 rounded-xl bg-yellow-400 text-slate-950 font-bold text-xs uppercase tracking-wider shrink-0 cursor-pointer shadow-md"
            >
              Register Free
            </button>
          </div>
        )}
      </div>

      {/* Daily Reward & Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Daily Bonus Card */}
        <div className="p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-sm text-white">Daily Streak Bonus</h3>
            </div>
            <span className="text-xs text-amber-400 font-mono font-bold">+250 EP</span>
          </div>

          <p className="text-xs text-slate-300">
            Log in daily to claim free Earnova Points and maintain your tactical prediction streak.
          </p>

          <div>
            <button
              onClick={handleClaim}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs tracking-wide shadow-md shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer"
            >
              Claim Daily Bonus (+250 EP)
            </button>
            {bonusClaimStatus && (
              <p className="text-xs text-center text-emerald-400 mt-2 font-medium">
                {bonusClaimStatus}
              </p>
            )}
          </div>
        </div>

        {/* Prediction Accuracy Breakdown */}
        <div className="p-5 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-3">
          <h3 className="font-bold text-sm text-white flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Prediction Performance</span>
          </h3>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-[#081224] border border-[#132549]">
              <span className="text-slate-400 block">Total Placed</span>
              <span className="font-mono font-bold text-base text-white tabular-nums">
                {user.totalPredictions}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#081224] border border-[#132549]">
              <span className="text-slate-400 block">Win Rate</span>
              <span className="font-mono font-bold text-base text-emerald-400 tabular-nums">
                {winRate}%
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#081224] border border-[#132549]">
              <span className="text-slate-400 block">Current Streak</span>
              <span className="font-mono font-bold text-base text-amber-400 tabular-nums">
                {user.winStreak}W
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#081224] border border-[#132549]">
              <span className="text-slate-400 block">Best Streak</span>
              <span className="font-mono font-bold text-base text-white tabular-nums">
                {user.longestStreak}W
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Badges & Achievements */}
      <div className="p-6 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-400" />
            <h3 className="font-display font-bold text-base text-white">
              Tactical Achievements
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            {user.badges.filter((b) => b.unlocked).length} of {user.badges.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {user.badges.map((badge) => (
            <div
              key={badge.id}
              className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
                badge.unlocked
                  ? 'bg-[#0f2142] border-emerald-500/30'
                  : 'bg-[#081224]/50 border-[#14264b] opacity-60'
              }`}
            >
              <span className="text-2xl shrink-0 p-1 rounded-lg bg-[#0a152a]">
                {badge.icon}
              </span>
              <div className="min-w-0">
                <h4 className="font-semibold text-xs text-white truncate">
                  {badge.name}
                </h4>
                <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">
                  {badge.description}
                </p>
                {badge.progress && !badge.unlocked && (
                  <span className="text-[10px] text-emerald-400 font-mono block mt-1">
                    {badge.progress}
                  </span>
                )}
                {badge.unlocked && (
                  <span className="text-[10px] text-emerald-400 font-semibold block mt-1">
                    ✓ Unlocked
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* App Preferences & Settings */}
      <div className="p-6 rounded-2xl bg-[#0c1830] border border-[#162c57] space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-base text-white">
            Preferences & Audio
          </h3>
          {onNavigateToSettings && (
            <button
              type="button"
              onClick={onNavigateToSettings}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer touch-manipulation active:scale-95"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Full Audio & Settings →</span>
            </button>
          )}
        </div>

        <div className="divide-y divide-[#14264a] text-xs">
          {/* Sound Toggle */}
          <div className="py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {user.soundEnabled ? (
                <Volume2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <VolumeX className="w-5 h-5 text-slate-500" />
              )}
              <div>
                <h4 className="font-semibold text-white">Synthesized Audio Effects</h4>
                <p className="text-slate-400 text-[11px]">
                  Play live goal audio chimes and prediction settlement fanfares
                </p>
              </div>
            </div>
            <button
              onClick={() => updateUser({ soundEnabled: !user.soundEnabled })}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                user.soundEnabled ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                  user.soundEnabled ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Notifications Toggle */}
          <div className="py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {user.notificationsEnabled ? (
                <Bell className="w-5 h-5 text-emerald-400" />
              ) : (
                <BellOff className="w-5 h-5 text-slate-500" />
              )}
              <div>
                <h4 className="font-semibold text-white">Real-Time Match Alerts</h4>
                <p className="text-slate-400 text-[11px]">
                  Show floating toast notifications for goals, red cards, and match kickoffs
                </p>
              </div>
            </div>
            <button
              onClick={() => updateUser({ notificationsEnabled: !user.notificationsEnabled })}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                user.notificationsEnabled ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                  user.notificationsEnabled ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>
          {/* Language Selection */}
          <div className="py-3 flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-white">App Language / Lugha</h4>
              <p className="text-slate-400 text-[11px]">
                Choose English or Kiswahili localization
              </p>
            </div>
            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#081224] border border-[#14264b]">
              <button
                onClick={() => updateUser({ language: 'en' })}
                className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  user.language === 'en' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => updateUser({ language: 'sw' })}
                className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  user.language === 'sw' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Kiswahili
              </button>
            </div>
          </div>

          {/* Smart Low-Data Mode Toggle */}
          <div className="py-3 flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-white">Smart Low-Data Mode</h4>
              <p className="text-slate-400 text-[11px]">
                Reduces animation framerates and polling bandwidth for limited internet connections
              </p>
            </div>
            <button
              onClick={() => updateUser({ lowDataMode: !user.lowDataMode })}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                user.lowDataMode ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                  user.lowDataMode ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Account Maintenance & Factory Demo Reset */}
      <div className="p-6 rounded-2xl bg-[#0c1830] border border-rose-500/20 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-semibold text-white">Reset Factory Demo Data</h4>
            <p className="text-slate-400 text-xs">
              Clear local prediction slips, reset virtual balances to 2,500 EP, and restore default demo state.
            </p>
          </div>
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to restore factory demo defaults?')) {
                resetAllDemoData();
              }
            }}
            className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo</span>
          </button>
        </div>
      </div>
    </div>
  );
};
