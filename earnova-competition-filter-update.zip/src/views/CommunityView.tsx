import React, { useState } from 'react';
import {
  MessageSquare,
  Swords,
  Heart,
  Send,
  Plus,
  Share2,
  Sparkles,
  Trophy,
  Check,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

export const CommunityView: React.FC = () => {
  const {
    communityPosts,
    friendChallenges,
    addCommunityPost,
    likeCommunityPost,
    addCommentToPost,
    acceptFriendChallenge,
    createFriendChallenge,
    matches,
    user,
    language,
  } = useEarnova();
  const { t } = useTranslation(language);

  const [activeSection, setActiveSection] = useState<'discussions' | 'challenges'>('discussions');

  // New post modal state
  const [showNewPostModal, setShowNewPostModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newTag, setNewTag] = useState<'Prediction' | 'Tactics' | 'Discussion' | 'Debate'>('Tactics');
  const [newMatchId, setNewMatchId] = useState<string>('');

  // Comment input state per post
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});

  // Challenge modal state
  const [showNewChallengeModal, setShowNewChallengeModal] = useState(false);
  const [chalMatchId, setChalMatchId] = useState(matches[0]?.id || '');
  const [chalPick, setChalPick] = useState('');
  const [chalStake, setChalStake] = useState(100);

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;
    addCommunityPost(newTitle.trim(), newContent.trim(), newTag, newMatchId || undefined);
    setNewTitle('');
    setNewContent('');
    setShowNewPostModal(false);
  };

  const handleSendChallenge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chalPick.trim()) return;
    createFriendChallenge(chalMatchId, chalPick.trim(), chalStake);
    setShowNewChallengeModal(false);
    setChalPick('');
  };

  const handleCommentSubmit = (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;
    addCommentToPost(postId, text);
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
            {t('fanCommunity')}
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Share tactical breakdowns, debate match odds, and challenge friends to virtual 1v1 duels
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeSection === 'discussions' ? (
            <button
              onClick={() => setShowNewPostModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t('createPost')}</span>
            </button>
          ) : (
            <button
              onClick={() => setShowNewChallengeModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer"
            >
              <Swords className="w-4 h-4" />
              <span>{t('challengeFriend')}</span>
            </button>
          )}
        </div>
      </div>

      {/* Mode Tabs */}
      <div className="flex items-center gap-2 p-1 bg-[#0c1830] rounded-2xl border border-[#162c57] w-fit">
        <button
          onClick={() => setActiveSection('discussions')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSection === 'discussions'
              ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>{t('discussionThreads')} ({communityPosts.length})</span>
        </button>
        <button
          onClick={() => setActiveSection('challenges')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSection === 'challenges'
              ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Swords className="w-4 h-4" />
          <span>{t('friendChallenges')} ({friendChallenges.length})</span>
        </button>
      </div>

      {/* SECTION 1: DISCUSSIONS */}
      {activeSection === 'discussions' && (
        <div className="space-y-4">
          {communityPosts.map((post) => (
            <div
              key={post.id}
              className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3 transition-all hover:border-[#1d386e]"
            >
              {/* Post Author Bar */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-[#122347] border border-[#1a3363] flex items-center justify-center text-lg">
                    {post.avatar}
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">{post.author}</h4>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {formatTimeAgo(post.timestamp)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-[#122347] text-emerald-400 font-semibold text-[10px] border border-[#182f5c]">
                    {post.tag}
                  </span>
                </div>
              </div>

              {/* Match tag if linked */}
              {post.matchTitle && (
                <div className="text-[11px] text-slate-400 font-medium bg-[#081224] px-3 py-1.5 rounded-xl border border-[#132549] w-fit">
                  Fixture: <strong className="text-emerald-300">{post.matchTitle}</strong>
                </div>
              )}

              {/* Content */}
              <div>
                <h3 className="font-display font-bold text-sm text-white">
                  {post.title}
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed whitespace-pre-line">
                  {post.content}
                </p>
              </div>

              {/* Likes & Comments Action bar */}
              <div className="pt-2 border-t border-[#14264b] flex items-center gap-4 text-xs">
                <button
                  onClick={() => likeCommunityPost(post.id)}
                  className={`flex items-center gap-1.5 font-medium transition-colors cursor-pointer ${
                    post.userLiked ? 'text-rose-400' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${post.userLiked ? 'fill-rose-400' : ''}`} />
                  <span className="font-mono">{post.likes}</span>
                </button>
                <div className="flex items-center gap-1.5 text-slate-400">
                  <MessageSquare className="w-4 h-4" />
                  <span className="font-mono">{post.comments.length}</span>
                </div>
              </div>

              {/* Comments Feed */}
              {post.comments.length > 0 && (
                <div className="space-y-2 pt-1 border-t border-[#122347]">
                  {post.comments.map((c) => (
                    <div
                      key={c.id}
                      className="p-2.5 rounded-xl bg-[#081224] border border-[#14264b] text-xs flex items-start gap-2"
                    >
                      <span className="text-base shrink-0">{c.avatar}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-white text-[11px]">{c.author}</span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {formatTimeAgo(c.timestamp)}
                          </span>
                        </div>
                        <p className="text-slate-300 text-xs mt-0.5">{c.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Add Comment input */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="text"
                  value={commentInputs[post.id] || ''}
                  onChange={(e) =>
                    setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                  }
                  onKeyDown={(e) => e.key === 'Enter' && handleCommentSubmit(post.id)}
                  placeholder="Join the discussion..."
                  className="flex-1 h-9 px-3 rounded-xl bg-[#081224] border border-[#172c54] text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-400"
                />
                <button
                  onClick={() => handleCommentSubmit(post.id)}
                  className="p-2 rounded-xl bg-[#142852] hover:bg-[#1a3469] text-emerald-400 transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SECTION 2: FRIEND CHALLENGES */}
      {activeSection === 'challenges' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0d2247] to-[#0c1830] border border-emerald-500/30 text-xs text-slate-300 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-sm">1v1 Prediction Duels</h3>
              <p className="text-slate-400 mt-0.5">
                Stake virtual Earnova Points in head-to-head tactical battles against other predictors.
              </p>
            </div>
            <button
              onClick={() => setShowNewChallengeModal(true)}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs shrink-0 cursor-pointer"
            >
              + Create Duel
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {friendChallenges.map((chal) => {
              const isAccepted = chal.status === 'accepted';
              return (
                <div
                  key={chal.id}
                  className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{chal.avatar}</span>
                      <div>
                        <h4 className="font-semibold text-white">{chal.challenger}</h4>
                        <span className="text-[10px] text-slate-400">Challenger</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-mono font-bold text-sm text-emerald-400">
                        {chal.stakeEP} EP
                      </span>
                      <span className="text-[10px] text-slate-400 block">Virtual Stake</span>
                    </div>
                  </div>

                  <div className="p-3 rounded-2xl bg-[#081224] border border-[#14264b] space-y-1 text-xs">
                    <span className="text-slate-400 block text-[11px]">{chal.matchTitle}</span>
                    <div className="flex items-center justify-between">
                      <strong className="text-white font-semibold">
                        Pick: {chal.challengerPick}
                      </strong>
                    </div>
                  </div>

                  {isAccepted ? (
                    <div className="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-500/30 text-xs text-emerald-300 flex items-center justify-between">
                      <span className="flex items-center gap-1 font-semibold">
                        <Check className="w-4 h-4 text-emerald-400" />
                        Duel Locked In
                      </span>
                      <span className="font-mono text-slate-300">Your pick: {chal.myPick}</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => acceptFriendChallenge(chal.id, 'Opposing Result')}
                      className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs tracking-wide shadow-md transition-all cursor-pointer"
                    >
                      {t('acceptChallenge')} ({chal.stakeEP} EP)
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* NEW POST MODAL */}
      {showNewPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#091326] border border-[#1b3464] rounded-3xl w-full max-w-lg p-6 shadow-2xl space-y-4">
            <h3 className="font-display font-bold text-lg text-white">
              Create Community Discussion
            </h3>

            <form onSubmit={handleCreatePost} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Tactical insight for Titans vs Madrid..."
                  className="w-full h-10 px-3 rounded-xl bg-[#0c1830] border border-[#182f5c] text-white focus:outline-none focus:border-emerald-400"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Category</label>
                  <select
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value as any)}
                    className="w-full h-10 px-3 rounded-xl bg-[#0c1830] border border-[#182f5c] text-white focus:outline-none"
                  >
                    <option value="Tactics">Tactics</option>
                    <option value="Prediction">Prediction</option>
                    <option value="Discussion">Discussion</option>
                    <option value="Debate">Debate</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Link Fixture (Optional)</label>
                  <select
                    value={newMatchId}
                    onChange={(e) => setNewMatchId(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl bg-[#0c1830] border border-[#182f5c] text-white focus:outline-none"
                  >
                    <option value="">None (General)</option>
                    {matches.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.homeTeam.code} vs {m.awayTeam.code}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Analysis & Thoughts</label>
                <textarea
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  rows={4}
                  placeholder="Share your reasoning, tactical statistics, or prediction advice..."
                  className="w-full p-3 rounded-xl bg-[#0c1830] border border-[#182f5c] text-white focus:outline-none focus:border-emerald-400"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewPostModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold"
                >
                  Publish Analysis
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* NEW CHALLENGE MODAL */}
      {showNewChallengeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#091326] border border-[#1b3464] rounded-3xl w-full max-w-lg p-6 shadow-2xl space-y-4">
            <h3 className="font-display font-bold text-lg text-white">
              Send 1v1 Prediction Duel
            </h3>

            <form onSubmit={handleSendChallenge} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Select Fixture</label>
                <select
                  value={chalMatchId}
                  onChange={(e) => setChalMatchId(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-[#0c1830] border border-[#182f5c] text-white focus:outline-none"
                >
                  {matches.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.homeTeam.name} vs {m.awayTeam.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Your Stated Pick</label>
                <input
                  type="text"
                  value={chalPick}
                  onChange={(e) => setChalPick(e.target.value)}
                  placeholder="e.g. London Titans to Win or Over 2.5 Goals"
                  className="w-full h-10 px-3 rounded-xl bg-[#0c1830] border border-[#182f5c] text-white focus:outline-none focus:border-emerald-400"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Virtual EP Stake</label>
                <input
                  type="number"
                  min="50"
                  max={user.points}
                  value={chalStake}
                  onChange={(e) => setChalStake(parseInt(e.target.value) || 50)}
                  className="w-full h-10 px-3 rounded-xl bg-[#0c1830] border border-[#182f5c] text-white font-mono font-bold focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewChallengeModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold"
                >
                  Send Challenge
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

function formatTimeAgo(timestamp: number): string {
  const diffSec = Math.floor((Date.now() - timestamp) / 1000);
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  return `${diffHours}h ago`;
}
