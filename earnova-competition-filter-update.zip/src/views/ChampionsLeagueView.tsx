import React, { useState } from 'react';
import { Trophy, Award, Shield, ChevronRight, Crown, Star, Flame } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { MatchCard } from '../components/MatchCard';
import { useTranslation } from '../utils/i18n';

export const ChampionsLeagueView: React.FC = () => {
  const { tournamentGroups, matches, leaderboard, user, language } = useEarnova();
  const { t } = useTranslation(language);
  const [activeTab, setActiveTab] = useState<'standings' | 'fixtures' | 'ranks' | 'badges'>('standings');

  const uclMatches = matches.filter((m) => m.leagueId === 'champions_cup');

  return (
    <div className="space-y-6 pb-12">
      {/* View Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0d1e3f] via-[#0b2b42] to-[#0a1833] border border-emerald-500/30 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-3xl shadow-xl shadow-emerald-950/40">
              🏆
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                <Crown className="w-4 h-4" />
                <span>SEASON 2026 · WEEKLY ROUND 4</span>
              </div>
              <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white mt-0.5">
                {t('championsLeague')}
              </h1>
              <p className="text-xs text-slate-300 mt-1">
                Compete in weekly continental gameweeks for virtual glory, rankings, and exclusive badges
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-[#081326]/80 p-3 rounded-2xl border border-[#162f5e] self-start sm:self-auto">
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Your Weekly UCL Score
              </span>
              <span className="font-mono font-black text-xl text-emerald-400 tabular-nums">
                2,800 pts
              </span>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30">
              Rank #5
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('standings')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'standings'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'bg-[#0c1830] text-slate-300 hover:text-white border border-[#162c57]'
          }`}
        >
          Group Standings
        </button>
        <button
          onClick={() => setActiveTab('fixtures')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'fixtures'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'bg-[#0c1830] text-slate-300 hover:text-white border border-[#162c57]'
          }`}
        >
          UCL Fixtures ({uclMatches.length})
        </button>
        <button
          onClick={() => setActiveTab('ranks')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'ranks'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'bg-[#0c1830] text-slate-300 hover:text-white border border-[#162c57]'
          }`}
        >
          Weekly Leaderboard
        </button>
        <button
          onClick={() => setActiveTab('badges')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'badges'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'bg-[#0c1830] text-slate-300 hover:text-white border border-[#162c57]'
          }`}
        >
          Tournament Badges
        </button>
      </div>

      {/* Content */}
      {activeTab === 'standings' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {tournamentGroups.map((group, idx) => (
            <div
              key={idx}
              className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3"
            >
              <div className="flex items-center justify-between border-b border-[#14264b] pb-2 text-xs">
                <h3 className="font-display font-bold text-sm text-white">
                  {group.groupName}
                </h3>
                <span className="text-emerald-400 font-medium">Gameweek 4 of 6</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="text-slate-400 border-b border-[#14264a] text-[11px]">
                      <th className="pb-2 font-medium">Club</th>
                      <th className="pb-2 font-mono text-center">P</th>
                      <th className="pb-2 font-mono text-center">W</th>
                      <th className="pb-2 font-mono text-center">D</th>
                      <th className="pb-2 font-mono text-center">L</th>
                      <th className="pb-2 font-mono text-center">GD</th>
                      <th className="pb-2 font-mono text-right font-bold text-emerald-400">PTS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#14264a]">
                    {group.standings.map((row, pos) => (
                      <tr key={row.team.id} className="hover:bg-[#102040]/50 transition-colors">
                        <td className="py-2.5 flex items-center gap-2 font-semibold text-white">
                          <span className="font-mono text-slate-400 text-[10px] w-3">{pos + 1}</span>
                          <span>{row.team.crestIcon}</span>
                          <span className="truncate">{row.team.shortName}</span>
                        </td>
                        <td className="py-2.5 font-mono text-center tabular-nums text-slate-300">{row.played}</td>
                        <td className="py-2.5 font-mono text-center tabular-nums text-slate-300">{row.won}</td>
                        <td className="py-2.5 font-mono text-center tabular-nums text-slate-300">{row.drawn}</td>
                        <td className="py-2.5 font-mono text-center tabular-nums text-slate-300">{row.lost}</td>
                        <td className="py-2.5 font-mono text-center tabular-nums text-slate-300">
                          {row.goalsFor - row.goalsAgainst > 0 ? `+${row.goalsFor - row.goalsAgainst}` : row.goalsFor - row.goalsAgainst}
                        </td>
                        <td className="py-2.5 font-mono text-right font-bold tabular-nums text-emerald-400">
                          {row.points}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'fixtures' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {uclMatches.map((m) => (
            <MatchCard key={m.id} match={m} featured={m.isFeatured} />
          ))}
        </div>
      )}

      {activeTab === 'ranks' && (
        <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-4">
          <div className="flex items-center justify-between border-b border-[#14264b] pb-2 text-xs">
            <h3 className="font-display font-bold text-sm text-white">
              Weekly Tournament Leaderboard
            </h3>
            <span className="text-slate-400">Ends in 2 Days, 14 Hours</span>
          </div>

          <div className="divide-y divide-[#14264a]">
            {leaderboard.map((item) => (
              <div
                key={item.rank}
                className="py-3 flex items-center justify-between gap-3 text-xs hover:bg-[#102040]/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="font-mono font-bold text-slate-400 w-5 tabular-nums">#{item.rank}</span>
                  <span className="text-xl">{item.avatar}</span>
                  <div>
                    <h4 className="font-semibold text-white">{item.username}</h4>
                    <span className="text-[10px] text-slate-400">{item.tier}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono font-bold text-sm text-emerald-400 tabular-nums">
                    {item.weeklyPoints || Math.round(item.points * 0.12)} pts
                  </span>
                  <span className="text-[10px] text-slate-400 block">{item.winRate}% win rate</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'badges' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <BadgeCard
            icon="🏆"
            title="UCL Oracle"
            description="Score over 1,000 points in a single weekly round"
            unlocked={true}
          />
          <BadgeCard
            icon="⭐"
            title="Group Stage Master"
            description="Correctly predict 5 group stage winners"
            unlocked={true}
          />
          <BadgeCard
            icon="🛡️"
            title="Clean Sheet Tactician"
            description="Predict 3 Under 2.5 goal matches in UCL fixtures"
            unlocked={true}
          />
          <BadgeCard
            icon="👑"
            title="Continental Finalist"
            description="Finish in the weekly top 10 leaderboard"
            unlocked={false}
            progress="Rank #42 / Top 10"
          />
          <BadgeCard
            icon="⚡"
            title="Underdog Specialist"
            description="Win a prediction with odds greater than 3.50x in UCL"
            unlocked={false}
            progress="Best odd: 2.45x"
          />
          <BadgeCard
            icon="🎯"
            title="Grand Slam Accumulator"
            description="Hit a 4-leg UCL accumulator slip"
            unlocked={false}
            progress="0 / 1 Slip"
          />
        </div>
      )}
    </div>
  );
};

function BadgeCard({
  icon,
  title,
  description,
  unlocked,
  progress,
}: {
  icon: string;
  title: string;
  description: string;
  unlocked: boolean;
  progress?: string;
}) {
  return (
    <div
      className={`p-4 rounded-2xl border flex items-start gap-3 ${
        unlocked
          ? 'bg-[#0e2144] border-emerald-500/40 shadow-md'
          : 'bg-[#091326]/60 border-[#14264b] opacity-60'
      }`}
    >
      <span className="text-3xl p-2 rounded-xl bg-[#091326] shrink-0">{icon}</span>
      <div className="min-w-0">
        <h4 className="font-semibold text-xs text-white">{title}</h4>
        <p className="text-[11px] text-slate-300 mt-1 leading-snug">{description}</p>
        {unlocked ? (
          <span className="text-[10px] text-emerald-400 font-semibold block mt-1">
            ✓ Earned & Active
          </span>
        ) : (
          <span className="text-[10px] text-amber-400 font-mono block mt-1">
            {progress || 'Locked'}
          </span>
        )}
      </div>
    </div>
  );
}
