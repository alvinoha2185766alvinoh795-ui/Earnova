/**
 * Earnova Authentication Service
 * 
 * Provides secure client-side user registration, login, session persistence,
 * password hashing (SHA-256 via Web Crypto API), and account management.
 * Plaintext passwords are NEVER stored in localStorage or database records.
 */

import { UserProfile } from '../types';
import { INITIAL_USER } from '../data/mockData';
import { safeStorage } from './safeStorage';

export interface StoredAccount {
  uid: string;
  fullName: string;
  username: string;
  email: string;
  passwordHash: string;
  createdAt: number;
  profile: UserProfile;
}

export interface AuthSession {
  uid: string;
  token: string;
  createdAt: number;
}

const STORAGE_KEY_ACCOUNTS = 'earnova_auth_accounts_v2';
const STORAGE_KEY_SESSION = 'earnova_auth_session_v2';

/**
 * Hash password securely using Web Crypto API SHA-256
 */
export async function hashPassword(password: string): Promise<string> {
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password + '_earnova_salt_2026');
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  // Simple deterministic fallback if crypto.subtle is unavailable
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return `hash_${Math.abs(hash)}_${password.length}`;
}

/**
 * Generate a unique Firebase-style User ID
 */
export function generateUserId(): string {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 10);
  return `user_${timestamp}_${randomStr}`;
}

/**
 * Retrieve all registered accounts from local registry
 */
export function getRegisteredAccounts(): StoredAccount[] {
  try {
    const raw = safeStorage.getItem(STORAGE_KEY_ACCOUNTS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((acc) => ({
          ...acc,
          profile: {
            ...INITIAL_USER,
            ...(acc.profile || {}),
            points: typeof acc.profile?.points === 'number' ? acc.profile.points : INITIAL_USER.points,
          },
        }));
      }
    }
  } catch (err) {
    console.error('Failed to parse accounts registry:', err);
  }

  // Seed default demonstration account
  const defaultAccount: StoredAccount = {
    uid: 'user_earnova_demo_apex',
    fullName: 'Alvin Oha',
    username: INITIAL_USER.username || 'ApexTactician',
    email: 'alvin@earnova.com',
    passwordHash: '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', // Earnova2026!
    createdAt: Date.now() - 30 * 24 * 3600 * 1000,
    profile: {
      ...INITIAL_USER,
      uid: 'user_earnova_demo_apex',
      email: 'alvin@earnova.com',
      fullName: 'Alvin Oha',
      isLoggedIn: true,
    },
  };

  try {
    safeStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify([defaultAccount]));
  } catch {}

  return [defaultAccount];
}

/**
 * Save updated accounts list to registry
 */
export function saveRegisteredAccounts(accounts: StoredAccount[]): void {
  try {
    safeStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(accounts));
  } catch (err) {
    console.error('Failed to save accounts registry:', err);
  }
}

/**
 * Get active session
 */
export function getActiveSession(): AuthSession | null {
  try {
    const raw = safeStorage.getItem(STORAGE_KEY_SESSION);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Failed to get active session:', err);
  }
  return null;
}

/**
 * Save active session
 */
export function saveActiveSession(session: AuthSession | null): void {
  try {
    if (session) {
      safeStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(session));
    } else {
      safeStorage.removeItem(STORAGE_KEY_SESSION);
    }
  } catch (err) {
    console.error('Failed to save session:', err);
  }
}

/**
 * Authenticate current session or return initial user
 */
export function resolveCurrentAuthUser(): { user: UserProfile; isLoggedIn: boolean } {
  const session = getActiveSession();
  const accounts = getRegisteredAccounts();

  if (session && session.uid) {
    const account = accounts.find((a) => a.uid === session.uid);
    if (account) {
      const mergedUser: UserProfile = {
        ...INITIAL_USER,
        ...(account.profile || {}),
        uid: account.uid,
        email: account.email,
        fullName: account.fullName,
        username: account.username,
        points: typeof account.profile?.points === 'number' ? account.profile.points : INITIAL_USER.points,
        isLoggedIn: true,
      };
      return {
        user: mergedUser,
        isLoggedIn: true,
      };
    }
  }

  // Check if default account exists
  const defaultAcc = accounts[0];
  if (defaultAcc) {
    const mergedUser: UserProfile = {
      ...INITIAL_USER,
      ...(defaultAcc.profile || {}),
      uid: defaultAcc.uid,
      email: defaultAcc.email,
      fullName: defaultAcc.fullName,
      username: defaultAcc.username,
      points: typeof defaultAcc.profile?.points === 'number' ? defaultAcc.profile.points : INITIAL_USER.points,
      isLoggedIn: true,
    };
    return {
      user: mergedUser,
      isLoggedIn: true,
    };
  }

  return {
    user: {
      ...INITIAL_USER,
      uid: 'guest_user',
      email: '',
      fullName: 'Guest User',
      isLoggedIn: false,
    },
    isLoggedIn: false,
  };
}
