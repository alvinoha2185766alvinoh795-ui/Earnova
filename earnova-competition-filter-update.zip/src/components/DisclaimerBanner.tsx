import React, { useState } from 'react';
import { ShieldAlert, X } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

export const DisclaimerBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState(false);
  const { language } = useEarnova();
  const { t } = useTranslation(language);

  if (dismissed) return null;

  return (
    <div className="bg-[#0b182d] border-b border-emerald-950/60 px-4 py-2 text-xs text-slate-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-hidden">
          <ShieldAlert className="w-4 h-4 text-emerald-400 shrink-0" />
          <p className="truncate">
            <strong className="text-emerald-400 font-semibold mr-1.5">{t('disclaimerTitle')}:</strong>
            {t('disclaimerText')}
          </p>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-slate-400 hover:text-white p-1 rounded-md transition-colors shrink-0"
          aria-label="Dismiss disclaimer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
