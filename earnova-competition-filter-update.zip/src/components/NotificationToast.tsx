import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Goal, Award, Flag, X, ArrowRight } from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';

export const NotificationToast: React.FC = () => {
  const { activeToast, dismissToast, setSelectedMatchDetail, matches } = useEarnova();

  if (!activeToast) return null;

  const handleOpenMatch = () => {
    if (activeToast.matchId) {
      const match = matches.find((m) => m.id === activeToast.matchId);
      if (match) {
        setSelectedMatchDetail(match);
      }
    }
    dismissToast();
  };

  const getIcon = () => {
    switch (activeToast.type) {
      case 'goal':
        return <Goal className="w-5 h-5 text-emerald-400 shrink-0" />;
      case 'prediction_settled':
      case 'daily_bonus':
        return <Award className="w-5 h-5 text-amber-400 shrink-0" />;
      default:
        return <Flag className="w-5 h-5 text-sky-400 shrink-0" />;
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.95 }}
        transition={{ duration: 0.2 }}
        className="fixed top-18 right-4 left-4 sm:left-auto sm:right-6 sm:w-96 z-50 pointer-events-auto"
      >
        <div className="bg-[#0b162f] border border-emerald-500/40 rounded-xl p-3.5 shadow-2xl shadow-emerald-950/40 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-[#112347] border border-[#1b3464]">
            {getIcon()}
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-semibold text-white truncate">
              {activeToast.title}
            </h4>
            <p className="text-xs text-slate-300 mt-0.5 line-clamp-2">
              {activeToast.message}
            </p>
            {activeToast.matchId && (
              <button
                onClick={handleOpenMatch}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 mt-2 transition-colors cursor-pointer"
              >
                <span>View Live Tracker</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>
          <button
            onClick={dismissToast}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
            aria-label="Dismiss alert"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
