import React, { useState } from 'react';
import {
  Activity,
  Play,
  FastForward,
  Goal,
  Shield,
  Zap,
  Target,
  BarChart3,
  SlidersHorizontal,
  Flame,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { Match } from '../types';
import { useTranslation } from '../utils/i18n';

export const LiveCenterView: React.FC = () => {
  const {
    matches,
    simulateLiveStep,
    fastForwardMatch,
    setSelectedMarketsMatch,
    setSelectedIntelligenceMatch,
    language,
    lowDataMode,
  } = useEarnova();
  const { t } = useTranslation(language);

  const liveMatches = matches.filter((m) => m.status === 'live');
  const availableMatches = liveMatches.length > 0 ? liveMatches : matches.filter((m) => m.status !== 'finished');

  const [activeMatchId, setActiveMatchId] = useState<string>(availableMatches[0]?.id || matches[0]?.id);

  const currentMatch = matches.find((m) => m.id === activeMatchId) || matches[0];

  if (!currentMatch) return null;

  const isLive = currentMatch.status === 'live';
  const homePoss = currentMatch.stats.possession[0];
  const awayPoss = currentMatch.stats.possession[1];

  return (
    <div className="space-y-6 pb-12">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
              {t('liveCentre')}
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time simulated match tracker, animated momentum pitch, and live event feed
          </p>
        </div>

        {/* Fixture Selector Carousel / Dropdown */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full">
          {matches.map((m) => {
            const isActive = m.id === currentMatch.id;
            return (
              <button
                key={m.id}
                onClick={() => setActiveMatchId(m.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                    : 'bg-[#0d1c3a] text-slate-300 hover:text-white border border-[#162e5c]'
                }`}
              >
                <span>{m.homeTeam.code} vs {m.awayTeam.code}</span>
                {m.status === 'live' && (
                  <span className="ml-1.5 text-[10px] text-slate-950 bg-emerald-300 px-1.5 py-0.2 rounded font-mono font-bold">
                    {m.minute}&apos;
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Live Scoreboard Card */}
      <div className="p-5 sm:p-7 rounded-3xl bg-gradient-to-b from-[#0e1d3d] to-[#091326] border border-[#183161] shadow-2xl relative overflow-hidden">
        {/* Top Status */}
        <div className="flex items-center justify-between border-b border-[#162c57] pb-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">{currentMatch.leagueName}</span>
            <span aria-hidden="true">·</span>
            <span>{currentMatch.homeTeam.stadium}</span>
          </div>

          <div className="flex items-center gap-2">
            {isLive ? (
              <span className="flex items-center gap-1.5 text-emerald-400 font-bold font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {currentMatch.minute}&apos; LIVE
              </span>
            ) : currentMatch.status === 'finished' ? (
              <span className="text-slate-400 font-semibold">Full Time</span>
            ) : (
              <span className="text-emerald-400 font-medium">{currentMatch.startTime}</span>
            )}
          </div>
        </div>

        {/* Teams & Scores */}
        <div className="py-6 grid grid-cols-[1fr_auto_1fr] items-center gap-4">
          {/* Home Team */}
          <div className="flex flex-col items-center text-center">
            <div
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center text-3xl sm:text-4xl border border-white/10 shadow-lg mb-2"
              style={{ backgroundColor: currentMatch.homeTeam.crestBg }}
            >
              {currentMatch.homeTeam.crestIcon}
            </div>
            <h3 className="font-display font-extrabold text-base sm:text-lg text-white">
              {currentMatch.homeTeam.name}
            </h3>
            <span className="text-xs text-slate-400">{currentMatch.homeTeam.city}</span>
          </div>

          {/* Big Score Counter */}
          <div className="flex flex-col items-center px-2">
            <div className="font-mono font-black text-4xl sm:text-6xl text-white tracking-widest tabular-nums">
              <span className={currentMatch.homeScore > currentMatch.awayScore ? 'text-emerald-400' : 'text-white'}>
                {currentMatch.homeScore}
              </span>
              <span className="text-slate-500 mx-2 text-3xl sm:text-4xl">-</span>
              <span className={currentMatch.awayScore > currentMatch.homeScore ? 'text-emerald-400' : 'text-white'}>
                {currentMatch.awayScore}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono mt-1">
              xG {currentMatch.stats.xG[0].toFixed(2)} - {currentMatch.stats.xG[1].toFixed(2)}
            </span>
          </div>

          {/* Away Team */}
          <div className="flex flex-col items-center text-center">
            <div
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center text-3xl sm:text-4xl border border-white/10 shadow-lg mb-2"
              style={{ backgroundColor: currentMatch.awayTeam.crestBg }}
            >
              {currentMatch.awayTeam.crestIcon}
            </div>
            <h3 className="font-display font-extrabold text-base sm:text-lg text-white">
              {currentMatch.awayTeam.name}
            </h3>
            <span className="text-xs text-slate-400">{currentMatch.awayTeam.city}</span>
          </div>
        </div>

        {/* Live Simulation Controls Bar */}
        <div className="pt-4 border-t border-[#162c57] flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => simulateLiveStep(currentMatch.id)}
              disabled={currentMatch.status === 'finished'}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#12244a] hover:bg-[#1a3366] disabled:opacity-40 text-slate-200 border border-[#1b376e] transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t('advanceMatch')}</span>
            </button>
            <button
              onClick={() => fastForwardMatch(currentMatch.id)}
              disabled={currentMatch.status === 'finished'}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 disabled:opacity-40 text-emerald-300 border border-emerald-500/40 transition-colors cursor-pointer"
            >
              <FastForward className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t('simulateToFT')}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedIntelligenceMatch(currentMatch)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0f2145] hover:bg-[#163166] text-emerald-300 border border-emerald-500/30 transition-colors cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              <span>AI Intelligence Dossier</span>
            </button>
            <button
              onClick={() => setSelectedMarketsMatch(currentMatch)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-colors cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{t('moreMarkets')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2D Pitch Momentum Radar (Simplified if Low-Data Mode is ON) */}
      {!lowDataMode && (
        <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 font-semibold text-white">
              <Activity className="w-4 h-4 text-emerald-400" />
              <span>{t('pitchRadar')}</span>
            </div>
            <span className="text-slate-400">
              Active Attack Zone: {homePoss > 50 ? `${currentMatch.homeTeam.code} Attacking 3rd` : `${currentMatch.awayTeam.code} Attacking 3rd`}
            </span>
          </div>

          {/* Football Field Visualizer */}
          <div className="h-28 rounded-2xl bg-gradient-to-r from-[#06331e] via-[#09472b] to-[#06331e] border-2 border-emerald-700/50 relative overflow-hidden flex items-center justify-between px-6 shadow-inner">
            {/* Center circle */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full border-2 border-emerald-400/30" />
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-emerald-400/30" />

            {/* Left penalty box */}
            <div className="w-14 h-20 border-2 border-emerald-400/30 border-l-0 rounded-r-lg" />

            {/* Simulated Live Ball with glow */}
            <div
              className="absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white shadow-[0_0_12px_#34d399] transition-all duration-700"
              style={{
                left: `${Math.min(88, Math.max(12, homePoss + (Math.sin(currentMatch.minute) * 15)))}%`,
              }}
            />

            {/* Right penalty box */}
            <div className="w-14 h-20 border-2 border-emerald-400/30 border-r-0 rounded-l-lg" />
          </div>
        </div>
      )}

      {/* 2-Column Grid: Timeline & Tactical Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Match Timeline */}
        <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-3">
          <div className="flex items-center justify-between border-b border-[#14264b] pb-2 text-xs">
            <h3 className="font-display font-bold text-sm text-white">
              {t('matchTimeline')}
            </h3>
            <span className="text-slate-400 font-mono">
              {currentMatch.events.length} Events Logged
            </span>
          </div>

          <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
            {currentMatch.events.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                No key events recorded yet. Click &ldquo;Advance +8 Min&rdquo; above to simulate game action.
              </div>
            ) : (
              currentMatch.events.map((ev) => (
                <div
                  key={ev.id}
                  className="p-3 rounded-xl bg-[#0f2040] border border-[#162b54] flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono font-bold text-emerald-400 tabular-nums w-8">
                      {ev.minute}&apos;
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5 font-semibold text-white">
                        {ev.type === 'goal' && <Goal className="w-4 h-4 text-emerald-400" />}
                        {ev.type === 'yellow_card' && <div className="w-2.5 h-3.5 bg-amber-400 rounded-xs" />}
                        {ev.type === 'red_card' && <div className="w-2.5 h-3.5 bg-rose-500 rounded-xs" />}
                        <span>{ev.player}</span>
                      </div>
                      {ev.detail && <p className="text-[11px] text-slate-400 mt-0.5">{ev.detail}</p>}
                    </div>
                  </div>
                  <span className="font-semibold text-slate-400 text-[11px]">
                    {ev.teamId === currentMatch.homeTeam.id ? currentMatch.homeTeam.code : currentMatch.awayTeam.code}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Detailed Tactical Stats */}
        <div className="p-5 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-4">
          <div className="flex items-center justify-between border-b border-[#14264b] pb-2 text-xs">
            <h3 className="font-display font-bold text-sm text-white">
              {t('tacticalStats')}
            </h3>
            <span className="text-slate-400 font-mono">
              Live Verified
            </span>
          </div>

          {/* Possession bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
              <span className="font-mono text-emerald-400 tabular-nums">{homePoss}%</span>
              <span className="text-slate-400">{t('possession')}</span>
              <span className="font-mono text-sky-400 tabular-nums">{awayPoss}%</span>
            </div>
            <div className="h-2 rounded-full bg-[#112347] overflow-hidden flex">
              <div className="bg-emerald-500 transition-all duration-300" style={{ width: `${homePoss}%` }} />
              <div className="bg-sky-500 transition-all duration-300" style={{ width: `${awayPoss}%` }} />
            </div>
          </div>

          <div className="space-y-2 text-xs pt-1">
            <StatRow
              label={t('shotsOnTarget')}
              home={currentMatch.stats.shotsOnTarget[0]}
              away={currentMatch.stats.shotsOnTarget[1]}
            />
            <StatRow
              label="Total Shots"
              home={currentMatch.stats.totalShots[0]}
              away={currentMatch.stats.totalShots[1]}
            />
            <StatRow
              label={t('expectedGoals')}
              home={currentMatch.stats.xG[0].toFixed(2)}
              away={currentMatch.stats.xG[1].toFixed(2)}
            />
            <StatRow
              label={t('dangerousAttacks')}
              home={currentMatch.stats.dangerousAttacks[0]}
              away={currentMatch.stats.dangerousAttacks[1]}
            />
            <StatRow
              label="Corners"
              home={currentMatch.stats.corners[0]}
              away={currentMatch.stats.corners[1]}
            />
            <StatRow
              label="Fouls"
              home={currentMatch.stats.fouls[0]}
              away={currentMatch.stats.fouls[1]}
            />
            {currentMatch.stats.passesCompleted && (
              <StatRow
                label={t('passesCompleted')}
                home={currentMatch.stats.passesCompleted[0]}
                away={currentMatch.stats.passesCompleted[1]}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

function StatRow({ label, home, away }: { label: string; home: number | string; away: number | string }) {
  return (
    <div className="flex items-center justify-between text-xs py-2 px-3 rounded-xl bg-[#0e1d3b] border border-[#162c57]">
      <span className="font-mono font-bold text-white tabular-nums">{home}</span>
      <span className="text-slate-400">{label}</span>
      <span className="font-mono font-bold text-white tabular-nums">{away}</span>
    </div>
  );
}
