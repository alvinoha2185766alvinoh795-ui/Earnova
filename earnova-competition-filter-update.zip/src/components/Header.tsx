import React from 'react';
import {
  Bell,
  Coins,
  Ticket,
  Globe,
  Wifi,
  WifiOff,
  Star,
  Menu,
  Wallet,
  Settings,
  ArrowDownLeft,
  ArrowUpRight,
  Plane,
  LogIn,
  LogOut,
  User,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenFavorites: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, onSelectTab, onOpenFavorites }) => {
  const {
    user,
    slip,
    notifications,
    setIsSlipOpen,
    isNotificationCenterOpen,
    setIsNotificationCenterOpen,
    setIsNavDrawerOpen,
    language,
    setLanguage,
    lowDataMode,
    toggleLowDataMode,
    openAuthModal,
    logoutUser,
  } = useEarnova();
  const { t } = useTranslation(language);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-30 bg-[#070d18]/95 backdrop-blur-md border-b border-[#162548]">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3 sm:gap-6">
        {/* Zone 1: Brand Title & Menu Trigger */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => setIsNavDrawerOpen(true)}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-[#0e1933] transition-colors cursor-pointer touch-manipulation"
            aria-label="Open Navigation Menu"
            title="Open EARNOVA Menu"
          >
            <Menu className="w-5 h-5 text-emerald-400" />
          </button>

          <button
            type="button"
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2 text-left focus:outline-none group cursor-pointer shrink-0 touch-manipulation"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center font-bold text-slate-950 text-base shadow-sm group-hover:brightness-110 transition-all">
              E
            </div>
            <span className="font-display font-extrabold text-lg sm:text-xl tracking-tight text-white group-hover:text-emerald-400 transition-colors">
              EARNOVA
            </span>
          </button>
        </div>

        {/* Zone 2: Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-3 xl:gap-4 text-xs xl:text-sm font-medium text-slate-300">
          <button
            type="button"
            onClick={() => onSelectTab('home')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'home'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('dashboard')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('wallet')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer flex items-center gap-1 ${
              currentTab === 'wallet'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>{t('wallet')}</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('matches')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'matches'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('fixtures')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('live')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer flex items-center gap-1.5 ${
              currentTab === 'live'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>{t('liveCentre')}</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('novaplay')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer flex items-center gap-1.5 ${
              currentTab === 'novaplay'
                ? 'text-amber-400 font-bold border-b-2 border-amber-400'
                : 'text-amber-300 hover:text-white'
            }`}
          >
            <Plane className="w-3.5 h-3.5 transform -rotate-45 text-amber-400" />
            <span className="font-extrabold tracking-tight">NovaPlay</span>
            <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/40">
              AVIATOR
            </span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('leaderboard')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'leaderboard'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('ranks')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('ucl')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'ucl'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('championsLeague')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('community')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'community'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('community')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('academy')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'academy'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('academy')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('performance')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'performance'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('performance')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('trivia')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'trivia'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('trivia')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('profile')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer ${
              currentTab === 'profile'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            {t('profile')}
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('deposit')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer flex items-center gap-1 ${
              currentTab === 'deposit'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            <ArrowDownLeft className="w-3.5 h-3.5" />
            <span>Deposit</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('withdraw')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer flex items-center gap-1 ${
              currentTab === 'withdraw'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Withdraw</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('settings')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer flex items-center gap-1 ${
              currentTab === 'settings'
                ? 'text-emerald-400 font-semibold border-b-2 border-emerald-400'
                : 'hover:text-white'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Settings</span>
          </button>
        </nav>

        {/* Zone 3: Control Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Smart Low-Data Mode Toggle */}
          <button
            type="button"
            onClick={toggleLowDataMode}
            title={lowDataMode ? 'Smart Low-Data Mode is ON' : 'Toggle Smart Low-Data Mode'}
            className={`p-2 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer touch-manipulation ${
              lowDataMode
                ? 'bg-amber-950/70 border-amber-500/50 text-amber-300'
                : 'bg-[#0e1933] border-[#1e3461] text-slate-400 hover:text-white'
            }`}
            aria-label="Toggle Low Data Mode"
          >
            {lowDataMode ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
            <span className="hidden xl:inline text-[11px]">
              {lowDataMode ? 'Low-Data' : 'Saver'}
            </span>
          </button>

          {/* Language Switcher (EN / SW) */}
          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'sw' : 'en')}
            className="px-2 py-1.5 rounded-lg bg-[#0e1933] border border-[#1e3461] text-xs font-bold text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer touch-manipulation"
            title="Switch Language / Badili Lugha"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-mono uppercase text-[11px]">{language}</span>
          </button>

          {/* Top Settings Icon Button */}
          <button
            type="button"
            onClick={() => onSelectTab('settings')}
            className={`p-2 rounded-lg border transition-all cursor-pointer touch-manipulation ${
              currentTab === 'settings'
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 ring-1 ring-emerald-400'
                : 'bg-[#0e1933] border-[#1e3461] text-slate-300 hover:text-white'
            }`}
            title="Settings & Audio Volume"
            aria-label="Open Settings"
          >
            <Settings className="w-4 h-4 text-emerald-400" />
          </button>

          {/* Favorite Teams Trigger */}
          <button
            type="button"
            onClick={onOpenFavorites}
            className="p-2 rounded-lg bg-[#0e1933] border border-[#1e3461] text-slate-300 hover:text-amber-400 transition-colors cursor-pointer touch-manipulation"
            title="Favorite Teams & Notifications"
            aria-label="Favorite Teams"
          >
            <Star className="w-4 h-4" />
          </button>

          {/* NovaPlay Aviator Header Quick Action */}
          <button
            type="button"
            onClick={() => onSelectTab('novaplay')}
            className={`px-2 sm:px-2.5 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1 transition-all cursor-pointer touch-manipulation shadow-sm active:scale-95 ${
              currentTab === 'novaplay'
                ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-300'
                : 'bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-400/40 text-amber-300 hover:text-white'
            }`}
            title="Open NovaPlay Aviator Games"
          >
            <Plane className="w-3.5 h-3.5 transform -rotate-45 text-amber-400" />
            <span className="text-[11px] font-black uppercase">NovaPlay</span>
          </button>

          {/* Quick Demo Deposit Button */}
          <button
            type="button"
            onClick={() => onSelectTab('deposit')}
            className={`px-2.5 sm:px-3 py-1.5 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center gap-1 transition-all cursor-pointer touch-manipulation shadow-sm active:scale-95 ${
              currentTab === 'deposit'
                ? 'bg-emerald-400 text-slate-950 ring-2 ring-emerald-300'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
            }`}
            title="Open Demo Deposit Center"
          >
            <ArrowDownLeft className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="hidden xs:inline text-[11px]">Deposit</span>
          </button>

          {/* Virtual Points Counter (Click to open Wallet) */}
          <button
            type="button"
            onClick={() => onSelectTab('wallet')}
            className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer group touch-manipulation ${
              currentTab === 'wallet'
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                : 'bg-[#0e1933] hover:bg-[#132448] border-[#1e3461] hover:border-emerald-500/50 text-emerald-400'
            }`}
            title="Open Virtual Wallet & Activity"
            aria-label="Open Virtual Wallet"
          >
            <Coins className="w-3.5 h-3.5 text-emerald-400 shrink-0 group-hover:scale-110 transition-transform" />
            <div className="flex items-baseline gap-1">
              <span className="font-mono font-bold text-xs sm:text-sm tracking-tight text-white tabular-nums">
                {(user?.points ?? 0).toLocaleString()}
              </span>
              <span className="text-[10px] font-semibold text-emerald-400">EP</span>
            </div>
          </button>

          {/* User Auth Action (Sign In / User Profile & Logout) */}
          {user.isLoggedIn !== false && user.email ? (
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onSelectTab('profile')}
                className={`p-1 sm:px-2 sm:py-1 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                  currentTab === 'profile'
                    ? 'bg-yellow-400/20 border-yellow-400 text-yellow-300'
                    : 'bg-[#0e1933] hover:bg-[#132448] border-[#1e3461] text-slate-200'
                }`}
                title={`Signed in as ${user.fullName || user.username} (@${user.username})`}
              >
                <span className="w-5 h-5 rounded-full bg-[#132752] border border-emerald-400/50 flex items-center justify-center text-xs">
                  {user.avatar || '⚡'}
                </span>
                <span className="hidden lg:inline text-[11px] font-bold truncate max-w-[80px]">
                  {user.username}
                </span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Are you sure you want to log out of your Earnova account?')) {
                    logoutUser();
                  }
                }}
                className="p-2 rounded-lg bg-[#0e1933] hover:bg-rose-950/40 border border-[#1e3461] hover:border-rose-500/50 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                title="Log Out of Earnova"
                aria-label="Log Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => openAuthModal('login')}
              className="px-2 sm:px-3 py-1.5 rounded-lg bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer shadow-sm active:scale-95"
              title="Sign In or Register"
            >
              <LogIn className="w-3.5 h-3.5 stroke-[2.5]" />
              <span className="text-[11px] font-black uppercase">Sign In</span>
            </button>
          )}

          {/* Notifications Bell */}
          <button
            type="button"
            onClick={() => setIsNotificationCenterOpen(!isNotificationCenterOpen)}
            className="relative p-2 rounded-lg text-slate-300 hover:text-white hover:bg-[#121f3d] transition-colors cursor-pointer touch-manipulation"
            aria-label="Match Notifications"
          >
            <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-[#070d18]" />
            )}
          </button>

          {/* Quick Slip Toggle */}
          <button
            type="button"
            onClick={() => setIsSlipOpen(true)}
            className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs tracking-wide transition-all shadow-sm active:scale-95 cursor-pointer touch-manipulation"
          >
            <Ticket className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">SLIP</span>
            {slip.length > 0 && (
              <span className="flex items-center justify-center w-4 h-4 rounded-full bg-slate-950 text-emerald-300 text-[10px] font-mono font-bold">
                {slip.length}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
