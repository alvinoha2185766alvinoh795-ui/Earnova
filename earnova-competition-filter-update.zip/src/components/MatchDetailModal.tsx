import React, { useState } from 'react';
import { X, Play, FastForward, Activity, BarChart2, Shield, Goal } from 'lucide-react';
import { Match } from '../types';
import { useEarnova } from '../context/EarnovaContext';

interface MatchDetailModalProps {
  match: Match;
  onClose: () => void;
}

export const MatchDetailModal: React.FC<MatchDetailModalProps> = ({ match, onClose }) => {
  const { simulateLiveStep, fastForwardMatch } = useEarnova();
  const [detailTab, setDetailTab] = useState<'timeline' | 'stats' | 'info'>('timeline');

  const isLive = match.status === 'live';
  const isFinished = match.status === 'finished';

  const homePoss = match.stats.possession[0];
  const awayPoss = match.stats.possession[1];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#091326] border border-[#182f5c] rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="p-4 border-b border-[#14264a] flex items-center justify-between bg-[#060c18]">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-medium text-slate-300">{match.leagueName}</span>
            <span aria-hidden="true">·</span>
            <span>{match.leagueCountry}</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-[#122245] transition-colors"
            aria-label="Close match detail"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Big Match Scoreboard Banner */}
        <div className="p-5 sm:p-6 bg-gradient-to-b from-[#0b1730] to-[#081122] border-b border-[#14264a]">
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4">
            {/* Home Team */}
            <div className="flex flex-col items-center text-center">
              <div
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl border border-white/10 shadow-lg mb-2"
                style={{ backgroundColor: match.homeTeam.crestBg }}
              >
                {match.homeTeam.crestIcon}
              </div>
              <h3 className="font-display font-bold text-sm sm:text-base text-white">
                {match.homeTeam.name}
              </h3>
              <span className="text-[11px] text-slate-400">Home</span>
            </div>

            {/* Score & Time Status */}
            <div className="flex flex-col items-center px-2">
              {isLive ? (
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full mb-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-mono tabular-nums">{match.minute}&apos; LIVE</span>
                </div>
              ) : isFinished ? (
                <span className="text-xs font-semibold text-slate-400 bg-[#122347] px-3 py-1 rounded-full mb-2">
                  Full Time
                </span>
              ) : (
                <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1 rounded-full mb-2">
                  {match.startTime}
                </span>
              )}

              <div className="font-mono font-black text-3xl sm:text-4xl text-white tracking-widest tabular-nums">
                {match.homeScore} - {match.awayScore}
              </div>

              <span className="text-[11px] text-slate-400 mt-1 truncate">
                {match.homeTeam.stadium}
              </span>
            </div>

            {/* Away Team */}
            <div className="flex flex-col items-center text-center">
              <div
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl border border-white/10 shadow-lg mb-2"
                style={{ backgroundColor: match.awayTeam.crestBg }}
              >
                {match.awayTeam.crestIcon}
              </div>
              <h3 className="font-display font-bold text-sm sm:text-base text-white">
                {match.awayTeam.name}
              </h3>
              <span className="text-[11px] text-slate-400">Away</span>
            </div>
          </div>

          {/* Interactive Simulation Controls (For easy demo testing) */}
          <div className="mt-5 pt-4 border-t border-[#16274b] flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs text-slate-400">
              Simulation Controls:
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => simulateLiveStep(match.id)}
                disabled={isFinished}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#132549] hover:bg-[#1a3363] disabled:opacity-40 text-xs font-medium text-slate-200 border border-[#1f3b72] transition-colors cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 text-emerald-400" />
                <span>Advance +8 Min</span>
              </button>
              <button
                onClick={() => fastForwardMatch(match.id)}
                disabled={isFinished}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 disabled:opacity-40 text-xs font-semibold text-emerald-300 border border-emerald-500/40 transition-colors cursor-pointer"
              >
                <FastForward className="w-3.5 h-3.5 text-emerald-400" />
                <span>Simulate to FT</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tab Controls (Timeline / Stats / Info) */}
        <div className="px-4 py-2 bg-[#070e1b] border-b border-[#14264a] flex items-center gap-2">
          <button
            onClick={() => setDetailTab('timeline')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              detailTab === 'timeline'
                ? 'bg-emerald-500 text-slate-950'
                : 'text-slate-300 hover:text-white hover:bg-[#112244]'
            }`}
          >
            Match Timeline ({match.events.length})
          </button>
          <button
            onClick={() => setDetailTab('stats')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              detailTab === 'stats'
                ? 'bg-emerald-500 text-slate-950'
                : 'text-slate-300 hover:text-white hover:bg-[#112244]'
            }`}
          >
            Tactical Stats
          </button>
          <button
            onClick={() => setDetailTab('info')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              detailTab === 'info'
                ? 'bg-emerald-500 text-slate-950'
                : 'text-slate-300 hover:text-white hover:bg-[#112244]'
            }`}
          >
            Stadium & Info
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {/* TAB 1: TIMELINE */}
          {detailTab === 'timeline' && (
            <div className="space-y-3">
              {match.events.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  {isLive ? 'No key match events yet. Advancing minute-by-minute...' : 'Match has not kicked off yet.'}
                </div>
              ) : (
                match.events.map((ev) => {
                  const isHomeEvent = ev.teamId === match.homeTeam.id;
                  return (
                    <div
                      key={ev.id}
                      className="p-3 rounded-xl bg-[#0c1830] border border-[#14264b] flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono font-bold text-emerald-400 tabular-nums w-8">
                          {ev.minute}&apos;
                        </span>
                        <div>
                          <div className="flex items-center gap-1.5 font-semibold text-slate-100">
                            {ev.type === 'goal' && <Goal className="w-3.5 h-3.5 text-emerald-400" />}
                            {ev.type === 'yellow_card' && <div className="w-2.5 h-3.5 bg-amber-400 rounded-xs" />}
                            {ev.type === 'red_card' && <div className="w-2.5 h-3.5 bg-rose-500 rounded-xs" />}
                            <span>{ev.player}</span>
                          </div>
                          {ev.detail && (
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              {ev.detail}
                            </p>
                          )}
                        </div>
                      </div>
                      <span className="text-[11px] font-semibold text-slate-400 shrink-0">
                        {isHomeEvent ? match.homeTeam.code : match.awayTeam.code}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 2: TACTICAL STATS */}
          {detailTab === 'stats' && (
            <div className="space-y-4">
              {/* Possession Bar */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span className="font-mono tabular-nums">{homePoss}%</span>
                  <span className="text-slate-400">Possession</span>
                  <span className="font-mono tabular-nums">{awayPoss}%</span>
                </div>
                <div className="h-2 rounded-full bg-[#112347] overflow-hidden flex">
                  <div
                    className="bg-emerald-500 transition-all duration-300"
                    style={{ width: `${homePoss}%` }}
                  />
                  <div
                    className="bg-sky-500 transition-all duration-300"
                    style={{ width: `${awayPoss}%` }}
                  />
                </div>
              </div>

              {/* Stat rows */}
              <div className="space-y-2 pt-2">
                <StatRow
                  label="Shots on Target"
                  home={match.stats.shotsOnTarget[0]}
                  away={match.stats.shotsOnTarget[1]}
                />
                <StatRow
                  label="Total Shots"
                  home={match.stats.totalShots[0]}
                  away={match.stats.totalShots[1]}
                />
                <StatRow
                  label="Corners"
                  home={match.stats.corners[0]}
                  away={match.stats.corners[1]}
                />
                <StatRow
                  label="Fouls"
                  home={match.stats.fouls[0]}
                  away={match.stats.fouls[1]}
                />
                <StatRow
                  label="Dangerous Attacks"
                  home={match.stats.dangerousAttacks[0]}
                  away={match.stats.dangerousAttacks[1]}
                />
                <StatRow
                  label="Expected Goals (xG)"
                  home={match.stats.xG[0].toFixed(2)}
                  away={match.stats.xG[1].toFixed(2)}
                />
              </div>
            </div>
          )}

          {/* TAB 3: INFO */}
          {detailTab === 'info' && (
            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-xl bg-[#0c1830] border border-[#14264b] space-y-2">
                <h4 className="font-semibold text-slate-200">Venue & Pitch</h4>
                <p className="text-slate-400">
                  Stadium: <strong className="text-white">{match.homeTeam.stadium}</strong>, {match.homeTeam.city}
                </p>
                <p className="text-slate-400">
                  Surface: Natural Hybrid Turf
                </p>
                <p className="text-slate-400">
                  Capacity: 64,500
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0c1830] border border-[#14264b] space-y-2">
                <h4 className="font-semibold text-slate-200">Head-to-Head Record</h4>
                <p className="text-slate-400">
                  Past 5 meetings: {match.homeTeam.shortName} (2 wins), Draws (2), {match.awayTeam.shortName} (1 win).
                </p>
                <p className="text-slate-400">
                  Average goals per encounter: 2.8 goals.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

function StatRow({ label, home, away }: { label: string; home: number | string; away: number | string }) {
  return (
    <div className="flex items-center justify-between text-xs py-1.5 px-3 rounded-lg bg-[#0c1830] border border-[#14264b]">
      <span className="font-mono font-bold text-white tabular-nums">{home}</span>
      <span className="text-slate-400">{label}</span>
      <span className="font-mono font-bold text-white tabular-nums">{away}</span>
    </div>
  );
}
