import React, { useState, useEffect, useCallback } from 'react';
import {
  RotateCcw,
  Trophy,
  Coins,
  Sparkles,
  ArrowLeft,
  Volume2,
  VolumeX,
  Wand2,
  Flame,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useEarnova } from '../context/EarnovaContext';
import { sound } from '../utils/sound';

type RuneType = 'nature' | 'fire' | 'frost' | 'arcane' | 'thunder';

interface RuneItem {
  id: string;
  type: RuneType;
  isWild?: boolean;
}

const RUNE_INFO: Record<RuneType, { name: string; icon: string; bg: string; border: string; glow: string; points: number }> = {
  nature: { name: 'Sylva Leaf', icon: '🌿', bg: 'bg-emerald-700', border: 'border-emerald-400', glow: '#10b981', points: 30 },
  fire: { name: 'Ignis Flame', icon: '🔥', bg: 'bg-rose-700', border: 'border-rose-400', glow: '#f43f5e', points: 40 },
  frost: { name: 'Astra Frost', icon: '❄️', bg: 'bg-sky-600', border: 'border-sky-300', glow: '#38bdf8', points: 35 },
  arcane: { name: 'Arcane Eye', icon: '🔮', bg: 'bg-purple-700', border: 'border-purple-400', glow: '#a855f7', points: 50 },
  thunder: { name: 'Thunder Bolt', icon: '⚡', bg: 'bg-amber-600', border: 'border-yellow-300', glow: '#fbbf24', points: 45 },
};

const RUNE_KEYS: RuneType[] = ['nature', 'fire', 'frost', 'arcane', 'thunder'];
const SIZE = 6;
const TARGET_MANA = 100;

const createRune = (r: number, c: number): RuneItem => {
  const type = RUNE_KEYS[Math.floor(Math.random() * RUNE_KEYS.length)];
  return { id: `rune-${r}-${c}-${Date.now()}-${Math.random()}`, type };
};

const createInitialMatrix = (): RuneItem[][] => {
  const matrix: RuneItem[][] = [];
  for (let r = 0; r < SIZE; r++) {
    const row: RuneItem[] = [];
    for (let c = 0; c < SIZE; c++) {
      let rune = createRune(r, c);
      while (
        (c >= 2 && row[c - 1]?.type === rune.type && row[c - 2]?.type === rune.type) ||
        (r >= 2 && matrix[r - 1]?.[c]?.type === rune.type && matrix[r - 2]?.[c]?.type === rune.type)
      ) {
        rune = createRune(r, c);
      }
      row.push(rune);
    }
    matrix.push(row);
  }
  return matrix;
};

interface SpellboundTrioGameProps {
  onBack?: () => void;
}

export const SpellboundTrioGame: React.FC<SpellboundTrioGameProps> = ({ onBack }) => {
  const { user, updateUser } = useEarnova();
  const [board, setBoard] = useState<RuneItem[][]>(() => createInitialMatrix());
  const [selected, setSelected] = useState<{ r: number; c: number } | null>(null);
  const [score, setScore] = useState<number>(0);
  const [natureMana, setNatureMana] = useState<number>(40);
  const [fireMana, setFireMana] = useState<number>(30);
  const [frostMana, setFrostMana] = useState<number>(50);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [spellMessage, setSpellMessage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Match finder
  const findMatches = useCallback((b: RuneItem[][]): { r: number; c: number; type: RuneType }[] => {
    const matchedCoords = new Map<string, RuneType>();

    // Horizontal check
    for (let r = 0; r < SIZE; r++) {
      let count = 1;
      for (let c = 0; c < SIZE; c++) {
        const cur = b[r][c];
        const next = c < SIZE - 1 ? b[r][c + 1] : null;
        if (next && (cur.type === next.type || cur.isWild || next.isWild)) {
          count++;
        } else {
          if (count >= 3) {
            for (let i = 0; i < count; i++) {
              matchedCoords.set(`${r},${c - i}`, cur.type);
            }
          }
          count = 1;
        }
      }
    }

    // Vertical check
    for (let c = 0; c < SIZE; c++) {
      let count = 1;
      for (let r = 0; r < SIZE; r++) {
        const cur = b[r][c];
        const next = r < SIZE - 1 ? b[r + 1][c] : null;
        if (next && (cur.type === next.type || cur.isWild || next.isWild)) {
          count++;
        } else {
          if (count >= 3) {
            for (let i = 0; i < count; i++) {
              matchedCoords.set(`${r - i},${c}`, cur.type);
            }
          }
          count = 1;
        }
      }
    }

    return Array.from(matchedCoords.entries()).map(([coord, type]) => {
      const [r, c] = coord.split(',').map(Number);
      return { r, c, type };
    });
  }, []);

  // Process board collapse
  const processCascades = useCallback(
    (currentBoard: RuneItem[][]) => {
      const matches = findMatches(currentBoard);
      if (matches.length === 0) {
        setIsProcessing(false);
        return;
      }

      setIsProcessing(true);
      if (soundEnabled) sound.playWin();

      // Channel mana to sorceresses
      matches.forEach((m) => {
        if (m.type === 'nature') setNatureMana((prev) => Math.min(100, prev + 8));
        if (m.type === 'fire') setFireMana((prev) => Math.min(100, prev + 8));
        if (m.type === 'frost') setFrostMana((prev) => Math.min(100, prev + 8));
      });

      const gainedScore = matches.length * 35;
      setScore((prev) => prev + gainedScore);

      const nextBoard = currentBoard.map((row) => row.map((rune) => ({ ...rune })));

      setTimeout(() => {
        for (let c = 0; c < SIZE; c++) {
          let writeRow = SIZE - 1;
          for (let r = SIZE - 1; r >= 0; r--) {
            const isMatched = matches.some((item) => item.r === r && item.c === c);
            if (!isMatched) {
              if (writeRow !== r) {
                nextBoard[writeRow][c] = nextBoard[r][c];
              }
              writeRow--;
            }
          }
          while (writeRow >= 0) {
            nextBoard[writeRow][c] = createRune(writeRow, c);
            writeRow--;
          }
        }

        setBoard(nextBoard);
        setTimeout(() => {
          processCascades(nextBoard);
        }, 320);
      }, 250);
    },
    [findMatches, soundEnabled]
  );

  const handleTileClick = (r: number, c: number) => {
    if (isProcessing) return;

    if (soundEnabled) sound.playTap();

    if (!selected) {
      setSelected({ r, c });
      return;
    }

    const isAdjacent =
      (Math.abs(selected.r - r) === 1 && selected.c === c) ||
      (Math.abs(selected.c - c) === 1 && selected.r === r);

    if (!isAdjacent) {
      setSelected({ r, c });
      return;
    }

    // Perform swap
    const nextBoard = board.map((row) => row.map((rune) => ({ ...rune })));
    const temp = nextBoard[selected.r][selected.c];
    nextBoard[selected.r][selected.c] = nextBoard[r][c];
    nextBoard[r][c] = temp;

    const matches = findMatches(nextBoard);
    if (matches.length > 0) {
      setBoard(nextBoard);
      setSelected(null);
      processCascades(nextBoard);
    } else {
      setSelected(null);
    }
  };

  // Cast Sylva Nature Spell (Converts 4 random runes to Wild Vines)
  const castNatureSpell = () => {
    if (natureMana < 100 || isProcessing) return;
    setNatureMana(0);
    setSpellMessage('🌿 Sylva casts Emerald Wild Vines! (4 Wild Runes created)');
    if (soundEnabled) sound.playBonus();

    const nextBoard = board.map((row) => row.map((rune) => ({ ...rune })));
    for (let i = 0; i < 4; i++) {
      const randR = Math.floor(Math.random() * SIZE);
      const randC = Math.floor(Math.random() * SIZE);
      nextBoard[randR][randC].isWild = true;
    }
    setBoard(nextBoard);
    updateUser({ points: user.points + 150 });
    processCascades(nextBoard);
  };

  // Cast Ignis Fire Spell (Meteor Blast clears center 3x3)
  const castFireSpell = () => {
    if (fireMana < 100 || isProcessing) return;
    setFireMana(0);
    setSpellMessage('🔥 Ignis summons Meteor Blast! (+200 EP Burnt Area)');
    if (soundEnabled) sound.playWin();
    confetti({ particleCount: 50, spread: 70 });

    const nextBoard = board.map((row) => row.map((rune) => ({ ...rune })));
    for (let r = 1; r <= 3; r++) {
      for (let c = 1; c <= 3; c++) {
        nextBoard[r][c] = createRune(r, c);
      }
    }
    setScore((s) => s + 400);
    updateUser({ points: user.points + 200 });
    setBoard(nextBoard);
    processCascades(nextBoard);
  };

  // Cast Astra Frost Spell (Frost Freeze Multiplier)
  const castFrostSpell = () => {
    if (frostMana < 100 || isProcessing) return;
    setFrostMana(0);
    setSpellMessage('❄️ Astra casts Absolute Zero Freeze! (+300 EP Bonus)');
    if (soundEnabled) sound.playBonus();
    confetti({ particleCount: 60, spread: 60 });
    setScore((s) => s + 600);
    updateUser({ points: user.points + 300 });
  };

  const handleReset = () => {
    setBoard(createInitialMatrix());
    setSelected(null);
    setScore(0);
    setNatureMana(40);
    setFireMana(30);
    setFrostMana(50);
    setSpellMessage(null);
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-purple-900/50">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#0c1830] border border-purple-500/40 text-purple-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🧙‍♀️</span>
              <h2 className="font-display font-black text-lg sm:text-xl text-fuchsia-300 tracking-tight">
                Spellbound Trio
              </h2>
            </div>
            <p className="text-[11px] text-purple-300/80 font-mono">
              Wild Elemental Magic Rune Quest · Virtual Demo EP
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-[#0c1830] border border-purple-500/40 text-purple-300 hover:text-white cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="p-2 rounded-xl bg-[#0c1830] border border-purple-500/40 text-purple-300 hover:text-white cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 3 Sorceresses Elemental Mana Cards */}
      <div className="grid grid-cols-3 gap-2">
        {/* Sylva Nature */}
        <div className="p-2.5 rounded-2xl bg-gradient-to-b from-[#082415] to-[#04120a] border border-emerald-500/40 flex flex-col justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-xl">🧝‍♀️</span>
            <div className="min-w-0">
              <span className="text-[10px] font-bold text-emerald-300 block leading-tight">
                Sylva
              </span>
              <span className="text-[8.5px] text-emerald-400/80 font-mono">Nature</span>
            </div>
          </div>
          <div className="h-1.5 w-full bg-emerald-950 rounded-full overflow-hidden my-1.5">
            <div className="h-full bg-emerald-400" style={{ width: `${natureMana}%` }} />
          </div>
          <button
            type="button"
            onClick={castNatureSpell}
            disabled={natureMana < 100}
            className={`w-full py-1 rounded-lg text-[9px] font-bold uppercase transition-all cursor-pointer ${
              natureMana >= 100
                ? 'bg-emerald-400 text-slate-950 animate-pulse font-black'
                : 'bg-emerald-950/60 text-emerald-600 cursor-not-allowed'
            }`}
          >
            {natureMana >= 100 ? 'CAST WILD!' : `${natureMana}% Mana`}
          </button>
        </div>

        {/* Ignis Fire */}
        <div className="p-2.5 rounded-2xl bg-gradient-to-b from-[#2b0c10] to-[#120406] border border-rose-500/40 flex flex-col justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-xl">🧙‍♀️</span>
            <div className="min-w-0">
              <span className="text-[10px] font-bold text-rose-300 block leading-tight">
                Ignis
              </span>
              <span className="text-[8.5px] text-rose-400/80 font-mono">Fire</span>
            </div>
          </div>
          <div className="h-1.5 w-full bg-rose-950 rounded-full overflow-hidden my-1.5">
            <div className="h-full bg-rose-400" style={{ width: `${fireMana}%` }} />
          </div>
          <button
            type="button"
            onClick={castFireSpell}
            disabled={fireMana < 100}
            className={`w-full py-1 rounded-lg text-[9px] font-bold uppercase transition-all cursor-pointer ${
              fireMana >= 100
                ? 'bg-rose-500 text-slate-950 animate-pulse font-black'
                : 'bg-rose-950/60 text-rose-600 cursor-not-allowed'
            }`}
          >
            {fireMana >= 100 ? 'METEOR!' : `${fireMana}% Mana`}
          </button>
        </div>

        {/* Astra Frost */}
        <div className="p-2.5 rounded-2xl bg-gradient-to-b from-[#0a182d] to-[#040914] border border-sky-500/40 flex flex-col justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-xl">🧚‍♀️</span>
            <div className="min-w-0">
              <span className="text-[10px] font-bold text-sky-300 block leading-tight">
                Astra
              </span>
              <span className="text-[8.5px] text-sky-400/80 font-mono">Frost</span>
            </div>
          </div>
          <div className="h-1.5 w-full bg-sky-950 rounded-full overflow-hidden my-1.5">
            <div className="h-full bg-sky-400" style={{ width: `${frostMana}%` }} />
          </div>
          <button
            type="button"
            onClick={castFrostSpell}
            disabled={frostMana < 100}
            className={`w-full py-1 rounded-lg text-[9px] font-bold uppercase transition-all cursor-pointer ${
              frostMana >= 100
                ? 'bg-sky-400 text-slate-950 animate-pulse font-black'
                : 'bg-sky-950/60 text-sky-600 cursor-not-allowed'
            }`}
          >
            {frostMana >= 100 ? 'FREEZE 3X!' : `${frostMana}% Mana`}
          </button>
        </div>
      </div>

      {/* Score bar */}
      <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-[#09152b] border border-purple-500/30">
        <div className="text-center">
          <span className="text-[10px] uppercase font-bold text-purple-300 block">Arcane Score</span>
          <span className="font-mono font-black text-xl text-yellow-300 tabular-nums">
            {score.toLocaleString()}
          </span>
        </div>
        <div className="text-center border-l border-purple-900/60">
          <span className="text-[10px] uppercase font-bold text-purple-300 block">Virtual Balance</span>
          <span className="font-mono font-black text-base text-emerald-400 tabular-nums">
            {(user?.points ?? 0).toLocaleString()} EP
          </span>
        </div>
      </div>

      {/* 6x6 Rune Grid */}
      <div className="relative p-3 rounded-3xl bg-gradient-to-b from-[#19092d] to-[#090214] border-2 border-purple-600/60 shadow-2xl">
        <div className="grid grid-cols-6 gap-1.5 sm:gap-2 max-w-[420px] mx-auto p-1">
          {board.map((row, r) =>
            row.map((rune, c) => {
              const info = RUNE_INFO[rune.type];
              const isSelected = selected?.r === r && selected?.c === c;
              return (
                <button
                  key={rune.id}
                  type="button"
                  onClick={() => handleTileClick(r, c)}
                  className={`aspect-square rounded-2xl flex items-center justify-center relative cursor-pointer select-none transition-all duration-150 transform ${
                    info.bg
                  } border-2 ${info.border} ${
                    isSelected ? 'scale-110 ring-4 ring-yellow-300 z-10 animate-pulse' : 'hover:scale-105 active:scale-95'
                  }`}
                >
                  <span className="text-2xl filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] pointer-events-none">
                    {rune.isWild ? '✨' : info.icon}
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>

      {spellMessage && (
        <div className="p-2.5 rounded-xl bg-purple-950/60 border border-purple-500/40 text-center text-xs font-semibold text-fuchsia-200 animate-fade-in">
          {spellMessage}
        </div>
      )}
    </div>
  );
};
