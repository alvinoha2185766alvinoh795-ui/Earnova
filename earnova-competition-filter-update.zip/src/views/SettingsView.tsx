import React, { useState } from 'react';
import {
  ArrowLeft,
  Volume2,
  VolumeX,
  Plus,
  Minus,
  Check,
  RotateCcw,
  Bell,
  BellOff,
  Globe,
  Wifi,
  WifiOff,
  Save,
  Music,
  Sliders,
  ShieldCheck,
  Sparkles,
  LogIn,
  LogOut,
  User,
} from 'lucide-react';
import { useEarnova } from '../context/EarnovaContext';
import { useTranslation } from '../utils/i18n';

interface SettingsViewProps {
  onBack: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onBack }) => {
  const {
    user,
    updateUser,
    volume,
    setVolume,
    playTestSound,
    language,
    setLanguage,
    lowDataMode,
    toggleLowDataMode,
    resetAllDemoData,
    openAuthModal,
    logoutUser,
  } = useEarnova();
  const { t } = useTranslation(language);

  // Local state for volume adjustment before saving
  const [currentVolume, setCurrentVolume] = useState<number>(volume ?? 80);
  const [isMuted, setIsMuted] = useState<boolean>(!user.soundEnabled || currentVolume === 0);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [lastSavedVolume, setLastSavedVolume] = useState<number>(volume ?? 80);

  // Handle slider drag
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setCurrentVolume(val);
    if (val > 0 && isMuted) {
      setIsMuted(false);
    }
    setVolume(val);
  };

  // Increase volume by step (5)
  const handleIncrease = () => {
    const next = Math.min(100, currentVolume + 5);
    setCurrentVolume(next);
    if (isMuted && next > 0) {
      setIsMuted(false);
      updateUser({ soundEnabled: true });
    }
    setVolume(next);
    playTestSound();
  };

  // Decrease volume by step (5)
  const handleDecrease = () => {
    const next = Math.max(0, currentVolume - 5);
    setCurrentVolume(next);
    setVolume(next);
    if (next === 0) {
      setIsMuted(true);
    }
    playTestSound();
  };

  // Toggle mute / unmute
  const handleToggleMute = () => {
    if (isMuted) {
      // Unmute: restore to last non-zero volume or 80
      const restored = lastSavedVolume > 0 ? lastSavedVolume : 80;
      setIsMuted(false);
      setCurrentVolume(restored);
      setVolume(restored);
      updateUser({ soundEnabled: true });
      setTimeout(() => playTestSound(), 50);
    } else {
      // Mute: save current volume and set to 0
      setLastSavedVolume(currentVolume);
      setIsMuted(true);
      updateUser({ soundEnabled: false });
    }
  };

  // Save volume preference
  const handleSavePreference = () => {
    updateUser({
      soundEnabled: !isMuted && currentVolume > 0,
      volume: isMuted ? 0 : currentVolume,
    });
    setVolume(isMuted ? 0 : currentVolume);
    setSaveSuccess(true);
    playTestSound();
    setTimeout(() => {
      setSaveSuccess(false);
    }, 3000);
  };

  return (
    <div className="space-y-6 pb-16 max-w-3xl mx-auto">
      {/* 1. Header with Back Button */}
      <div className="flex items-center justify-between gap-4 pb-2 border-b border-[#14264b]">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#0c1830] hover:bg-[#122347] border border-[#162c57] text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer touch-manipulation active:scale-95"
          title="Back to Previous Screen"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-400" />
          <span>Back</span>
        </button>

        <div className="text-right">
          <h1 className="font-display font-extrabold text-lg sm:text-2xl text-white tracking-tight">
            Settings & Preferences
          </h1>
          <p className="text-[11px] text-slate-400">
            Audio volume, sound effects & app configuration
          </p>
        </div>
      </div>

      {/* 2. Audio & Volume Control Section (User Requirements 2 & 3) */}
      <div className="p-6 sm:p-7 rounded-3xl bg-[#0c1830] border border-[#162c57] shadow-xl space-y-6">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-inner">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-base sm:text-lg text-white">
                Audio Volume Controls
              </h2>
              <p className="text-xs text-slate-400">
                Live match goal chimes, settlement fanfares & tactical clicks
              </p>
            </div>
          </div>

          {/* Mute / Unmute Quick Toggle Button */}
          <button
            type="button"
            onClick={handleToggleMute}
            className={`px-3.5 py-2 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer touch-manipulation active:scale-95 ${
              isMuted
                ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                : 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
            }`}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            <span>{isMuted ? 'Muted' : 'Sound ON'}</span>
          </button>
        </div>

        {/* Volume Level Display & Percentage */}
        <div className="p-5 rounded-2xl bg-[#081224] border border-[#14264b] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Current Output Level
            </span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="font-mono font-black text-3xl sm:text-4xl text-white tabular-nums">
                {isMuted ? 0 : currentVolume}
              </span>
              <span className="text-emerald-400 font-bold text-sm">/ 100%</span>
            </div>
          </div>

          {/* Test Sound Preview Button */}
          <button
            type="button"
            onClick={() => {
              if (isMuted) {
                handleToggleMute();
              } else {
                playTestSound();
              }
            }}
            className="px-4 py-2.5 rounded-xl bg-[#10234a] hover:bg-[#163066] border border-[#1e3e7a] text-slate-200 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer touch-manipulation active:scale-95 shrink-0"
            title="Preview Audio with Current Volume"
          >
            <Music className="w-4 h-4 text-emerald-400" />
            <span>Test Sound Chime</span>
          </button>
        </div>

        {/* Slider with Decrease (-) and Increase (+) Buttons */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>0 (Silent)</span>
            <span className="font-mono font-bold text-emerald-400">
              {isMuted ? '0% (Muted)' : `${currentVolume}%`}
            </span>
            <span>100 (Maximum)</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Decrease Button (-) */}
            <button
              type="button"
              onClick={handleDecrease}
              disabled={isMuted ? currentVolume === 0 : currentVolume <= 0}
              className="w-12 h-12 rounded-2xl bg-[#0e1d3b] hover:bg-[#142a54] border border-[#193366] text-slate-200 hover:text-white flex items-center justify-center transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer touch-manipulation active:scale-90 shrink-0"
              title="Decrease Volume (-5%)"
              aria-label="Decrease Volume"
            >
              <Minus className="w-5 h-5 text-emerald-400" />
            </button>

            {/* Continuous Range Slider 0 to 100 */}
            <div className="relative flex-1 flex items-center">
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                value={isMuted ? 0 : currentVolume}
                onChange={handleSliderChange}
                className="w-full h-3 bg-[#081224] rounded-lg appearance-none cursor-pointer accent-emerald-500 border border-[#162c57] touch-manipulation"
                aria-label="Volume Slider from 0 to 100"
              />
            </div>

            {/* Increase Button (+) */}
            <button
              type="button"
              onClick={handleIncrease}
              disabled={!isMuted && currentVolume >= 100}
              className="w-12 h-12 rounded-2xl bg-[#0e1d3b] hover:bg-[#142a54] border border-[#193366] text-slate-200 hover:text-white flex items-center justify-center transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer touch-manipulation active:scale-90 shrink-0"
              title="Increase Volume (+5%)"
              aria-label="Increase Volume"
            >
              <Plus className="w-5 h-5 text-emerald-400" />
            </button>
          </div>
        </div>

        {/* Save Volume Preference Button (Requirement 3: Save volume preference) */}
        <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
          <button
            type="button"
            onClick={handleSavePreference}
            className="w-full sm:flex-1 py-3 px-5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer touch-manipulation"
          >
            {saveSuccess ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Preference Saved Successfully!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Save Volume Preference</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onBack}
            className="w-full sm:w-auto py-3 px-5 rounded-xl bg-[#081224] hover:bg-[#0e1e3b] border border-[#162c57] text-slate-300 hover:text-white font-semibold text-xs transition-colors cursor-pointer touch-manipulation"
          >
            Back to App
          </button>
        </div>
      </div>

      {/* 3. Additional App Preferences (Preserving existing features) */}
      <div className="p-6 rounded-3xl bg-[#0c1830] border border-[#162c57] space-y-4">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Match Alerts & Language</span>
        </h3>

        <div className="divide-y divide-[#14264a] text-xs">
          {/* Notifications Toggle */}
          <div className="py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {user.notificationsEnabled ? (
                <Bell className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <BellOff className="w-5 h-5 text-slate-500 shrink-0" />
              )}
              <div>
                <h4 className="font-semibold text-white">Live Event Banners</h4>
                <p className="text-slate-400 text-[11px]">
                  Real-time toasts for goals, VAR reviews, and prediction settlement
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => updateUser({ notificationsEnabled: !user.notificationsEnabled })}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer touch-manipulation shrink-0 ${
                user.notificationsEnabled ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                  user.notificationsEnabled ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Language Switcher */}
          <div className="py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <Globe className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <h4 className="font-semibold text-white">Interface Localization</h4>
                <p className="text-slate-400 text-[11px]">Switch between English and Kiswahili</p>
              </div>
            </div>
            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#081224] border border-[#14264b]">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer touch-manipulation ${
                  language === 'en' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setLanguage('sw')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer touch-manipulation ${
                  language === 'sw' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Kiswahili
              </button>
            </div>
          </div>

          {/* Smart Low-Data Mode */}
          <div className="py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {lowDataMode ? (
                <WifiOff className="w-5 h-5 text-amber-400 shrink-0" />
              ) : (
                <Wifi className="w-5 h-5 text-slate-400 shrink-0" />
              )}
              <div>
                <h4 className="font-semibold text-white">Smart Low-Data Mode</h4>
                <p className="text-slate-400 text-[11px]">
                  Optimizes background polling and minimizes animations for limited internet
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={toggleLowDataMode}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer touch-manipulation shrink-0 ${
                lowDataMode ? 'bg-amber-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                  lowDataMode ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* 4. Account & Authentication Management */}
      <div className="p-6 rounded-3xl bg-[#0c1830] border border-amber-500/40 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#14264b]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-white text-sm">Account & Security</h4>
              <p className="text-slate-400 text-xs">
                {user.isLoggedIn !== false && user.email
                  ? `Signed in as ${user.fullName || user.username} (${user.email})`
                  : 'Currently browsing in guest preview'}
              </p>
            </div>
          </div>

          <div>
            {user.isLoggedIn !== false && user.email ? (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Are you sure you want to log out of your Earnova account?')) {
                    logoutUser();
                  }
                }}
                className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In / Register</span>
              </button>
            )}
          </div>
        </div>

        {user.isLoggedIn !== false && user.email && (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-400 gap-2">
            <span>
              Firebase User ID: <strong className="font-mono text-emerald-400">{user.uid}</strong>
            </span>
            <button
              type="button"
              onClick={() => openAuthModal('forgot')}
              className="text-amber-400 hover:underline cursor-pointer text-left sm:text-right"
            >
              Change / Reset Password →
            </button>
          </div>
        )}
      </div>

      {/* 5. Factory Demo Reset Section */}
      <div className="p-6 rounded-3xl bg-[#0c1830] border border-rose-500/20 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="font-semibold text-white text-sm">Reset Demo Simulation</h4>
            <p className="text-slate-400 text-xs mt-0.5">
              Reset virtual balances back to 2,500 EP and restore initial demo state.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Restore initial factory demo balances and records?')) {
                resetAllDemoData();
                onBack();
              }
            }}
            className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer touch-manipulation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo State</span>
          </button>
        </div>
      </div>
    </div>
  );
};
